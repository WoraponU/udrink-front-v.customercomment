import Config from 'react-native-config'

// Fallback to dev endpoints
export const driverApi = Config.DRIVERAPI_URL || 'https://driver.api.udrinkidev.com/api/'
export const tripApi = Config.TRIPAPI_URL || 'https://trip.api.udrinkidev.com/api/'
