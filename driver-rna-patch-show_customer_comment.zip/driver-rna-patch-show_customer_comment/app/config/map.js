import { loadLocation, saveDirectionApiCallCount, loadDirectionApiCallCount } from './storage'
import { googleApiKey } from './uiconfig'

export const getLocation = async () => {
  let location = await loadLocation()
  return location
}

export const getRoute = async (mode, fromText, waypoints, toText) => {
  const APIKEY = googleApiKey
  const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${fromText}&waypoints=${waypoints}&destination=${toText}&key=${APIKEY}&mode=${mode}`

  try {
    let response = await fetch(url)

    let responseJson = await response.json()

    return responseJson
  }

  catch (e) {
    throw new Error('Map Routing error : ' + e)
  }
}

export const decodeRoute = (t, e) => {
  for (var n, o, u = 0, l = 0, r = 0, d = [], h = 0, i = 0, a = null, c = Math.pow(10, e || 5); u < t.length;) { a = null, h = 0, i = 0; do a = t.charCodeAt(u++) - 63, i |= (31 & a) << h, h += 5; while (a >= 32); n = 1 & i ? ~(i >> 1) : i >> 1, h = i = 0; do a = t.charCodeAt(u++) - 63, i |= (31 & a) << h, h += 5; while (a >= 32); o = 1 & i ? ~(i >> 1) : i >> 1, l += n, r += o, d.push([l / c, r / c]) } return d = d.map(function (t) { return { latitude: t[0], longitude: t[1] } })
}

export const setPath = async (fromText, waypoints, toText) => {  
  try {
    const n = await loadDirectionApiCallCount() + 1
    saveDirectionApiCallCount(n)
    console.log(`calling google direction api #${n}`)

    let responseJson = await getRoute(
      'driving',
      fromText,
      waypoints,
      toText
    )
    if (responseJson.routes.length) {
      return decodeRoute(responseJson.routes[0].overview_polyline.points)
    }
  }
  catch(e){ 
    console.log('can not calling google direction api');
    return {}
  }
}