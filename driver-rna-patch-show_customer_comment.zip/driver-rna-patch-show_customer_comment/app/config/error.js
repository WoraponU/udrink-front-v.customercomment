export const errorTranslator = (e) => {
  let message = e.message.replace('TypeError:', '').replace('Error:', '').replace(' ', '')
  switch (message) {
    case 'InputError':
      return 'ข้อมูลที่กรอกผิดพลาด'
    case 'InvalidDriverCredentialsError':
      return 'อีเมลล์หรือรหัสผิดพลาด'
    case 'Network request failed':
      return 'กรุณาต่ออินเตอร์เน็ต'
    case 'RatingInputError':
      return 'กรุณาให้ประเมินลูกค้า'
    case 'GPSError':
      return 'กรุณาเปิด GPS'
    case 'cancelled':
      return 'งานถูกยกเลิก'
    case 'DuplicatedDriverError':
      return 'พนักงานขับรถลงทะเบียนไปแล้ว'
    case 'NotApprovedError':
      return 'พนักงานขับรถยังไม่ได้รับการอนุญาติให้ใช้งาน'
    case 'DriverNotAssignedError':
    case 'TripLockedError':
      return 'ไม่สามารถรับงานได้เนื่องจากข้อมูลมีการเปลี่ยนแปลง'
    case 'DriverNotOnTripError':
      return 'ไม่สามารถปฏิบัติงานต่อได้เนื่องจากคุณไม่ได้อยู่ในทริปนี้แล้ว'
    default:
      return message
  }
}
export const getError = (e) => {
  let alertText = {
    title: '',
    text: ''
  }
  switch (e.message) {
    case 'ApiError':
      alertText.title = 'เกิดข้อผิดพลาด'
      alertText.text = 'เกิดข้อผิดพลาด'
      break;
    case 'FetchStateError':
      alertText.title = 'เกิดข้อผิดพลาด'
      alertText.text = 'เกิดข้อผิดพลาด'
      break;
    case 'NetworkError':
      alertText.title = 'เครือข่ายผิดพลาด'
      alertText.text = 'เครือข่ายผิดพลาด'
      break;
    case 'GpsError':
      alertText.title = 'GPS ผิดพลาด'
      alertText.text = 'GPS ผิดพลาด เปิด GPS แล้วรออีกหนึ่งนาที'
      break;
    default:
      alertText.title = 'เกิดข้อผิดพลาด'
      alertText.text = 'เกิดข้อผิดพลาด'
  }

  return alertText
}

