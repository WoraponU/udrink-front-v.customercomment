import Config from 'react-native-config'

export const timeWaitBeforeMockup = 20 * 60 * 1000

export const timeWaitBefore = 20 * 60 * 1000

export const timeWaitAfter = 30 * 1000

export const pollingTime = 1000

export const MAX_WAIT_TIME = 60

export const locationInterval = 10 * 1000

export const updateCycle = 60 * 1000

export const maximumLocation = 10

export const updateGap = 2

export const intervalName = 'countDown'

export const COMPENSATE_TIME = 0

// export const COMPENSATE_TIME = 1740000+10000

export const expense = {
  bucket: 'udid-dev-images',
  region: 'ap-southeast-1',
  accessKey: 'AKIAI5CW7CV62XVRMBQA',
  secretKey: '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',
  successActionStatus: 201
}

export const googleApiKey = 'AIzaSyAT4ci-YXqw2on2ZiMsP0pSP-T55vWrkZ0'
// export const googleApiKey = 'AIzaSyBb7Pgva9cWL5gc3LAcMYEvgTV_xoS13GM'
// export const googleApiKey = 'AIzaSyC_9z08UBNOL4ysQQufx_rDUQj4LxGOb_A'

export const POLLING_INTERVAL = Config.POLLING_INTERVAL || 15
export const FCM_TOPIC_RESTART_SHIFT = Config.FCM_TOPIC_RESTART_SHIFT || 'restart-shift'

export const AUTODRIVE_POLLING = Config.AUTODRIVE_POLLING || 600
export const AUTODRIVE_DISTANCE = Config.AUTODRIVE_DISTANCE || 2
export const AUTODRIVE_UNIT = Config.AUTODRIVE_UNIT || 'km'