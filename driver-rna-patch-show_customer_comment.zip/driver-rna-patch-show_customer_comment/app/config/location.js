import BackgroundGeolocation from 'react-native-mauron85-background-geolocation'
import _ from 'lodash'

export const getLocationNow = () => {
  return new Promise((resolve, reject) =>
    BackgroundGeolocation.getLocations(
      locationsStored => {
        const latestLocation = _.maxBy(locationsStored, function (location) {
          return location.time
        })
        // let currentLocationMap = locationsStored[locationsStored.length - 1]
        resolve(latestLocation)
      },
      err => {
        console.log(err)
        reject(err)
      }
    )
  )
}