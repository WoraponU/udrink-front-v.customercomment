import { driverApi } from './hostname'
import { getLocationNow } from './location'
import { updateCycle } from './uiconfig'

// let lastUpdate = new Date().getTime()

export const fetchInfo2 = async (url, body, action = 0, timestamp = new Date().toJSON()) => {
  if (action == 1) {
    let location = await getLocationNow()
    // console.log(location)
    if(location !== undefined){
      body.location = [location.longitude, location.latitude]
    } 
    body.timestamp = timestamp
    const timeLocation = location.time
    if (timeLocation - new Date().getTime() < -1*updateCycle*1*0.5) {      
      // throw new Error('GPSError')
    } 
  }
  try {
    let response = await fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    })

    let responseJson = await response.json()

    if (responseJson.error) {
      throw new Error(responseJson.error)
    }
    return responseJson
  }
  catch (error) {    
    throw new Error(error)
  }

}

export const getState2 = async (token, deviceInfo) => {
  try {
    let response = await fetch(driverApi + 'driver-state', {
      method: 'POST',
      headers: {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        token: token,
        ...(deviceInfo && { deviceInfo })
      })
    })
    let responseJson = await response.json()
    // console.log(responseJson)
    if (responseJson.error) {
      throw new Error(responseJson.error)
    }

    return responseJson
  }
  catch (error) {    
    throw new Error(error)
  }
}

export const calculateTime = (maxtime, lastStateChanged) =>{
  return maxtime - Math.floor(((new Date().getTime()) - (lastStateChanged))/1000)
}