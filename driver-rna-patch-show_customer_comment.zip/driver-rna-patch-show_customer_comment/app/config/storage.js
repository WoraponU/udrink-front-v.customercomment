import Storage from 'react-native-storage'
import { AsyncStorage } from 'react-native'
import moment from 'moment'
import { locationInterval, updateGap } from './uiconfig'

let storage = new Storage({
  size: 1000,
  storageBackend: AsyncStorage,
  defaultExpires: null,
  enableCache: true,
  sync: {

  }
})

export const setLocation = (location) => {
  storage.save({
    key: 'location',
    data: {
      location: location
    }
  })
}

export const loadLocation = async () => {
  try {
    return (await storage.load({
      key: 'location'
    })).location
  }
  catch (error) {
    return {
      latitude: 0,
      longitude: 0
    }
  }

}

export const isLocationUpdate = async () => {
  try {
    let location = (await storage.load({
      key: 'location'
    })).location

    let diff = (new Date().getTime()) - location.time
    if (diff > locationInterval*updateGap) {
      storage.save({
        key: 'isupdate',
        data: {
          isupdate: false
        }
      })
    }
    else {
      storage.save({
        key: 'isupdate',
        data: {
          isupdate: true
        }
      })
    }
  }
  catch (error) {

  }
}

export const loadIsLocationUpdate = async () => {
  await isLocationUpdate()
  try {
    let isupdate = (await storage.load({
      key: 'isupdate'
    })).isupdate

    return isupdate

  }
  catch (error) {

  }
}

export const setWaitAccept = (waitTime) => {
  storage.save({
    key: 'waitAccept',
    data: {
      time: moment(waitTime)
    }
  })
}

export const loadWaitAccept = async () => {
  let ret = await storage.load({
    key: 'waitAccept',
  })
  let timeDiff = moment.duration(moment().diff(ret.time))

  return timeDiff
}

export const setNotiId = (device) => {
  storage.save({
    key: 'notiId',
    data: {
      device: device
    }
  })
}

export const loadNotiId = async () => {
  try{
    return (await storage.load({
      key: 'notiId',
    })).device
  } catch(err) {
    return {}
  }
}

export const setTrip = (tripInfo) => {
  storage.save({
    key: 'tripInfo',
    data: {
      tripInfo: tripInfo
    },
    expires: null
  })
}

export const loadTrip = async () => {
  return (await storage.load({
    key: 'tripInfo',
  })).tripInfo
}

export const resetWaitBefore = () => {
  storage.save({
    key: 'waitBeforeTime',
    data: {
      time: moment()
    },
    expires: null
  })
}

export const setWaitBefore = (pickupDate) => {
  storage.save({
    key: 'waitBeforeTime',
    data: {
      time: moment(pickupDate)
    },
    expires: null
  })
}

export const loadWaitBefore = async () => {
  let ret = await storage.load({
    key: 'waitBeforeTime',
  })
  let timeDiff = moment.duration(moment().diff(ret.time))

  return timeDiff
}

export const resetWaitAfter = () => {
  storage.save({
    key: 'waitAfterTime',
    data: {
      time: moment()
    },
    expires: null
  })
}

export const setWaitAfter = (lastStateChange) => {
  storage.save({
    key: 'waitAfterTime',
    data: {
      time: moment(lastStateChange)
    },
    expires: null
  })
}

export const loadWaitAfter = async () => {
  let ret = await storage.load({
    key: 'waitAfterTime',
  })
  let timeDiff = moment.duration(moment().diff(ret.time))

  return timeDiff
}

export const setLogin = (email, password) => {
  storage.save({
    key: 'login',
    data: {
      email: email,
      password: password
    }
  })
}

export const loadLogin = async () => {
  try {
    return await storage.load({
      key: 'login',
    })
  }
  catch (error) {
    return error
  }
}

export const setToken = (token) => {
  try {
    storage.save({
      key: 'token',
      data: {
        token: token
      }
    })
  }
  catch (err) {
    console.error(err)
  }
}

export const loadToken = async () => {
  try {
    let token = await storage.load({
      key: 'token'
    })
    if (token) {
      return token.token
    }
  }
  catch (err) {
    console.log('@storage:', err.message)
    return null
  }
}

const STORAGE_DIRECTIONAPI_CALLCOUNT = 'directionApiCallCount'
export const saveDirectionApiCallCount = n => {
  try {
    storage.save({key:STORAGE_DIRECTIONAPI_CALLCOUNT, data: n.toString()})
  }
  catch (err) {
    console.error(err)
  }
}
export const loadDirectionApiCallCount = async _ => {
  let n = 0
  try {
    const result = await storage.load({key: STORAGE_DIRECTIONAPI_CALLCOUNT})
    if (result) {
      n = parseInt(result,10)
    }
  }
  catch(err) {
    console.log('@storage:', err.message)
  }
  return n
}