import React from 'react'
import { StatusBar } from 'react-native'
import { StackNavigator } from 'react-navigation'

import Trips from '../screens/Trips'
import Login from '../screens/Login'
import Register from '../screens/Register'
import JobAfterFinish from '../screens/JobAfterFinish'
import JobProcess from '../screens/JobProcess'
import TransportCost from '../screens/TransportCost'

export default (RootStack = StackNavigator(
  {
    Login: {
      screen: Login,
      navigationOptions: {
        title: 'Login'
      }
    },
    Register: {
      screen: Register,
      navigationOptions: {
        title: 'Register'
      }
    },
    TransportCost: {
      screen: TransportCost
    },
    Trips: {
      screen: Trips,
      navigationOptions: {
        title: 'Trips'
      }
    },
    JobProcess: {
      screen: JobProcess
    },
    JobAfterFinish: {
      screen: JobAfterFinish
    }, 
  },
  {
    headerMode: 'none',    
  }
))
