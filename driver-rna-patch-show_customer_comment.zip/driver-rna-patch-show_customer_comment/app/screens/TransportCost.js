import React from 'react'
import { connect } from 'react-redux'
import {
  View,
  ImageBackground,
  Text,
  TouchableOpacity,
  Keyboard,
  Alert,
  TextInput,
  AppState
} from 'react-native'
import { FormInput, Button, Icon } from 'react-native-elements'
import { CameraKitCamera } from 'react-native-camera-kit'
import ModalSelector from 'react-native-modal-selector'
import { getState2, fetchInfo2 } from '../config/api'
import { loadToken } from '../config/storage'
import { RNS3 } from 'react-native-aws3'
import { expense } from '../config/uiconfig'
import { driverApi } from '../config/hostname'
import { navigateToScreen } from '../state/paco/nav'
import { processArrive } from '../state/paco/process'
import { errorTranslator } from '../config/error'
import { tripOpenNoti } from '../state/paco/trip';
class TransportCost extends React.Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      layout: 'formInput',
      header: 'บันทึกค่าใช้จ่าย',
      camera: 'off',
      preview: 'off',
      activeNumber: 0,
      token: '',
      state: '',
      tripId: '',
      tripInfo: '',
      uploading: false,
      expenseType: ['', '', '', '', '', ''],
      cost: ['', '', '', '', '', ''],
      keyboard: 'off',
      cancel: false,

      appState: AppState.currentState,
    }
    this.expenseType = ['', '', '', '', '', '']
    this.cost = ['', '', '', '', '', '']
    this.imagepath = {
      image1: {
        index: 1,
        path: ''
      },
      image2: {
        index: 2,
        path: ''
      },
      image3: {
        index: 3,
        path: ''
      },
      image4: {
        index: 4,
        path: ''
      },
      image5: {
        index: 5,
        path: ''
      }
    }
  }

  componentWillMount() {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow
    )
    this.keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      this._keyboardDidHide
    )
  }

  componentDidMount = async () => {
    AppState.addEventListener('change', this._handleAppStateChange)
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove()
    this.keyboardDidHideListener.remove()

    AppState.removeEventListener('change', this._handleAppStateChange)
  }

  _handleAppStateChange = nextAppState => {
    let stillInThisScreen = true
    if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
      try {
        this.props.tripOpenNoti({}) // fake noti to refresh state
        stillInThisScreen = false
      } catch (err) {
        // TODO: show warning to user
        console.log('@TransportCost: getting state error', err)
      }
    }

    if (stillInThisScreen) {
      this.setState({
        appState: nextAppState
      })
    }
  }

  _keyboardDidShow = () => {
    this.setState({
      keyboard: 'on'
    })
  }

  _keyboardDidHide = () => {
    this.setState({
      keyboard: 'off'
    })
  }

  clearInfo(id) {
    this.expenseType[id] = ''
    let expenseType = this.state.expenseType
    expenseType[id] = ''
    this.cost[id] = ''
    let cost = this.state.cost
    cost[id] = ''
    this.setState({
      cost: cost,
      expenseType: expenseType
    })
    this.imagepath[`image${id}`].path = ''
  }

  setActiveRow(id) {
    this.setState({
      activeNumber: id
    })
  }

  previewOff() {
    this.setState({
      preview: 'off',
      camera: 'off',
      activeNumber: 0,
      header: 'บันทึกค่าใช้จ่าย'
    })
  }

  putFile = async (token, responseJson, state) => {
    let rns3Put = []
    if (
      (responseJson.lastTripId || responseJson.tripId) &&
      responseJson.state &&
      !responseJson.error
    ) {
      let tripId = null
      if (responseJson.lastTripId) {
        tripId = responseJson.lastTripId
      } else if (responseJson.tripId) {
        tripId = responseJson.tripId
      }
      for (let img in this.imagepath) {
        let imgObj = this.imagepath[img]
        if (
          imgObj.path !== '' &&
          this.expenseType[imgObj.index] !== '' &&
          this.cost[imgObj.index] !== ''
        ) {
          let fileName = `${imgObj.index}-${Math.random()
            .toString(36)
            .substring(2) + new Date().getTime().toString(36)}-${imgObj.path.replace(
            /^.*[\\\/]/,
            ''
          )}`
          let file = {
            uri: imgObj.path,
            name: fileName,
            type: 'image/jpeg'
          }

          expense.keyPrefix = `trip-photos/${tripId}/`
          rns3Put.push(
            RNS3.put(file, expense)
              .then(response => {
                return {
                  type: this.expenseType[imgObj.index],
                  amount: parseInt(this.cost[imgObj.index]),
                  photo: response.body.postResponse.location
                }
              })
              .progress(e => console.log(e.loaded, e.total))
          )
        }
      }
      await Promise.all(rns3Put).then(items => {
        return fetchInfo2(driverApi + 'v2/driver-expense', {
          token: token,
          command: 'write',
          tripId: tripId,
          driverState: responseJson.state,
          items: items
        })
      })

      return this.goToScreen(state)
    } else {
      throw new Error('อัพโหลดไม่ได้')
    }
  }

  validate = () => {
    let totalEmpthy = true
    let result = true
    for (let obj in this.imagepath) {
      let path = this.imagepath[obj].path == ''
      let expenseType = this.expenseType[this.imagepath[obj].index] == ''
      let cost = this.cost[this.imagepath[obj].index] == ''

      let empthy = path & expenseType & cost

      let notEmpthy = !(path | expenseType | cost)

      result &= empthy | notEmpthy
      totalEmpthy &= empthy
    }

    return {
      result,
      totalEmpthy
    }
  }

  finish = async () => {
    let { result, totalEmpthy } = await this.validate()
    if (result && !totalEmpthy) {
      this.setState({
        uploading: true
      })
      try {
        let token = await loadToken()
        let response = await getState2(token)

        await this.putFile(token, response, this.props.state)
        console.log('putfile finished')
        // this.setState({
        //   uploading: false
        // }
        //   // () => this.props.navigateToScreen('JobProcess')
        // )
        // if (this.props.state == 'travel') {
        //   let res = await this.props.processArrive()
        //   // console.log(res)
        //   if (res) {
        //     await this.putFile(token, response, this.props.state)
        //     // this.goToScreen(this.props.state)
        //   } else {
        //     throw Error('ยังไม่สามารถอัพโหลดได้')
        //   }
        // } else {
        //   await this.putFile(token, response, this.props.state)
        //   // this.goToScreen(this.props.state)
        // }
      } catch (error) {
        console.log('putfile catch')

        this.setState({
          uploading: false
        })

        Alert.alert(
          'เกิดข้อผิดพลาด',
          errorTranslator(error),
          [
            {
              text: 'รับทราบ',
              onPress: () => {}
            }
          ],
          { cancelable: false }
        )
      }
    } else {
      Alert.alert(
        'คำเตือน!',
        'กรุณากรอกข้อมูลให้เรียบร้อย',
        [
          {
            text: 'รับทราบ',
            onPress: () => {}
          }
        ],
        { cancelable: false }
      )
    }
  }

  backToScreen = async () => {
    this.setState({
      uploading: true,
      cancel: true
    })
    this.setState({
      uploading: false
    })
    this.goToScreen(this.props.state)
  }

  goToScreen(state) {
    if (
      state == 'on-queue' ||
      state == 'standby' ||
      state == 'on-line' ||
      state == 'evaluated' ||
      state == 'assigned'
    ) {
      this.props.navigateToScreen('Trips')
    } else if (
      state == 'booked' ||
      state == 'travel' ||
      state == 'arrived' ||
      state == 'on-job' ||
      state == 'on-board' ||
      state == 'waitBefore' ||
      state == 'arrivedBefore' ||
      state == 'arrivedAfter' ||
      state == 'drive' ||
      state == 'drop'
    ) {
      this.props.navigateToScreen('JobProcess')
    } else if (state == 'off-job') {
      this.props.navigateToScreen('JobAfterFinish')
    } else {
      this.props.navigateToScreen('JobProcess')
    }
  }

  takePicture = async () => {
    try {
      const { id, height, width, name, size, uri } = await this.camera.capture(true)
      if (uri) {
        this.imagepath[`image${this.state.activeNumber}`] = {
          index: this.state.activeNumber,
          path: `file://${uri}`
        }
        this.handleLayout('formInput', this.state.activeNumber)
      } else {
        throw new Error('หาภาพไม่เจอ')
      }
    } catch (error) {
      Alert.alert(
        'เกิดข้อผิดพลาด',
        'ไม่สามารถถ่ายรูปได้',
        [
          {
            text: 'รับทราบ',
            onPress: () => {}
          }
        ],
        { cancelable: false }
      )
    }
  }

  handleLayout = (layout, activeNumber = 0) => {
    let header

    switch (layout) {
      case 'camera':
        header = ''
        break
      case 'reviewPhoto':
        header = 'ตัวอย่างภาพถ่าย'
        break
      default:
        header = 'บันทึกค่าใช้จ่าย'
        break
    }

    this.setState(
      {
        layout,
        activeNumber,
        header
      },
      () => {
        Keyboard.dismiss()
      }
    )
  }

  calculateBg = number => {
    // number == this.state.activeNumber ? '#9E9E9E' : '#F5F5F5'
    if (
      this.imagepath[`image${number}`].path &&
      this.expenseType[number] !== '' &&
      this.cost[number] !== ''
    ) {
      return '#ced19a'
    } else if (
      (!this.imagepath[`image${number}`] ||
        this.imagepath[`image${number}`].path === '') &&
      this.expenseType[number] === '' &&
      this.cost[number] === ''
    ) {
      return '#F5F5F5'
    } else {
      return '#ffebea'
    }
  }

  render() {
    const numbers = [1, 2, 3, 4, 5]
    const formCost = numbers.map(number => (
      <View
        key={number}
        style={{
          flex: 1,
          flexDirection: 'row',
          margin: 0,
          paddingVertical: 3,
          backgroundColor: this.calculateBg(number),
          justifyContent: 'center',
          alignItems: 'center'
        }}>
        <View
          style={{
            flex: 2,
            margin: 0
          }}>
          <ModalSelector
            style={{
              flex: 1,
              margin: 0,
              justifyContent: 'center',
              alignItems: 'center'
            }}
            overlayStyle={{
              backgroundColor: 'rgba(0,0,0,0.9)'
            }}
            selectStyle={{
              borderWidth: 0
            }}
            optionTextStyle={{
              fontSize: 25
            }}
            cancelTextStyle={{
              fontSize: 25
            }}
            data={[
              { key: 1, label: 'แท๊กซี่', value: 'taxi' },
              { key: 2, label: 'มอไซวิน/grab bike', value: 'motorcycle' },
              { key: 3, label: 'BTS/MRT/Airport Link', value: 'train' },
              { key: 4, label: 'เรือ', value: 'boat' },
              { key: 5, label: 'รถตู้', value: 'van' },
              { key: 6, label: 'รถเมล์/รถทัวร์', value: 'bus' },
              { key: 7, label: 'ค่าทางด่วน', value: 'trollway' },
              { key: 8, label: 'อื่นๆ', value: 'others' }
            ]}
            cancelText="ปิด"
            onPress={this.setActiveRow.bind(this, number)}
            onChange={option => {
              this.expenseType[number] = option.value
              let expenseType = this.state.expenseType
              expenseType[number] = option.label
              this.setState({
                expenseType: expenseType
              })
            }}>
            <TextInput
              style={{
                flex: 2,
                margin: 0,
                padding: 0,
                width: 100,
                justifyContent: 'center',
                alignItems: 'center',
                color: '#565656',
                fontSize: 20
              }}
              textAlign={'center'}
              underlineColorAndroid={0}
              editable={false}
              placeholder="ประเภท"
              value={this.state.expenseType[number]}
            />
          </ModalSelector>
        </View>
        <View
          style={{
            flex: 2
          }}>
          <FormInput
            keyboardType="numeric"
            underlineColorAndroid={0}
            inputStyle={{
              fontSize: 20,
              color: '#565656'
            }}
            placeholder="ราคา"
            value={this.state.cost[number]}
            onPress={this.setActiveRow.bind(this, number)}
            onChangeText={val => {
              this.cost[number] = val
              let cost = this.state.cost
              cost[number] = val
              this.setState({
                cost: cost
              })
            }}
          />
        </View>
        {!(this.imagepath[`image${number}`] && this.imagepath[`image${number}`].path) ? (
          <TouchableOpacity
            disabled={this.state.uploading}
            activeOpacity={0.8}
            style={{
              flex: 1
            }}
            onPress={this.handleLayout.bind(this, 'camera', number)}>
            <Icon name="photo-camera" size={32} />
          </TouchableOpacity>
        ) : null}
        {this.imagepath[`image${number}`] && this.imagepath[`image${number}`].path ? (
          <TouchableOpacity
            disabled={this.state.uploading}
            activeOpacity={0.8}
            style={{
              flex: 1
            }}
            onPress={this.handleLayout.bind(this, 'reviewPhoto', number)}>
            <Icon name={'crop-original'} size={32} />
          </TouchableOpacity>
        ) : null}
        {(this.imagepath[`image${number}`] && this.imagepath[`image${number}`].path) ||
        this.expenseType[number] !== '' ||
        this.cost[number] !== '' ? (
          <TouchableOpacity
            disabled={this.state.uploading}
            activeOpacity={0.8}
            style={{
              flex: 1
            }}
            onPress={this.clearInfo.bind(this, number)}>
            <Icon name={'clear'} size={32} />
          </TouchableOpacity>
        ) : null}
      </View>
    ))

    return (
      <View
        style={{
          flex: 1,
          backgroundColor: '#F5F5F5'
        }}
        textAlign={'center'}>
        {/* ///////////// formInput /////////////  */}
        {this.state.layout === 'formInput' && (
          <View
            style={{
              flex: 1
            }}>
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                paddingVertical: 15,
                marginBottom: 3
              }}>
              <Text
                style={{
                  fontSize: 30,
                  color: '#565656'
                }}>
                {this.state.header}
              </Text>
            </View>
            <View
              style={{
                flex: 10,
                flexDirection: 'column',
                paddingVertical: 15,
                marginBottom: 3
              }}>
              {formCost}
            </View>
            <View
              style={{
                flex: 2,
                flexDirection: 'row',
                padding: 3,
                margin: 3
              }}>
              <Button
                title="ย้อนกลับ"
                disabled={this.state.uploading}
                containerViewStyle={{
                  flex: 1
                }}
                fontSize={16}
                fontFamily="dbhelvethaicax_bd"
                backgroundColor="#E64A19"
                borderRadius={0}
                onPress={this.backToScreen}
              />
              <Button
                title={'บันทึก'}
                disabled={this.state.uploading}
                containerViewStyle={{
                  flex: 1
                }}
                fontSize={16}
                fontFamily="dbhelvethaicax_bd"
                backgroundColor="#46ade8"
                borderRadius={0}
                onPress={this.finish}
              />
            </View>
          </View>
        )}

        {/* ///////////// camera /////////////  */}
        {this.state.layout === 'camera' && (
          <View
            style={{
              flex: 1,
              backgroundColor: '#000'
            }}>
            <CameraKitCamera
              ref={cam => {
                this.camera = cam
              }}
              cameraOptions={{
                flashMode: 'auto', // on/off/auto(default)
                focusMode: 'on', // off/on(default)
                zoomMode: 'off', // off/on(default)
                ratioOverlay: '16:9', // optional, ratio overlay on the camera and crop the image seamlessly
                ratioOverlayColor: '#00000077' // optional
              }}
              style={{
                flex: 1,
                marginTop: 'auto',
                marginBottom: 'auto',
                padding: 0,
                justifyContent: 'center',
                alignItems: 'center'
              }}
            />

            <View
              style={{
                flex: 1,
                padding: 10,
                position: 'absolute',
                top: 10
              }}>
              <TouchableOpacity onPress={this.handleLayout.bind(this, 'formInput')}>
                <Icon name={'chevron-left'} size={60} color="#ffffff" />
              </TouchableOpacity>
            </View>
            <View
              style={{
                flex: 1,
                padding: 10,
                alignSelf: 'center',
                position: 'absolute',
                bottom: 10
              }}>
              <TouchableOpacity onPress={this.takePicture}>
                <Icon name="lens" size={70} color="#ffffff" />
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* ///////////// reviewPhoto /////////////  */}
        {this.state.layout === 'reviewPhoto' && (
          <View
            style={{
              flex: 1
            }}>
            <ImageBackground
              style={{
                flex: 1,
                margin: 0,
                justifyContent: 'center',
                alignItems: 'center'
              }}
              imageStyle={{ resizeMode: 'cover' }}
              source={{
                uri: this.imagepath[`image${this.state.activeNumber}`].path
              }}
            />
            <View
              style={{
                flex: 1,
                padding: 10,
                position: 'absolute',
                top: 10
              }}>
              <TouchableOpacity onPress={this.handleLayout.bind(this, 'formInput')}>
                <Icon name={'chevron-left'} size={60} color="#ffffff" />
              </TouchableOpacity>
            </View>
            <View
              style={{
                flex: 1,
                padding: 10,
                alignSelf: 'center',
                position: 'absolute',
                bottom: 10
              }}>
              <TouchableOpacity
                onPress={this.handleLayout.bind(this, 'camera', this.state.activeNumber)}>
                <Icon name="cancel" size={70} color="red" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
    )
  }
}

const mapStateToProp = state => ({
  state: state.trip.state,
  tripId: state.trip.tripId,
  trip: state.trip.tripInfo,
  customer: state.trip.tripInfo && state.trip.tripInfo.customer,
  stopsLocation: state.trip.tripInfo && state.trip.tripInfo.stopsLocation,
  fromLocation: state.trip.tripInfo && state.trip.tripInfo.fromLocation,
  toLocation: state.trip.tripInfo && state.trip.tripInfo.toLocation,
  pickupDate: state.trip.tripInfo && state.trip.tripInfo.pickupDate,
  priceNet: state.trip.tripInfo && state.trip.tripInfo.priceNet,
  remark: state.trip.tripInfo && state.trip.tripInfo.remark
})

const mapDispatchToProp = dispatch => {
  return {
    processArrive: () => dispatch(processArrive(false)),
    navigateToScreen: name => dispatch(navigateToScreen(name)),
    tripOpenNoti: (openResult) => dispatch(tripOpenNoti(openResult)),
  }
}

export default connect(
  mapStateToProp,
  mapDispatchToProp
)(TransportCost)
