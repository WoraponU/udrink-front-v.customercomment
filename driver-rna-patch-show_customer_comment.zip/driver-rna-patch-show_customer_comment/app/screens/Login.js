import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import {
  Text,
  View,
  Image,
  ImageBackground,
  Keyboard,
  Alert,
  ActivityIndicator,
  StyleSheet,
  AsyncStorage
} from 'react-native'
import { FormInput, Button } from 'react-native-elements'
import DeviceInfo from 'react-native-device-info'
import { loadLogin, loadToken, loadNotiId, setNotiId } from '../config/storage'
import { errorTranslator } from '../config/error'

import {
  requestLogin,
  loginSavePlayerId,
  clearError,
  loginSuccess,
  nextScreen,
  checkingToken,
  checkingTokenDone
} from '../state/paco/auth'
import { navigateToScreen } from '../state/paco/nav'
import { getState2 } from '../config/api'
import { getFCMToken } from './helpers/firebase'

class Login extends Component {
  state = {
    email: '',
    password: ''
  }

  componentWillMount() {
    this.props.checkingToken()
  }
  componentDidMount = async () => {
    this.keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      this._keyboardDidShow.bind(this)
    )
    this.keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      this._keyboardDidHide.bind(this)
    )

    const fcmToken = await AsyncStorage.getItem('fcmToken')
    if (fcmToken) {
      console.log('@Login, got fcmToken')
      this.props.loginSavePlayerId(fcmToken) // rehydrate to store

      let currentState
      const token = await loadToken()

      if (token) {
        console.log('@Login: got driver token', token)
        this.props.loginSuccess(token)

        try {
          const deviceInfo = await this.composeDeviceInfo()
          console.log('@Login: getting current state from api...')
          console.log('@Login: and saving DeviceInfo', deviceInfo)

          const { state: apiState } = await getState2(token, deviceInfo)
          currentState = apiState
          console.log('@Login: got current state', currentState)
          console.log('@Login: auto forward to next screen...')

          await this.props.nextScreen(currentState)
        } catch (err) {
          console.log('@Login: getting state error', err)
        }
      }

      if (!currentState) {
        console.log('@Login: showing login form')
        this.props.checkingTokenDone()
        this.recallLoginValues()
      }
    } else {
      console.log('@Login, no fcmToken')
      this.props.checkingTokenDone()
      this.recallLoginValues()
    }
  }

  recallLoginValues = async _ => {
    let result = await loadLogin()
    if (
      result.name !== 'NotFoundError' &&
      result.email !== '' &&
      result.password !== ''
    ) {
      this.setState({
        email: result.email,
        password: result.password
      })
    }
  }
  componentWillReceiveProps = nextProps => {
    Keyboard.dismiss()
    if (nextProps.errorMessage && nextProps.errorMessage !== '') {
      // let alertText = getError(nextProps.errorMessage)
      // console.log(nextProps.errorMessage)
      Alert.alert(
        'เกิดข้อผิดพลาด',
        errorTranslator(nextProps.errorMessage),
        [
          {
            text: 'รับทราบ',
            onPress: () => this.props.clearError()
          }
        ],
        { cancelable: false }
      )
    }
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove()
    this.keyboardDidHideListener.remove()
  }

  _keyboardDidShow() {
    this.setState({
      logoheight: 50
    })
    // setTimeout(() => {
    //   this.setState({
    //     logoheight: 50
    //   })
    // }, 500)
  }

  _keyboardDidHide() {
    this.setState({
      logoheight: 150
    })
    // setTimeout(() => {
    //   this.setState({
    //     logoheight: 150
    //   })
    // }, 500)
  }

  composeDeviceInfo = async _ => {
    const { userId } = await loadNotiId()
    return {
      buildNumber: DeviceInfo.getBuildNumber(),
      brand: DeviceInfo.getBrand(),
      model: DeviceInfo.getModel(),
      systemName: DeviceInfo.getSystemName(),
      systemVersion: DeviceInfo.getSystemVersion(),
      timestamp: new Date(),
      ...(userId && { playerId: userId })
    }
  }

  handleLogin2 = async () => {
    Keyboard.dismiss()
    this.props.requestLogin({
      email: this.state.email,
      password: this.state.password,
      deviceInfo: await this.composeDeviceInfo()
    })
  }

  handleRegister = () => {
    this.setState({
      loggingin: false
    })
    this.props.navigateToScreen('Register')
  }

  regetFCMToken = async _ => {
    const fcmToken = await getFCMToken()
    if (fcmToken) {
      setNotiId({ userId: fcmToken })
      this.props.loginSavePlayerId(fcmToken)
      console.log('done - setNotiId(fcmToken)')
    }
  }

  render() {
    const { isCheckingToken, playerId } = this.props
    return isCheckingToken ? (
      <View
        accessibilityLabel="loginView"
        style={{
          flex: 1,
          backgroundColor: '#d5d4d4',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
        <ActivityIndicator size="large" color="#58aee2" />
      </View>
    ) : !!playerId ? (
      <View
        accessibilityLabel="loginView"
        style={{
          flex: 1,
          backgroundColor: '#d5d4d4'
        }}>
        <ImageBackground
          accessibilityLabel="background"
          source={require('../asset/image/stripe2.png')}
          resizeMode="cover"
          style={{
            flex: this.props.logoheight / 5,
            width: '100%',
            height: '100%',
            justifyContent: 'center',
            alignItems: 'center'
          }}>
          <Image
            accessibilityLabel="logo"
            source={require('../asset/image/logo_udrink.png')}
            resizeMode="contain"
            style={{
              height: this.props.logoheight,
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: 40
            }}
          />
          <Text
            accessibilityLabel="logoLabel"
            style={{
              color: '#FFFFFF',
              marginVertical: 15,
              marginHorizontal: 10,
              justifyContent: 'center',
              alignItems: 'center',
              textAlign: 'center'
            }}>
            แอพสำหรับพนักงานขับรถ App {'\n'}
            {this.props.appVersion}, {'\n'}
            Build {this.props.buildBersion}
          </Text>
        </ImageBackground>
        <View
          style={{
            flex: 60
          }}>
          <View
            style={{
              marginTop: 30,
              marginHorizontal: 15
            }}>
            <FormInput
              accessibilityLabel="emailInput"
              underlineColorAndroid={0}
              containerStyle={{
                backgroundColor: '#FFF',
                borderRadius: 3,
                paddingLeft: 20,
                elevation: 2
              }}
              inputStyle={{
                fontSize: 25
              }}
              placeholder={'อีเมลล์'}
              onChangeText={val => {
                this.setState({ email: val })
              }}
              value={this.state && this.state.email ? this.state.email : ''}
            />
          </View>
          <View
            style={{
              marginVertical: 5,
              marginHorizontal: 15
            }}>
            <FormInput
              accessibilityLabel="passwordInput"
              underlineColorAndroid={0}
              containerStyle={{
                backgroundColor: '#FFF',
                borderRadius: 3,
                paddingLeft: 20,
                elevation: 2
              }}
              inputStyle={{
                fontSize: 25
              }}
              placeholder={'รหัสผ่าน'}
              secureTextEntry={true}
              onChangeText={val => {
                this.setState({ password: val })
              }}
              value={this.state && this.state.password ? this.state.password : ''}
            />
          </View>
          <Button
            large
            raise
            icon={this.props.isFetching ? { name: 'cached' } : null}
            accessibilityLabel="loginButton"
            onPress={this.handleLogin2}
            fontFamily="dbhelvethaicax_bd"
            fontSize={20}
            buttonStyle={styles.btnLogin}
            disabled={this.props.isFetching}
            title="เข้าสู่ระบบ"
          />
          <Text
            style={{
              textAlign: 'center',
              marginVertical: 6,
              color: '#FFFFFF'
            }}>
            หรือ
          </Text>
          <Button
            large
            raise
            accessibilityLabel="registerButton"
            onPress={this.handleRegister}
            fontFamily="dbhelvethaicax_bd"
            fontSize={20}
            buttonStyle={styles.btnRegister}
            title="สมัครใหม่"
          />
        </View>
      </View>
    ) : (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Your device is not ready!</Text>
        <Button
          onPress={this.regetFCMToken}
          title="Try again"
          fontFamily="dbhelvethaicax_bd"
          fontSize={20}
          buttonStyle={styles.btnLogin}
        />
      </View>
    )
  }
}

const styles = StyleSheet.create({
  btnLogin: {
    height: 50,
    marginHorizontal: 15,
    borderRadius: 3,
    marginTop: 10,
    backgroundColor: '#000000'
  },
  btnRegister: {
    height: 50,
    marginHorizontal: 15,
    borderRadius: 3,
    marginTop: 10,
    backgroundColor: '#58aee2'
  }
})

Login.propTypes = {
  requestLogin: PropTypes.func
}

const mapStateToProp = state => ({
  logoheight: 150,
  isFetching: state.auth.isFetching,
  isError: state.auth.isError,
  errorMessage: state.auth.errorMessage,
  appVersion: DeviceInfo.getVersion(),
  buildBersion: DeviceInfo.getBuildNumber(),
  isCheckingToken: state.auth.isCheckingToken,
  playerId: state.auth.playerId
})

const mapDispatchToProp = dispatch => {
  return {
    requestLogin: creds => dispatch(requestLogin(creds)),
    loginSavePlayerId: device => dispatch(loginSavePlayerId(device)),
    navigateToScreen: name => dispatch(navigateToScreen(name)),
    clearError: () => dispatch(clearError()),
    loginSuccess: token => dispatch(loginSuccess(token)),
    checkingToken: _ => dispatch(checkingToken()),
    checkingTokenDone: _ => dispatch(checkingTokenDone()),
    nextScreen: state => dispatch(nextScreen(state))
  }
}

export default connect(
  mapStateToProp,
  mapDispatchToProp
)(Login)
