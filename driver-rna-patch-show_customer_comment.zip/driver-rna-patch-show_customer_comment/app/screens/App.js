import React, { Component } from 'react'
import _ from 'lodash'
import { AppState, AsyncStorage, Linking } from 'react-native'
import { addNavigationHelpers } from 'react-navigation'
import {
  locationInterval,
  updateCycle,
  maximumLocation,
  POLLING_INTERVAL,
  FCM_TOPIC_RESTART_SHIFT
} from '../config/uiconfig'
import BackgroundGeolocation from 'react-native-mauron85-background-geolocation'
import Permissions from 'react-native-permissions'
import SystemSetting from 'react-native-system-setting'
import firebase from 'react-native-firebase'
import Sound from 'react-native-sound'
import BackgroundTimer from 'react-native-background-timer'

import RootStack from '../config/router'
import { setNotiId } from '../config/storage'
import { driverApi } from '../config/hostname'

class App extends Component {
  state = {
    latestUpdate: new Date().getTime(),
    playingNewTripSound: false
  }

  async getToken() {
    console.log('loading FCM token from storage ...')
    let fcmToken = await AsyncStorage.getItem('fcmToken')
    if (!fcmToken) {
      console.log('getting FCM token from firebase ...')
      fcmToken = await firebase.messaging().getToken()
      if (fcmToken) {
        console.log('got FCM token from firebase')
        console.log('saving FCM token to storage ...')
        await AsyncStorage.setItem('fcmToken', fcmToken)
      } else {
        console.log('no FCM token from firebase!')
      }
    }
    console.log('current FCM token:', fcmToken)
    return fcmToken
  }

  async setPlayerId(fcmToken) {
    if (fcmToken) {
      setNotiId({ userId: fcmToken })
      this.props.loginSavePlayerId(fcmToken)
      console.log('done - setNotiId(fcmToken)')
    } else {
      setNotiId({})
    }
  }

  subscribeTopics() {
    firebase.messaging().subscribeToTopic(FCM_TOPIC_RESTART_SHIFT)
  }

  playSound(sound) {
    SystemSetting.setVolume(1.0, {
      type: 'music',
      playSound: false,
      showUI: false
    })
    sound.play(_ => {})
  }

  onMessageListener = message => {
    // console.log({ message })
    const data = message._data
    console.log({ data })

    const { event } = data || {}
    switch (event) {
      case 'new-trip':
        this.playSound(this.newTripSound)
        return this.props.checkIn(data)

      case 'cancel-trip':
        if (this.newTripSound) this.newTripSound.stop()
        this.playSound(this.cancelTripSound)
        break

      case 'change-trip-info':
        this.playSound(this.changeTripInfoSound)
        break

      case 'reset-state':
        this.playSound(this.resetStateSound)
        break
    }

    // this.showLocalNotification(message._messageId, data)

    this.props.tripReceiveNoti(data)
  }

  showLocalNotification(messageId, data) {
    const { event, title, body } = data
    const notification = new firebase.notifications.Notification()
      .setNotificationId(messageId)
      .setTitle(title)
      .setBody(body)
      .setData(data)
    notification.android.setChannelId(event)
    notification.android.setPriority(firebase.notifications.Android.Priority.Max)
    firebase.notifications().displayNotification(notification)
  }

  createNotificationChannel(id, name, description, sound) {
    const newChannel = new firebase.notifications.Android.Channel(
      id,
      name,
      firebase.notifications.Android.Importance.Max
    )
      .setDescription(description)
      .setSound(sound)
    firebase.notifications().android.createChannel(newChannel)
  }

  createSounds = () => {
    Sound.setCategory('Playback')

    const newTripSoundPromise = new Promise((resolve, reject) => {
      this.newTripSound = new Sound('assign.mp3', Sound.MAIN_BUNDLE, error => {
        if (error) reject(error)
        resolve('created newTripSound')
      })
    })

    const cancelTripSoundPromise = new Promise((resolve, reject) => {
      this.cancelTripSound = new Sound('cancel.mp3', Sound.MAIN_BUNDLE, error => {
        if (error) reject(error)
        resolve('created newTripSound')
      })
    })

    const changeTripInfoSoundPromise = new Promise((resolve, reject) => {
      this.changeTripInfoSound = new Sound('change.mp3', Sound.MAIN_BUNDLE, error => {
        if (error) reject(error)
        resolve('created newTripSound')
      })
    })

    const resetStateSoundPromise = new Promise((resolve, reject) => {
      this.resetStateSound = new Sound('reset.mp3', Sound.MAIN_BUNDLE, error => {
        if (error) reject(error)
        resolve('created newTripSound')
      })
    })
    return Promise.all([
      newTripSoundPromise,
      cancelTripSoundPromise,
      changeTripInfoSoundPromise,
      resetStateSoundPromise
    ])
  }

  getDriverState = async token => {
    try {
      const driverState = await fetch(driverApi + 'driver-state', {
        method: 'POST',
        headers: {
          Accept: 'application/json, text/plain, */*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          token
        })
      })

      return driverState.json()
    } catch (err) {
      throw new Error(err)
    }
  }

  pollingTripEventListeners = () => {
    const period = POLLING_INTERVAL * 1000
    console.log(`set polling interval to ${POLLING_INTERVAL} seconds`)

    this.intervalId = BackgroundTimer.setInterval(() => {
      this.tripEventListeners()
    }, period)
  }

  async componentDidMount() {
    this.requestPermission()

    const fcmToken = await this.getToken()
    await this.setPlayerId(fcmToken)
    await this.createSounds()
    this.subscribeTopics()
    this.pollingTripEventListeners()
    this.setupBackgroundLocation()

    AppState.addEventListener('change', this.handleAppStateChange)
  }

  releaseSound(sound) {
    if (sound) sound.release()
  }

  componentWillUnmount() {
    // this.onTokenRefreshListener()
    this.notificationDisplayedListener()
    this.notificationListener()
    this.notificationOpenedListener()
    this.messageListener()
    this.releaseSound(this.newTripSound)
    this.releaseSound(this.cancelTripSound)
    this.releaseSound(this.changeTripInfoSound)
    this.releaseSound(this.resetStateSound)

    BackgroundGeolocation.events.forEach(event =>
      BackgroundGeolocation.removeAllListeners(event)
    )
    AppState.removeEventListener('change', this.handleAppStateChange)
  }

  tripEventListeners = async () => {
    console.log('polling driver state ...')
    try {
      const {
        token,
        trip: { state: clientState, tripInfo: clientTripInfo }
      } = this.props
      const { playingNewTripSound } = this.state

      if (!token) return

      const { state: serverState, trip: serverTripInfo } = await this.getDriverState(
        token
      )

      const tripInfoChange = !_.isEqual(clientTripInfo, serverTripInfo)
      const tripRevieveEvent = clientState !== 'assigned' && serverState === 'assigned'
      const tripEditEvent = !!serverTripInfo && !tripRevieveEvent
      const tripCancelEvent =
        clientState !== serverState &&
        (serverState === 'standby' || serverState === 'on-queue')
      const resetStateEvent =
        (clientState === 'on-queue' || clientState === 'standby') &&
        serverState === 'on-line'

      if (tripInfoChange) {
        if (tripEditEvent) {
          if (clientState === 'assigned') {
            if (playingNewTripSound) this.stopNewTripSound()

            this.playNewTripSound()
          }

          this.playSound(this.changeTripInfoSound)
        }
        if (tripCancelEvent) {
          this.playSound(this.cancelTripSound)
        }

        this.props.tripReceiveNoti()
      }

      if (resetStateEvent) {
        this.playSound(this.resetStateSound)
        this.props.tripReceiveNoti()
      }
    } catch (err) {
      console.log(`cant get driver state: ${err}`)
    }
  }

  playNewTripSound = async () => {
    const { playingNewTripSound } = this.state

    if (!playingNewTripSound) {
      await this.createSounds()
      this.setState({
        playingNewTripSound: true
      })
      this.playSound(this.newTripSound)
    }
  }

  stopNewTripSound = () => {
    this.setState({
      playingNewTripSound: false
    })
    this.newTripSound.stop()
  }

  componentWillReceiveProps = nextProps => {
    const { trip } = this.props

    if (nextProps.trip.state !== trip.state) {
      if (nextProps.trip.state === 'assigned' && !nextProps.playingNewTripSound) {
        this.playNewTripSound()
      }

      if (
        trip.state === 'assigned' &&
        (nextProps.trip.state === 'accepted' ||
          nextProps.trip.state === 'rejected' ||
          nextProps.trip.state === 'standby' ||
          nextProps.trip.state === 'on-queue')
      ) {
        this.stopNewTripSound()
      }
    }
  }

  setupBackgroundLocation = () => {
    BackgroundGeolocation.configure({
      desiredAccuracy: 10,
      stationaryRadius: 5,
      distanceFilter: 5,
      debug: false,
      startOnBoot: true,
      stopOnTerminate: true,
      locationProvider: BackgroundGeolocation.ACTIVITY_PROVIDER,
      notificationTitle: 'Driver Apps',
      notificationText: 'GPS is On',
      interval: locationInterval,
      fastestInterval: locationInterval,
      activitiesInterval: locationInterval,
      stopOnStillActivity: false,
      maxLocations: maximumLocation
    })

    BackgroundGeolocation.on('location', location => {
      const { token } = this.props
      const now = new Date().getTime()
      const { latestUpdate } = this.state
      this.props.processSetCurrentLocation(location)
      if (token && now - latestUpdate > updateCycle) {
        BackgroundGeolocation.getLocations(locations => {
          let filteredLocation = _.filter(locations, function(o) {
            if (o.time > latestUpdate) {
              return true
            } else {
              return false
            }
          })
          console.log('updateLocationArraynew ', new Date().toTimeString())
          this.updateLocationArray(token, filteredLocation)
          this.setState({
            latestUpdate: locations[locations.length - 1].time
          })
        })
      }
    })

    BackgroundGeolocation.on('stationary', stationaryLocation => {
      // console.log('> stationary location:', stationaryLocation)
    })

    BackgroundGeolocation.on('error', error => {
      // console.log('[ERROR] BackgroundGeolocation error: ', error)
    })

    BackgroundGeolocation.on('start', () => {
      // console.log('[INFO] BackgroundGeolocation service has been started')
    })

    BackgroundGeolocation.on('stop', () => {
      // console.log('[INFO] BackgroundGeolocation service has been stopped')
    })

    BackgroundGeolocation.on('background', () => {
      // console.log('[INFO] App is in background')
    })

    BackgroundGeolocation.on('foreground', () => {
      // console.log('[INFO] App is in foreground')
    })

    BackgroundGeolocation.checkStatus(status => {
      if (!status.isRunning) {
        BackgroundGeolocation.start() //triggers start on start event
      }
    })
  }

  requestPermission = () => {
    Permissions.request('location').then(response => {})
    Permissions.request('storage').then(response => {})
    Permissions.request('camera').then(response => {})
  }

  handleAppStateChange = appState => {
    if (appState === 'active') {
      this.requestPermission()
      BackgroundGeolocation.start()
    }
  }

  updateLocationArray = async (token, locations) => {
    fetch(driverApi + 'v2/log-location', {
      method: 'POST',
      headers: {
        Accept: 'application/json, text/plain, */*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        token: token,
        locations: locations
      })
    })
      .then(response => response.json())
      .then(responseJson => {
        console.log(responseJson)
      })
      .catch(error => {})
  }

  render() {
    const { dispatch, nav } = this.props
    return <RootStack navigation={addNavigationHelpers({ dispatch, state: nav })} />
  }
}

export default App
