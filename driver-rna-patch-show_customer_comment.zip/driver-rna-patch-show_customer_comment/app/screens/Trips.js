import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { AppState, Text, ImageBackground, View, Alert, TouchableOpacity } from 'react-native'
import { Button, Icon } from 'react-native-elements'
import { errorTranslator } from '../config/error'
import {
  loadToken,
  setTrip,
  loadNotiId,
  setWaitAccept,
  loadWaitAccept,
  loadDirectionApiCallCount
} from '../config/storage'
import {
  setInitialState,
  tripApiToggle,
  tripApiReadyRequest,
  tripCountDown,
  tripStopTimer,
  navigateScreen,
  tripApiAcceptRequest,
  tripReceiveNoti,
  tripOpenNoti,
  clearError,
  tripStopWaitingForAccept,
  tripClearState
} from '../state/paco/trip'
import timer from 'react-native-timer'
import OneMinuteModal from './components/OneMinuteModal'
import DeviceInfo from 'react-native-device-info'

import { assign, accept, reject, purge } from '../state/v2/newTrip'
import { FCM_TOPIC_RESTART_SHIFT } from '../config/uiconfig';

class Trips extends React.Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      appState: AppState.currentState
    }
  }

  componentWillMount(){
    this.props.setInitialState()
  }

  async componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange)
    this.setState({
      directionApiCallCount: await loadDirectionApiCallCount()
    })
  }

  acceptJob = () => {
    this.props.acceptNewTrip()
    this.props.tripApiAcceptRequest(true).then(done => {
      if (done) {
        this.props.navigateScreen('JobProcess')
      } else {
        this.rejectJob()
      }
    })
  }

  rejectJob = () => {
    this.props.rejectNewTrip()
    this.props.tripApiAcceptRequest(false).then(() => {
      this.props.tripApiReadyRequest()
      this.props.tripApiToggle()
    })
  }

  componentWillReceiveProps = nextProps => {
    let state = ''
    if (this.props.errorMessage !== nextProps.errorMessage && nextProps.errorMessage !== '') {
      Alert.alert(
        'เกิดข้อผิดพลาด',
        errorTranslator(nextProps.errorMessage),
        [
          {
            text: 'รับทราบ',
            onPress: () => {
              this.props.clearError()
            }
          }
        ],
        { cancelable: false }
      )
    }
  }

  componentWillUnmount() {
    AppState.removeEventListener('change', this._handleAppStateChange)
    timer.clearInterval('countDown')
  }

  _handleAppStateChange = nextAppState => {
    let stillInThisScreen = true
    if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
      try {
        this.props.tripOpenNoti({}) // fake noti to refresh state
        stillInThisScreen = false
      } catch (err) {
        // TODO: show warning to user
        console.log('@Trip: getting state error', err)
      }
    }

    if (stillInThisScreen) {
      this.setState({
        appState: nextAppState
      })
    }
  }

  renderTextandColor() {
    let readyText = 'กำลังโหลดสถานะ...'
    let readyColor = '#56add8'
    const { fetching, state } = this.props
    // console.log(fetching, state)
    if (!fetching) {
      switch (state) {
        case 'on-queue':
        case 'standby':
          readyText = 'พร้อมรับงาน'
          readyColor = '#56add8'
          return {
            readyText,
            readyColor
          }
        case 'on-line':
          readyText = 'ไม่พร้อมรับงาน'
          readyColor = '#d7d3d3'
          return {
            readyText,
            readyColor
          }
        case 'evaluated':
          readyText = 'เพิ่งประเมินเสร็จ'
          readyColor = '#d7d3d3'
          return {
            readyText,
            readyColor
          }
        case 'assigned':
          readyText = 'ได้รับงาน'
          readyColor = '#56add8'
          return {
            readyText,
            readyColor
          }
        case 'rejected':
          readyText = 'ถูกปฎิเสธ'
          readyColor = '#d7d3d3'
          return {
            readyText,
            readyColor
          }
        case 'cancelled':
          readyText = 'ถูกยกเลิก'
          readyColor = '#d7d3d3'
          return {
            readyText,
            readyColor
          }
        case 'error':
          readyText = 'กดอีกครั้งเพื่ออัพเดทสถานะ'
          readyColor = '#d7d3d3'
          return {
            readyText,
            readyColor
          }
      }
    } else {
      switch (state) {
        case 'on-queue':
        case 'standby':
          readyText = 'กำลังโหลดสถานะ...'
          readyColor = '#56add8'
          return {
            readyText,
            readyColor
          }
        case 'on-line':
          readyText = 'กำลังโหลดสถานะ...'
          readyColor = '#d7d3d3'
          return {
            readyText,
            readyColor
          }
        case 'error':
          readyText = 'กดอีกครั้งเพื่ออัพเดทสถานะ'
          readyColor = '#d7d3d3'
          return {
            readyText,
            readyColor
          }
      }
    }
    return {
      readyText,
      readyColor
    }
  }

  render() {
    const { readyText, readyColor } = this.renderTextandColor()
    const { directionApiCallCount } = this.state

    return (
      <ImageBackground
        source={require('app/asset/image/stripe2.png')}
        resizeMode="cover"
        style={{
          flex: 1,
          width: null,
          height: null
        }}>
        <Text
          style={{
            padding: 20
          }}>
          Build: {`${this.props.buildBersion}\n`}
          Version: {`${this.props.appVersion}\n`}
          State: {`${this.props.state}\n`}
          Direction API Calls: {`${directionApiCallCount}\n`}
          Shift Reset Topic: {`${FCM_TOPIC_RESTART_SHIFT}\n`}
          Last trip: {`${this.props.lastTripInfo && this.props.lastTripInfo.runningNumber || this.props.lastTripId || '-'}\n`}
        </Text>
        {this.props.lastTripId ?
          <Button
            large
            icon={{ name: 'flight-land', size: 40 }}
            fontFamily="dbhelvethaicax_bd"
            fontSize={30}
            title='กลับฐานทัพ'
            // onPress={this.props.navigateScreen.bind(this, 'TransportCost')}
            onPress={
              () => {
                if(this.props.lastTripInfo){
                  Alert.alert(
                    'ตรวจสอบทริปก่อนอัพโหลด',
                    ' ลูกค้าชื่อ ' + (this.props.lastCustomer && this.props.lastCustomer.name)
                    + ' \nจาก ' + (this.props.lastFromLocation && this.props.lastFromLocation.name)
                    + ' \nถึง ' + (this.props.lastToLocation && this.props.lastToLocation.name),
                    [
                      { text: 'ยกเลิก', onPress: () => console.log('Cancel Pressed'), style: 'cancel' },
                      {
                        text: 'รับทราบ', onPress: () => {
                          this.props.navigateScreen('TransportCost')
                        }
                      },
                    ],
                    { cancelable: false }
                  )
                }
                else{
                  this.props.navigateScreen('TransportCost')
                }
                
              }
            }
          />
          : null
        }
        <View
          style={{
            flex: 1
          }}>
          <View
            style={{
              position: 'absolute',
              bottom: -15,
              left: -15,
              width: 124,
              height: 124,
              borderRadius: 124 / 2,
              backgroundColor: 'rgba(30, 30, 30,0.1)',
              zIndex: 1,
              justifyContent: 'center',
              alignItems: 'center'
            }}>
            <View
              style={{
                width: 104,
                height: 104,
                borderRadius: 104 / 2,
                backgroundColor: 'rgba(39, 38, 38,0.98)',
                zIndex: 1,
                justifyContent: 'center',
                alignItems: 'center'
              }}
            />
          </View>
          <View
            style={{
              flex: 1,
              flexDirection: 'row',
              position: 'absolute',
              bottom: 0,
              justifyContent: 'center'
            }}>
            <Button
              large
              buttonStyle={{
                backgroundColor: 'rgba(30, 30, 30,0.1)',
                justifyContent: 'flex-start',
                height: '100%'
              }}
              containerViewStyle={{
                flex: 1,
                marginLeft: 90,
                marginRight: 0,
                height: 90
              }}
            />
          </View>
          <View
            style={{
              position: 'absolute',
              bottom: 17,
              left: 17,
              width: 60,
              height: 60,
              borderRadius: 60 / 2,
              backgroundColor: '#000000',
              zIndex: 2,
              justifyContent: 'center',
              alignItems: 'center'
            }}>
            <TouchableOpacity onPress={this.props.tripApiToggle}>
              <Icon name="power-off" type="font-awesome" color={readyColor} size={42} />
            </TouchableOpacity>
          </View>
          <View
            style={{
              flex: 1,
              flexDirection: 'row',
              position: 'absolute',
              bottom: 0,
              justifyContent: 'center',
              padding: 0,
              zIndex: 1
            }}>
            <Button
              accessibilityLabel="toggleReady"
              onPress={_ => {}}
              title={readyText}
              fontSize={25}
              fontFamily="dbhelvethaicax_bd"
              buttonStyle={{
                backgroundColor: '#272626',
                justifyContent: 'flex-start',
                height: '100%',
                paddingTop: 5
              }}
              textStyle={{
                marginLeft: 100,
                zIndex: 1,
                color: readyColor
              }}
              containerViewStyle={{
                flex: 1,
                marginLeft: 0,
                marginRight: 0,
                height: 80
              }}
            />
          </View>
        </View>
        {this.props.waitingForAccept ? <OneMinuteModal
          acceptJob={this.acceptJob}
          tripInfo={this.props.tripInfo}
          rejectJob={this.rejectJob}
          stopsLocation={this.props.stopsLocation}
          state={this.props.state}
          waitingForAccept={this.props.waitingForAccept}
          countTime={this.props.countTime}
          pickupDate={this.props.pickupDate}
          fromLocation={this.props.fromLocation}
          toLocation={this.props.toLocation}
          fetching={this.props.fetching}
        /> : null}
      </ImageBackground>
    )
  }
}

Trips.propTypes = {
  ready: PropTypes.func
}

const mapStateToProp = state => ({
  state: state.trip.state,
  tripInfo: state.trip.tripInfo,
  lastTripId: state.trip.lastTripId,
  lastTripInfo: state.trip.lastTripInfo,
  lastCustomer: state.trip.lastTripInfo && state.trip.lastTripInfo.customer,
  lastFromLocation: state.trip.lastTripInfo && state.trip.lastTripInfo.fromLocation,
  lastToLocation:state.trip.lastTripInfo && state.trip.lastTripInfo.toLocation,
  tripId: state.trip.tripId,
  customer: state.trip.tripInfo && state.trip.tripInfo.customer,
  lastStateChanged: state.trip.lastStateChanged,
  stopsLocation: state.trip.tripInfo && state.trip.tripInfo.stopsLocation,
  pickupDate: state.trip.tripInfo && state.trip.tripInfo.pickupDate,
  fromLocation: state.trip.tripInfo && state.trip.tripInfo.fromLocation,
  toLocation: state.trip.tripInfo && state.trip.tripInfo.toLocation,
  fetching: state.trip.fetching,
  countTime: state.trip.countTime,
  waitingForAccept: state.trip.waitingForAccept,
  appVersion: DeviceInfo.getVersion(),
  buildBersion: DeviceInfo.getBuildNumber(),
  errorMessage: state.trip.errorMessage,
})

const mapDispatchToProp = dispatch => {
  return {
    setInitialState: () => dispatch(setInitialState()),
    tripApiToggle: () => dispatch(tripApiToggle()),
    tripResume: () => dispatch(tripResume()),
    tripCountDown: () => dispatch(tripCountDown()),
    tripStopTimer: () => dispatch(tripStopTimer()),
    tripApiReadyRequest: () => dispatch(tripApiReadyRequest()),
    navigateScreen: name => dispatch(navigateScreen(name)),
    tripApiAcceptRequest: yes => dispatch(tripApiAcceptRequest(yes)),
    tripReceiveNoti: (notification) => dispatch(tripReceiveNoti(notification)),
    tripOpenNoti: (openResult) => dispatch(tripOpenNoti(openResult)),
    clearError: () => dispatch(clearError()),
    tripStopWaitingForAccept: () => dispatch(tripStopWaitingForAccept()),
    tripClearState: () => dispatch(tripClearState()),

    acceptNewTrip: ()=>dispatch(accept()),
    rejectNewTrip: ()=>dispatch(reject()),
    purgeNewTrip: ()=>dispatch(purge())
  }
}

export default connect(mapStateToProp, mapDispatchToProp)(Trips)