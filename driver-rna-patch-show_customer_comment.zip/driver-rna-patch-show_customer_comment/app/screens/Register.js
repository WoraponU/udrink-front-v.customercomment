import React from 'react'
import { connect } from 'react-redux'
import { StyleSheet, Text, View, Image, ImageBackground, Keyboard, Picker, Dimensions, Alert } from 'react-native'
import { FormLabel, FormInput, FormValidationMessage, Button, Icon, CheckBox, colors } from 'react-native-elements'

import { driverApi } from '../config/hostname'
import { fetchInfo2, getState2 } from '../config/api'
import {
  setLogin,
} from '../config/storage'
import { navigateToScreen } from '../state/paco/nav'
import { errorTranslator } from '../config/error'

let { width } = Dimensions.get('window')
let options = {
  title: 'Select Avatar',
  customButtons: [
    { name: 'fb', title: 'Choose Photo from Facebook' },
  ],
  storageOptions: {
    skipBackup: true,
    path: 'images'
  }
}

class Register extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.state = {
      controlWidth: width - 50,
      logoheight: 150,
      keyboard: false,
      avatarSource: '',
      image: 'none',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: '',
      gear: [],
      manualGear: false,
      autoGear: false,
      supercar: false,
      gender: 'male',
      registering: false
    }
  }

  async componentWillMount() {
    this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this._keyboardDidShow.bind(this))
    this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this._keyboardDidHide.bind(this))
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove()
    this.keyboardDidHideListener.remove()
  }

  _keyboardDidShow() {
    // setTimeout(() => {
      this.setState({
        logoheight: 50,
        keyboard: true
      })
    // }, 200)
  }

  _keyboardDidHide() {
    // setTimeout(() => {
      this.setState({
        logoheight: 150,
        keyboard: false
      })
    // }, 200)
  }

  onSelectedItemsChange = selectedItems => {
    this.setState({ selectedItems });
  }

  selectImage() {
    
  }

  handleRegister = async () => {
    Keyboard.dismiss()
    let gearObject = { manual: this.state.manualGear, auto: this.state.autoGear, supercar: this.state.supercar }
    let gearArray = []
    for (let key in gearObject) {
      if (gearObject[key] == true) {
        gearArray.push(key)
      }
    }
    this.setState({
      registering: true
    })
    try {
      let responseJson = await fetchInfo2(driverApi + 'v2/driver-register',
        {
          profile: {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            phone: this.state.phone,
            email: this.state.email,
            password: this.state.password,
            gender: this.state.gender,
            transmission: gearArray
          }
        })

      if (responseJson) {
        this.setState({
          registering: false
        })
      }
      if (responseJson._id) {
        await setLogin(this.state.email, this.state.password)
        this.props.navigateToScreen('Login')
      }
    }
    catch (error) {
      Alert.alert(
        'เกิดข้อผิดพลาด',
        errorTranslator(error),
        [
          {
            text: 'รับทราบ', onPress: () => {
              this.setState({
                registering: false
              })
            }
          },
        ],
        { cancelable: false }
      )
    }
  }

  render() {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: '#d5d4d4'
        }}
      >
        <ImageBackground source={require('../asset/image/stripe2.png')}
          resizeMode='cover'
          style={{
            flex: this.state.keyboard ? 30 : 50,
            width: '100%',
            height: this.state.keyboard ? '0%' : '70%',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {this.state.image == 'loaded' ?
            <Image source={this.state.avatarSource}
              style={{
                width: this.state.keyboard ? 0 : 60,
                height: this.state.keyboard ? 0 : 60
              }} />
            : <Icon
              name='user-o'
              type='font-awesome'
              size={this.state.keyboard ? 0 : 60}
              color='#dad9d9'
              backgroundColor='#FFFFFF'
              style={{
                padding: this.state.keyboard ? 0 : 20,
                borderRadius: this.state.keyboard ? 0 : 64,
                marginVertical: this.state.keyboard ? 0 : 20,
                justifyContent: 'flex-end',
                alignItems: 'center',
              }}
              onPress={
                () => {
                  this.selectImage()
                }
              }
            />}
          <View
            style={{
              flex: this.state.keyboard ? 20 : 60,
              justifyContent: 'flex-end',
              alignItems: 'center',
            }}
          >
            <View
              style={{
                flexDirection: 'row',
                marginVertical: this.state.keyboard ? 3 : 5,
                width: this.state.controlWidth
              }}
            >
              <View
                style={{
                  width: this.state.controlWidth / 2
                }}
              >
                <FormInput
                  underlineColorAndroid={0}
                  containerStyle={{
                    backgroundColor: '#FFF',
                    borderRadius: 3,
                    maxHeight: this.state.keyboard ? 30 : 40
                  }}
                  inputStyle={{
                    width: this.state.controlWidth / 3,
                    marginHorizontal: 3,
                    fontSize: this.state.keyboard ? 15 : 20,
                  }}
                  placeholder={'ชื่อ'}
                  placeholderTextColor='#929191'
                  value={this.state.firstName}
                  onChangeText={(val) => { this.setState({ firstName: val }) }}
                />
              </View>
              <View
                style={{
                  width: this.state.controlWidth / 2
                }}
              >
                <FormInput
                  underlineColorAndroid={0}
                  containerStyle={{
                    backgroundColor: '#FFF',
                    borderRadius: 3,
                    maxHeight: this.state.keyboard ? 30 : 40
                  }}
                  inputStyle={{
                    width: this.state.controlWidth / 3,
                    marginHorizontal: 3,
                    fontSize: this.state.keyboard ? 15 : 20,
                  }}
                  placeholder={'นามสกุล'}
                  placeholderTextColor='#929191'
                  value={this.state.lastName}
                  onChangeText={(val) => { this.setState({ lastName: val }) }}
                />
              </View>
            </View>
            <View
              style={{
                marginVertical: this.state.keyboard ? 3 : 5,
                width: this.state.controlWidth
              }}
            >
              <FormInput
                underlineColorAndroid={0}
                containerStyle={{
                  backgroundColor: '#FFF',
                  borderRadius: 3,
                  paddingLeft: 5,
                  maxHeight: this.state.keyboard ? 30 : 40
                }}
                inputStyle={{
                  fontSize: this.state.keyboard ? 15 : 20,
                }}
                placeholder={'อีเมล'}
                placeholderTextColor='#929191'
                value={this.state.email}
                onChangeText={(val) => { this.setState({ email: val }) }}
              />
            </View>
          </View>
        </ImageBackground>
        <View
          style={{
            flex: 60,
            justifyContent: 'flex-start',
            alignItems: 'center',
          }}
        >
          <View
            style={{
              marginVertical: this.state.keyboard ? 3 : 5,
              width: this.state.controlWidth
            }}
          >
            <FormInput
              underlineColorAndroid={0}
              containerStyle={{
                backgroundColor: '#FFF',
                borderRadius: 3,
                paddingLeft: 5,
                maxHeight: this.state.keyboard ? 30 : 40
              }}
              inputStyle={{
                fontSize: this.state.keyboard ? 15 : 20,
              }}
              placeholder={'เบอร์โทร'}
              placeholderTextColor='#929191'
              value={this.state.phone}
              onChangeText={(val) => { this.setState({ phone: val }) }}
            />
          </View>
          <View
            style={{
              marginVertical: this.state.keyboard ? 3 : 5,
              width: this.state.controlWidth
            }}
          >
            <FormInput
              underlineColorAndroid={0}
              containerStyle={{
                backgroundColor: '#FFF',
                borderRadius: 3,
                paddingLeft: 5,
                maxHeight: this.state.keyboard ? 30 : 40
              }}
              inputStyle={{
                fontSize: this.state.keyboard ? 15 : 20,
              }}
              placeholder={'รหัสผ่าน'}
              placeholderTextColor='#929191'
              secureTextEntry={true}
              value={this.state.password}
              onChangeText={(val) => { this.setState({ password: val }) }}
            />
          </View>
          <View
            style={{
              marginVertical: this.state.keyboard ? 3 : 5,
              width: this.state.controlWidth
            }}
          >
            <FormInput
              underlineColorAndroid={0}
              containerStyle={{
                backgroundColor: '#FFF',
                borderRadius: 3,
                paddingLeft: 5,
                maxHeight: this.state.keyboard ? 30 : 40
              }}
              inputStyle={{
                fontSize: this.state.keyboard ? 15 : 20,
              }}
              placeholder={'ยืนยันรหัสผ่าน'}
              placeholderTextColor='#929191'
              secureTextEntry={true}
              value={this.state.confirmPassword}
              onChangeText={(val) => { this.setState({ confirmPassword: val }) }}
            />
          </View>
          <View
            style={{
              marginVertical: this.state.keyboard ? 3 : 5,
              width: this.state.controlWidth,
              flexDirection: 'row',
              marginHorizontal: 10,
            }}
          >
            <View
              style={{
                flex: 1,
                backgroundColor: '#FFFFFF',
                borderRadius: 3,
                marginHorizontal: 15,
                maxHeight: this.state.keyboard ? 30 : 40
              }}
            >
              <Picker
                style={{
                  borderRadius: 3,
                  color: '#929191',
                  maxHeight: this.state.keyboard ? 30 : 40,
                }}
                selectedValue={this.state.gender}
                onValueChange={(itemValue, itemIndex) => this.setState({ gender: itemValue })}>
                <Picker.Item label="ผู้ชาย" value="male" />
                <Picker.Item label="ผู้หญิง" value="female" />
              </Picker>
            </View>
          </View>
          <View
            style={{
              maxHeight: this.state.keyboard ? 30 : 40,
              width: this.state.controlWidth,
              flexDirection: 'row',
              marginLeft: 15,
              marginRight: 15,
            }}
          >
            <CheckBox
              containerStyle={{
                backgroundColor: 'rgba(255, 255, 255, 0)',
                borderWidth: 0,
                marginLeft: 15,
                marginRight: 0,
                padding: 0
              }}
              textStyle={{
                fontSize: 10,
                color: '#929191'
              }}
              title='เกียร์ธรรมดา'
              checked={this.state.manualGear}
              onPress={
                () => {
                  this.setState({
                    manualGear: !this.state.manualGear
                  })
                }
              }
            />
            <CheckBox
              center
              containerStyle={{
                backgroundColor: 'rgba(255, 255, 255, 0)',
                borderWidth: 0,
                marginLeft: 0,
                marginRight: 0,
                padding: 0
              }}
              textStyle={{
                fontSize: 10,
                color: '#929191'
              }}
              title='เกียร์ออโต้'
              checked={this.state.autoGear}
              onPress={
                () => {
                  this.setState({
                    autoGear: !this.state.autoGear
                  })
                }
              }
            />
            <CheckBox
              right
              containerStyle={{
                backgroundColor: 'rgba(255, 255, 255, 0)',
                borderWidth: 0,
                marginLeft: 0,
                marginRight: 0,
                padding: 0
              }}
              textStyle={{
                fontSize: 10,
                color: '#929191'
              }}
              title='ซุปเปอร์คาร์'
              checked={this.state.supercar}
              onPress={
                () => {
                  this.setState({
                    supercar: !this.state.supercar
                  })
                }
              }
            />
          </View>
          <View
            style={{
              marginVertical: 5,
              width: this.state.controlWidth
            }}
          >
            <Button
              large
              raise
              disabled={this.state.registering}
              icon={this.state.registering ? { name: 'cached' } : null}
              onPress={
                () => {
                  if (this.state.password == this.state.confirmPassword) {
                    this.handleRegister()
                  }
                  else {
                    Alert.alert(
                      'เกิดข้อผิดพลาด',
                      'กรุณากรอก password ให้ตรงกัน',
                      [
                        { text: 'OK', onPress: () => console.log('OK Pressed') },
                      ],
                      { cancelable: false }
                    )
                  }
                }
              }
              fontFamily='dbhelvethaicax_bd'
              fontSize={20}
              containerViewStyle={{
                justifyContent: 'center',
                alignItems: 'center',
                marginHorizontal: 30,
                marginVertical: 3
              }}
              buttonStyle={{
                height: 30,
                width: '100%',
                borderRadius: 3,
                backgroundColor: '#58aee2',
              }}
              title='เสร็จสิ้น'
            />
            <Button
              disabled={this.state.registering}
              icon={this.state.registering ? { name: 'cached' } : null}
              title="กลับไป Login"
              fontFamily='dbhelvethaicax_bd'
              fontSize={20}
              containerViewStyle={{
                justifyContent: 'center',
                alignItems: 'center',
                marginHorizontal: 30,
                marginVertical: 3
              }}
              buttonStyle={{
                height: 30,
                width: '100%',
                borderRadius: 3,
                backgroundColor: '#009688',
              }}
              onPress={
                () => {
                  this.props.navigateToScreen('Login')
                }
              }
            />
          </View>
        </View>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  footer: {

  }
})

const mapStateToProp = state => ({

})

const mapDispatchToProp = (dispatch) => {
  return {
    navigateToScreen: (name) => dispatch(navigateToScreen(name)),
  }
}

export default connect(mapStateToProp, mapDispatchToProp)(Register)
