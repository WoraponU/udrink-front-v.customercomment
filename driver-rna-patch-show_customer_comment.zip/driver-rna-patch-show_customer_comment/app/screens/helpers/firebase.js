import _ from 'lodash'
import { AppState, Alert, AsyncStorage } from 'react-native'
import firebase from 'react-native-firebase'
import { setNotiId } from '../../config/storage'

export const getFCMToken = async _ => {
  console.log('loading FCM token from storage ...')
  let fcmToken = await AsyncStorage.getItem('fcmToken')
  if (!fcmToken) {
    console.log('getting FCM token from firebase ...')
    fcmToken = await firebase.messaging().getToken()
    if (fcmToken) {
      console.log('got FCM token from firebase')
      console.log('saving FCM token to storage ...')
      await AsyncStorage.setItem('fcmToken', fcmToken)
    } else {
      console.log('no FCM token from firebase!')
    }
  }
  console.log('current FCM token:', fcmToken)
  return fcmToken
}
