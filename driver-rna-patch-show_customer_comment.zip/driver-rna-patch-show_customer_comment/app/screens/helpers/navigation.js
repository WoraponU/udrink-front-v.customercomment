import { NavigationActions } from 'react-navigation'

export const replaceSecondScreenAction = (newSecondScreenName, params) =>
  NavigationActions.reset({
    index: 1,
    actions: [
      NavigationActions.navigate({ routeName: 'Login' }),
      NavigationActions.navigate({
        routeName: newSecondScreenName,
        ...(params && { params })
      })
    ]
  })
