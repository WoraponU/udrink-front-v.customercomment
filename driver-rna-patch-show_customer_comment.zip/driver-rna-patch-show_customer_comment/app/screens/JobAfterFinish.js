import React from 'react'
import { connect } from 'react-redux'
import {
  TouchableOpacity,
  Text,
  TextInput,
  View,
  Image,
  ImageBackground,
  ScrollView,
  Keyboard,
  Alert
} from 'react-native'
import { ButtonGroup, Button, Icon, FormLabel, FormInput } from 'react-native-elements'
import StarRating from 'react-native-star-rating'

import { driverApi } from '../config/hostname'
import { setToken, loadToken, setTripId, loadTrip } from '../config/storage'
import { fetchInfo2, getState2 } from '../config/api'
import moment from 'moment'
import { errorTranslator } from '../config/error'
import { navigateToScreen } from '../state/paco/nav'

class JobAfterFinish extends React.Component {
  constructor(props, context) {
    super(props, context)

    this.state = {
      token: '',
      tripId: '',
      state: '',
      payment: '',
      colorMain: 'rgba(174,209,163,0.5)',
      colorSub: 'rgba(120,179,130,0.5)',
      priceNet: '...',
      remark: '',
      detailShow: true,
      starCount: 0,
      evaluated: false,
      priceDistance: '',
      distance: 0,
      waitSeconds: 0
    }
  }

  componentDidMount = async () => {
    // Keyboard.dismiss()
    try {
      let token = await loadToken()
      let responseStore = await getState2(token)

      if (responseStore.state) {
        this.setState({
          token: token,
          tripId: responseStore.tripId,
          state: responseStore.state,
          customerName: responseStore.trip.customer.name,
          priceNet: responseStore.trip.priceNet,
          payment: responseStore.trip.customer.paymentType,
          waitCharges: responseStore.trip.waitCharges,
          waitSeconds: responseStore.trip.waitSeconds,
          priceDistance: responseStore.trip.priceDistance,
          distance: responseStore.trip.distance
        })
      }
      this.keyboardDidShowListener = Keyboard.addListener(
        'keyboardDidShow',
        this._keyboardDidShow.bind(this)
      )
      this.keyboardDidHideListener = Keyboard.addListener(
        'keyboardDidHide',
        this._keyboardDidHide.bind(this)
      )
    } catch (e) {
      let alertText = getError(e)

      Alert.alert(
        alertText.title,
        alertText.text + ' : ' + e.message,
        [
          {
            text: 'รับทราบ',
            onPress: () => {}
          }
        ],
        { cancelable: false }
      )
    }
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove()
    this.keyboardDidHideListener.remove()
    Keyboard.dismiss()
  }

  _keyboardDidShow() {
    this.setState({
      detailShow: false
    })
  }

  _keyboardDidHide() {
    this.setState({
      detailShow: true
    })
  }

  alertEvaluate() {
    Alert.alert(
      'ใส่ค่าเดินทางแล้วหรือยัง',
      'คุณพนักงานขับรถใส่ข้อมูลค่าเดินทางแล้วหรือยัง',
      [
        {
          text: 'ใส่ค่าเดินทาง',
          onPress: () => this.props.navigateToScreen.bind(this, 'TransportCost'),
          style: 'cancel'
        },
        { text: 'ประเมินเลย', onPress: () => this.evaluate }
      ],
      { cancelable: false }
    )
  }

  evaluate = async () => {
    this.setState({
      evaluated: true
    })
    Keyboard.dismiss()

    try {
      if (this.state.starCount === 0) {
        throw new Error('กรุณาให้ดาว')
      } else if (
        this.state.starCount < 3 &&
        this.state.remark.replace(/\s+/g, '') === ''
      ) {
        throw new Error('กรุณาให้เหตุผล')
      }

      let responseJson1 = await fetchInfo2(driverApi + 'v2/rating-customer', {
        token: this.state.token,
        tripId: this.state.tripId,
        score: this.state.starCount,
        comment: this.state.remark
      })

      if (responseJson1.done) {
        let responseJson2 = await fetchInfo2(
          driverApi + 'driver-action/eval-customer',
          {
            token: this.state.token,
            tripId: this.state.tripId
          },
          1
        )
        if (responseJson2.state) {
          this.props.navigateToScreen('Trips')
        } else {
          throw new Error(responseJson2.error)
        }
      } else {
        throw new Error(responseJson2.error)
      }

      Keyboard.dismiss()
    } catch (e) {
      Alert.alert(
        errorTranslator(e),
        errorTranslator(e),
        [
          {
            text: 'รับทราบ',
            onPress: this.setState.bind(this, {
              evaluated: false
            })
          }
        ],
        { cancelable: false }
      )
    }
  }

  onStarRatingPress = rating => {
    this.setState({
      starCount: rating
    })
  }

  render() {
    return (
      <View
        style={{
          flex: 1
        }}>
        {this.state.detailShow ? (
          <ImageBackground
            source={require('../asset/image/stripe2.png')}
            resizeMode="cover"
            style={{
              flex: 50,
              width: '100%',
              height: '100%',
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor:
                this.state.payment == 'Cash' ? this.state.colorMain : 'rgb(204,160,170)'
            }}>
            {/* <TouchableOpacity
              style={{
                width: 75,
                height: 75,
                right: 10,
                top: 95,
                zIndex: 200,
                position: 'absolute',
                borderRadius: 75 / 2,
                backgroundColor: '#46ade8',
                justifyContent: 'center',
                alignItems: 'center'
              }}
              onPress={this.props.navigateToScreen.bind(this, 'TransportCost')}
            >
              <Icon name="description" size={20} />
              <Text
                style={{
                  fontSize: 13,
                  fontFamily: 'dbhelvethaicax_bd'
                }}
              >
                บันทึกค่าเดินทาง
              </Text>
            </TouchableOpacity> */}
            <View
              style={{
                flex: 10,
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                marginBottom: 10
              }}>
              <Text
                style={{
                  fontSize: 25,
                  fontFamily: 'dbhelvethaicax_bd',
                  color: '#3a3a3a'
                }}>
                {this.state.payment == 'Cash' ? 'เก็บเงินสด' : ''}
                {this.state.payment == 'Credit' ? 'จ่ายเงินผ่านบัตรแล้ว' : ''}
              </Text>
            </View>

            <View
              style={{
                flex: 12,
                justifyContent: 'center',
                alignItems: 'center',
                borderRadius: 10,
                backgroundColor:
                  this.state.payment == 'Cash' ? this.state.colorSub : 'rgb(203,130,145)'
              }}>
              <Text
                style={{
                  fontSize: 75,
                  padding: 10,
                  fontFamily: 'dbhelvethaicax_bd',
                  color: '#3a3a3a'
                }}>
                {this.state.priceNet}
              </Text>
            </View>

            <View
              style={{
                flex: 5,
                justifyContent: 'flex-end',
                alignItems: 'flex-end'
              }}>
              <Text
                style={{
                  fontFamily: 'dbhelvethaicax_bd',
                  color: '#3a3a3a'
                }}>
                ค่าบริการ: {this.state.priceDistance} บาท{' '}
                {this.state.distance ? '(' + this.state.distance + ' กิโลเมตร)' : null}
              </Text>
            </View>

            <View
              style={{
                flex: 5,
                justifyContent: 'flex-start',
                alignItems: 'flex-start'
              }}>
              <Text
                style={{
                  fontFamily: 'dbhelvethaicax_bd',
                  color: '#3a3a3a'
                }}>
                ค่ารอ: {this.state.waitCharges} บาท(
                {moment.duration(this.state.waitSeconds, 'seconds').hours() > 0
                  ? moment.duration(this.state.waitSeconds, 'seconds').hours() + ':'
                  : '0:'}
                {moment.duration(this.state.waitSeconds, 'seconds').minutes() + ':'}
                {moment.duration(this.state.waitSeconds, 'seconds').seconds()})
              </Text>
            </View>
          </ImageBackground>
        ) : null}
        <View
          style={{
            flex: this.state.detailShow ? 50 : 100,
            backgroundColor: '#d9d5d5',
            justifyContent: 'center',
            alignItems: 'center'
          }}>
          <View
            style={{
              flex: this.state.detailShow ? 20 : 30,
              justifyContent: 'center',
              alignItems: 'center'
            }}>
            <Text
              style={{
                fontSize: 20,
                fontFamily: 'dbhelvethaicax_bd',
                color: '#3a3a3a'
              }}>
              ประเมินลูกค้า
            </Text>
          </View>
          <View
            style={{
              flex: this.state.detailShow ? 15 : 30,
              justifyContent: 'center',
              alignItems: 'center'
            }}>
            <Text
              style={{
                fontSize: 15,
                fontFamily: 'dbhelvethaicax_bd',
                color: '#3a3a3a'
              }}>
              {this.state.customerName}
            </Text>
          </View>
          <View
            style={{
              flex: this.state.detailShow ? 20 : 30,
              justifyContent: 'center',
              alignItems: 'center'
            }}>
            <StarRating
              disabled={false}
              maxStars={5}
              rating={this.state.starCount}
              selectedStar={rating => {
                Keyboard.dismiss()
                this.onStarRatingPress(rating)
              }}
            />
          </View>
          <View
            style={{
              flex: this.state.detailShow ? 30 : 50,
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: 30,
              marginBottom: 25,
              marginHorizontal: 10
            }}>
            <FormInput
              multiline
              placeholder="กรุณาเขียนข้อมูลที่จำเป็นต่อพนักงานคนถัดไป.."
              underlineColorAndroid={0}
              containerStyle={{
                flex: 1,
                backgroundColor: '#FFF',
                borderRadius: 5
              }}
              inputStyle={{
                fontSize: 20
              }}
              onChangeText={val => {
                this.setState({ remark: val })
              }}
              onBlur={() => {
                Keyboard.dismiss()
              }}
              onPress={this.setState.bind(this, {
                detailShow: false
              })}
              value={this.state.remark}
            />
          </View>
        </View>
        <View
          style={{
            flex: this.state.detailShow ? 15 : 30,
            justifyContent: 'center',
            alignItems: 'center'
          }}>
          <Button
            title="เสร็จงาน"
            disabled={this.state.evaluated}
            icon={this.state.evaluated ? { name: 'cached' } : null}
            onPress={this.evaluate}
            containerViewStyle={{
              flex: 1,
              marginLeft: 0,
              marginRight: 0,
              marginBottom: 0,
              width: '100%',
              height: '100%'
            }}
            buttonStyle={{
              flex: 1,
              width: '100%',
              height: '100%',
              backgroundColor: '#43a1f5'
            }}
            textStyle={{
              fontFamily: 'dbhelvethaicax_bd',
              fontSize: 30,
              color: '#000000'
            }}
          />
        </View>
      </View>
    )
  }
}

const mapStateToProp = state => ({})

const mapDispatchToProp = dispatch => {
  return {
    navigateToScreen: name => dispatch(navigateToScreen(name))
  }
}

export default connect(
  mapStateToProp,
  mapDispatchToProp
)(JobAfterFinish)
