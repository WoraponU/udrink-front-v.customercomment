import React from 'react'
import { connect } from 'react-redux'
import { AppState, Alert } from 'react-native'
import Sound from 'react-native-sound'
import SystemSetting from 'react-native-system-setting'
import _ from 'lodash'
import JobProcessView from './components/JobProcessView'
import moment from 'moment'
import {
  setInitialState,
  processDepart,
  processArrive,
  processBegin,
  processGotCustomer,
  processBeginGotCustomer,
  processDrive,
  processDrop,
  processContinue,
  processEnd,
  getLocationNow,
  navigateScreen,
  clearError
} from '../state/paco/process'
import { tripClearState, tripOpenNoti } from '../state/paco/trip'
import haversine from 'haversine'
import BackgroundGeolocation from 'react-native-mauron85-background-geolocation'
import { timeWaitBefore } from 'app/config/uiconfig'
import BackgroundTimer from 'react-native-background-timer'
import { errorTranslator } from '../config/error'
import { AUTODRIVE_DISTANCE, AUTODRIVE_UNIT, AUTODRIVE_POLLING } from '../config/uiconfig'

class JobProcess extends React.Component {
  state = {
    appState: AppState.currentState,
    isOpenConfirmModal: false,
    isOpenReviewModal: false,
    isSetIntervalNotice: false
  }

  componentDidMount = async () => {
    this.props.setInitialState()
    this.pollingCheckNoticeDriverListeners()
    AppState.addEventListener('change', this._handleAppStateChange)
  }

  pollingCheckNoticeDriverListeners = () => {
    const period = 60 * 1000

    this.intervalId = BackgroundTimer.setInterval(() => {
      this.checkNoticeDriver()
    }, period)
  }

  checkNoticeDriver = () => {
    const { isSetIntervalNotice } = this.state
    const { state } = this.props

    if (!isSetIntervalNotice && (state === 'arrivedBefore' || state === 'waitBefore')) {
      const pickupDateTime = new Date(this.props.tripInfo.pickupDate)
      const now = new Date()
      const isLateFromPickupTime = moment(pickupDateTime).isBefore(now)
      if (isLateFromPickupTime) {
        this.intervalNotice()
      }
    }
  }

  componentDidUpdate(prevProps) {
    const { state } = this.props

    if (prevProps.state !== state) {
      if (prevProps.state === 'waitBefore' && state !== 'on-job') {
        this.clearIntervalNotice()
      }
    }
  }

  componentWillReceiveProps = nextProps => {
    if (
      this.props.errorMessage !== nextProps.errorMessage &&
      nextProps.errorMessage !== ''
    ) {
      // let alertText = getError(nextProps.errorMessage)
      Alert.alert(
        'เกิดข้อผิดพลาด',
        errorTranslator(nextProps.errorMessage),
        [
          {
            text: 'รับทราบ',
            onPress: () => this.props.clearError()
          }
        ],
        { cancelable: false }
      )
    }
  }

  componentWillUnmount() {
    AppState.removeEventListener('change', this._handleAppStateChange)
    this.clearIntervalNotice()
  }

  intervalNotice = async () => {
    const {
      tripInfo: { fromLocation }
    } = this.props
    const period = AUTODRIVE_POLLING * 1000

    this.intervalId = BackgroundTimer.setInterval(async () => {
      try {
        const { latitude, longitude } = await this.getCurrentLocation()
        const params = {
          currentLocation: { latitude, longitude },
          fromLocation: { latitude: fromLocation.lat, longitude: fromLocation.lng },
          options: { threshold: AUTODRIVE_DISTANCE * 1, unit: AUTODRIVE_UNIT }
        }
        const isOver2Km = !haversine(
          params.currentLocation,
          params.fromLocation,
          params.options
        )

        this.setState({
          isTravelOver2Km: isOver2Km
        })
      } catch (err) {
        console.log('cant get current location')
      }

      await this.createSounds()
      this.playSound(this.clockTickingSound)
    }, period)

    this.setState({
      isSetIntervalNotice: true
    })
  }

  playSound(sound) {
    SystemSetting.setVolume(1, {
      type: 'music',
      playSound: false,
      showUI: false
    })
    sound.play(_ => {})
  }

  createSounds = () => {
    Sound.setCategory('Playback')

    return new Promise((resolve, reject) => {
      this.clockTickingSound = new Sound('clockticking.mp3', Sound.MAIN_BUNDLE, error => {
        if (error) reject(error)
        resolve('created clockTickingSound')
      })
    })
  }

  clearIntervalNotice = () => {
    BackgroundTimer.clearInterval(this.intervalId)
    this.setState({
      isSetIntervalNotice: false
    })
  }

  getCurrentLocation = () => {
    return new Promise((resolve, reject) => {
      BackgroundGeolocation.getLocations(
        locationsStored => {
          const lastIndex = locationsStored.length - 1
          resolve(locationsStored[lastIndex])
        },
        err => {
          reject(err)
        }
      )
    })
  }

  toggleConfirmModal = () => {
    const { isOpenConfirmModal } = this.state
    this.setState({ isOpenConfirmModal: !isOpenConfirmModal })
  }

  toggleReviewModal = () => {
    const { isOpenReviewModal } = this.state
    this.setState({ isOpenReviewModal: !isOpenReviewModal })
  }

  _handleAppStateChange = nextAppState => {
    let stillInThisScreen = true
    if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
      try {
        this.props.setInitialState() // re-init state
        stillInThisScreen = false
      } catch (err) {
        // TODO: show warning to user
        console.log('@JobProcess: getting state error', err)
      }
    }

    if (stillInThisScreen) {
      this.setState({
        appState: nextAppState
      })
    }
  }

  render() {
    let countNumber = '0:0:0'
    let modalState = false
    let timelimit = 0

    let processPrimary = () => {}
    let processSecondary = () => {}
    const state = this.props.state
    if (state === 'booked' || state === 'accepted') {
      processPrimary = this.props.processDepart
    } else if (state === 'travel') {
      processPrimary = () => {
        Alert.alert(
          'คุณถ่ายรูปค่าเดินทางหรือยัง?',
          null,
          [
            {
              text: 'ถ่ายแล้ว',
              onPress: () => this.props.processArrive()
            },
            {
              text: 'ยังไม่ได้ถ่าย',
              onPress: () => this.props.navigateScreen('TransportCost')
            }
          ],
          { cancelable: false }
        )
      }
    } else if (state === 'arrived' || state === 'arrivedBefore') {
      processPrimary = this.props.processBeginGotCustomer
    } else if (state === 'waitBefore') {
      processPrimary = this.props.processGotCustomer
    } else if (state === 'on-job' || state === 'wait-before') {
      processPrimary = this.props.processGotCustomer
    } else if (state === 'on-board') {
      processPrimary = this.props.processDrive
    } else if (state === 'drive') {
      processPrimary = this.props.processEnd
      processSecondary = this.props.processDrop
    } else if (state === 'drop') {
      processPrimary = this.props.processContinue
    }

    if (state === 'arrivedBefore') {
      modalState = true
      countNumber = this.props.arriveBeforeTimer
    } else if (state === 'on-job') {
      modalState = true
      countNumber = '0:0:0'
    } else if (state === 'waitBefore') {
      modalState = true
      countNumber = this.props.arriveAfterTimer
      timelimit = timeWaitBefore
    } else if (state === 'drop' && !this.props.ending) {
      modalState = true
      countNumber = this.props.dropTimer
    } else {
      modalState = false
    }

    return (
      <JobProcessView
        modalState={modalState}
        isTravelOver2Km={this.state.isTravelOver2Km}
        isOpenConfirmModal={this.state.isOpenConfirmModal}
        isOpenReviewModal={this.state.isOpenReviewModal}
        toggleConfirmModal={this.toggleConfirmModal}
        toggleReviewModal={this.toggleReviewModal}
        countNumber={countNumber}
        state={this.props.state}
        processLeft={processPrimary}
        processHideModal={processPrimary}
        processRight={processSecondary}
        processingButton={this.props.fetching}
        buttonBlock={this.props.fetching}
        tripInfo={this.props.tripInfo}
        customer={this.props.customer}
        stopsLocation={this.props.stopsLocation}
        fromLocation={this.props.fromLocation}
        toLocation={this.props.toLocation}
        pickupDate={this.props.pickupDate}
        priceNet={this.props.priceNet}
        remark={this.props.remark}
        timelimit={timelimit}
        getLocationNow={this.props.getLocationNow}
        regionFromToMap={this.props.regionFromToMap}
        currentLocationMap={this.props.currentLocationMap}
        navigateScreen={this.props.navigateScreen}
      />
    )
  }
}

JobProcess.propTypes = {}

const mapStateToProp = state => ({
  state: state.trip.state,
  tripInfo: state.trip.tripInfo,
  customer: state.trip.tripInfo && state.trip.tripInfo.customer,
  stopsLocation: state.trip.tripInfo && state.trip.tripInfo.stopsLocation,
  fromLocation: state.trip.tripInfo && state.trip.tripInfo.fromLocation,
  toLocation: state.trip.tripInfo && state.trip.tripInfo.toLocation,
  pickupDate: state.trip.tripInfo && state.trip.tripInfo.pickupDate,
  priceNet: state.trip.tripInfo && state.trip.tripInfo.priceNet,
  remark: state.trip.tripInfo && state.trip.tripInfo.remark,
  tripId: state.trip.tripId,
  lastStateChanged: state.trip.lastStateChanged,
  arriveBeforeTimer: state.process.arriveBeforeTimer,
  arriveAfterTimer: state.process.arriveAfterTimer,
  fetching: state.process.fetching,
  countingDown: state.process.countingDown,
  countingUp: state.process.countingUp,
  countingDrop: state.process.countingDrop,
  dropTimer: state.process.dropTimer,
  ending: state.process.ending,
  regionFromToMap: state.process.regionFromToMap,
  currentLocationMap: state.process.currentLocationMap,
  errorMessage: state.process.errorMessage
})

const mapDispatchToProp = dispatch => {
  return {
    setInitialState: () => dispatch(setInitialState()),
    processDepart: () => dispatch(processDepart()),
    processArrive: () => dispatch(processArrive()),
    processBegin: () => dispatch(processBegin()),
    processGotCustomer: () => dispatch(processGotCustomer()),
    processBeginGotCustomer: () => dispatch(processBeginGotCustomer()),
    processDrive: () => dispatch(processDrive()),
    processDrop: () => dispatch(processDrop()),
    processContinue: () => dispatch(processContinue()),
    processEnd: () => dispatch(processEnd()),
    getLocationNow: () => dispatch(getLocationNow()),
    navigateScreen: (name, params = {}) => dispatch(navigateScreen(name, params)),
    tripClearState: () => dispatch(tripClearState()),
    clearError: () => dispatch(clearError()),
    tripOpenNoti: openResult => dispatch(tripOpenNoti(openResult))
  }
}

export default connect(
  mapStateToProp,
  mapDispatchToProp
)(JobProcess)
