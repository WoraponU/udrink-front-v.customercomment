import React, { Component } from 'react'
import Modal from 'react-native-modalbox'
import * as Progress from 'react-native-progress'
import {
  Text,
  Image,
  ImageBackground,
  View,
  Alert,
  ScrollView
} from 'react-native'
import { Button, Icon } from 'react-native-elements'
import moment from 'moment'

export default class OneMinuteModal extends React.Component {
  render() {
    const stopLocationName = this.props.stopsLocation && this.props.stopsLocation.map((addressInfo, index) =>
      <Text
        key={index}
        style={{
          flex: 1,
          fontSize: 15,
          textAlign: 'left',
          fontFamily: 'dbhelvethaicax_bd'
        }}>
        แวะ-{index + 1}: {addressInfo.name}
      </Text>
    )
    return (
      <Modal
        style={[
          {
            borderRadius: 10,
            height: 400,
            width: 300,
            marginTop: 88,
            zIndex: 100,
          }
        ]}
        isOpen={(this.props.waitingForAccept)}
        animationDuration={0}
        position={'top'}
        ref={'modal4'}
        backdropPressToClose={false}
        swipeToClose={false}
        backdropOpacity={0.95}>
        <View
          style={{
            flex: 20,
            justifyContent: 'center',
            alignItems: 'center',
            marginBottom: 0,
            marginTop: 0,
            zIndex: 100,
          }}>
          <Text
            style={{
              flex: 1,
              fontSize: 40,
              color: '#3897f4',
              textAlign: 'center',
              marginVertical: 5,
              fontFamily: 'dbhelvethaicax_bd'
            }}>
            งานใหม่
            </Text>
        </View>
        <ImageBackground
          source={require('../../asset/image/stripe2.png')}
          style={{
            flex: 80,
            width: '100%',
            height: '100%',
            backgroundColor: 'transparent',
            justifyContent: 'center',
            alignItems: 'center'
          }}>
          <Progress.Circle
            size={100}
            progress={this.props.countTime / 60}
            formatText={progress => this.props.countTime}
            color="#3796f4"
            unfilledColor="#c9c9ca"
            borderWidth={0}
            showsText={true}
            style={{
              flex: 3,
              marginTop: 13,
              marginBottom: 0,
              padding: 0
            }}
            textStyle={{
              fontSize: 45,
              fontFamily: 'dbhelvethaicax_bd'
            }}
          />
          <View
            style={{
              flex: 3,
              justifyContent: 'flex-start',
              alignItems: 'flex-start',
              paddingHorizontal: 10
            }}>           
            <ScrollView
              style={{
                flex: 1,
              }}>
              <Text
                style={{
                  flex: 1,
                  fontSize: 20,
                  fontFamily: 'dbhelvethaicax_bd',
                  textAlign: 'right'
                }}>เวลานัด - {moment
                  .utc(this.props.pickupDate)
                  .local()
                  .format('h:mmA')}
              </Text>
              <Text
                style={{
                  flex: 1,
                  fontSize: 15,
                  textAlign: 'left',
                  fontFamily: 'dbhelvethaicax_bd'
                }}>
                สถานที่รับ: {this.props.fromLocation && this.props.fromLocation.name}
              </Text>
              {stopLocationName}
              <Text
                style={{
                  flex: 1,
                  fontSize: 15,
                  textAlign: 'left',
                  fontFamily: 'dbhelvethaicax_bd'
                }}>
                สถานที่ส่ง: {this.props.toLocation && this.props.toLocation.name}
              </Text>
              { this.props.tripInfo && this.props.tripInfo.remark &&
                <Text
                  style={{
                    fontSize: 15,
                    fontFamily: 'dbhelvethaicax_bd',
                    marginBottom: 5
                  }}>
                  หมายเหตุ: {this.props.tripInfo.remark}
                </Text> 
              }
            </ScrollView>
          </View>
        </ImageBackground>
        <View
          style={{
            // flex: 25,
            flexDirection: 'row',
            // height: 80,
            justifyContent: 'flex-end',
            alignItems: 'flex-end',
            borderRadius: 10
          }}>
          <Button
            large
            title="รับงาน"
            disabled={this.props.fetching}
            icon={this.props.fetching ? { name: 'cached' } : null}
            accessibilityLabel="acceptButton"
            buttonStyle={{
              backgroundColor: '#4ebbf9',
              borderBottomLeftRadius: 10,
              justifyContent: 'center',
              alignItems: 'center',
              height: 80
            }}
            containerViewStyle={{
              flex: 2,
              marginLeft: 0,
              marginRight: 0,
              borderBottomLeftRadius: 10,
              height: 80
            }}
            textStyle={{
              color: '#000000',
              fontSize: 35,
              fontFamily: 'dbhelvethaicax_bd'
            }}
            onPress={this.props.acceptJob}
          />
          <Button
            large
            title="ไม่รับ"
            disabled={this.props.fetching}
            icon={this.props.fetching ? { name: 'cached' } : null}
            accessibilityLabel="rejectButton"
            buttonStyle={{
              backgroundColor: '#b7b7b7',
              borderBottomRightRadius: 10,
              justifyContent: 'center',
              alignItems: 'center',
              height: 80
            }}
            containerViewStyle={{
              flex: 1,
              marginLeft: 0,
              marginRight: 0,
              borderBottomRightRadius: 10,
              height: 80
            }}
            textStyle={{
              color: '#6a6666',
              // lineHeight: 15,
              fontSize: 30,
              fontFamily: 'dbhelvethaicax_bd'
            }}
            onPress={this.props.rejectJob}
          />
        </View>
      </Modal>
    )
  }
}