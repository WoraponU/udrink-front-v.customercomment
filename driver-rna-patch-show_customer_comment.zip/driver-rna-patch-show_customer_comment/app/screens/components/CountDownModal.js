import React from 'react'
import { Alert, Text, View, Image, ImageBackground, ScrollView } from 'react-native'
import { Button, Icon } from 'react-native-elements'
import Modal from 'react-native-modalbox'
import * as Progress from 'react-native-progress'
import moment from 'moment'
import Communications from 'react-native-communications'
import SendIntentAndroid from 'react-native-send-intent'

export default class CountDownModal extends React.Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      countNumber: '',
      circleprogress: 0,
      timeText: '',
      timelimit: 0,
      state: '',
      modalState: false,
      buttonBlock: false,
    }
  }
  async componentWillReceiveProps(nextProps) {
    let abs = Math.abs
    try {
      let timeText = nextProps.countNumber
      let circleprogress = 0
      if (typeof nextProps.countNumber === 'object') {
        circleprogress = await (nextProps.countNumber === '') ? 0 : abs(nextProps.countNumber.seconds())
        timeText = await abs(nextProps.countNumber.hours()) + ':' + abs(nextProps.countNumber.minutes()) + ':' + abs(nextProps.countNumber.seconds())
        if (circleprogress > 0) {
          circleprogress = circleprogress / 60
        }
      }
      this.setState({
        circleprogress: circleprogress,
        timeText: timeText,
        timelimit: nextProps.timelimit,
      })
    }
    catch (err) {
      throw new Error(err)
    }
  }

  handleOpenMap = (destination) => () => {
    SendIntentAndroid.openMaps(destination)
  }

  colorText = () => {
    if (this.props.countNumber.constructor.name === 'Duration') {
      if (this.props.countNumber.asMilliseconds() > this.state.timelimit) {
        return 'red'
      }
      else {
        return '#3796f4'
      }
    }
    else {
      return '#3796f4'
    }
  }

  handleChangeState = () => {
    const { processHideModal } = this.props

    Alert.alert(
      'ยืนยันการเปลี่ยนสถานะ',
      null,
      [
        { text: 'ตกลง', onPress: processHideModal },
        { text: 'ยกเลิก' },
      ],
    )
  }

  render() {
    let modalTitle = null
    if (this.props.state === 'arrivedBefore') {
      modalTitle = 'รอเวลานัด'
    }
    else if (this.props.state === 'on-job') {
      modalTitle = 'รอลูกค้า'
    }
    else if (this.props.state === 'waitBefore') {
      modalTitle = 'รอลูกค้า'
    }
    else if (this.props.state === 'drop') {
      modalTitle = 'รอลูกค้า'
    }
    const stopLocationName = this.props.stopsLocation && this.props.stopsLocation.map((addressInfo, index) =>
      <Text
        key={index}
        onPress={this.handleOpenMap(addressInfo && `${addressInfo.lat},${addressInfo.lng}`)}
        style={{
          flex: 1,
          fontSize: 18,
          marginBottom: 10,
          marginTop: 10,
          textAlign: 'left',
          fontFamily: 'dbhelvethaicax_bd',
          color: 'blue',
          textDecorationLine: 'underline'
        }}>
        แวะ-{index + 1}: {addressInfo.name}
      </Text>
    )
    return (
      <Modal style={[
        {
          borderRadius: 10,
          height: 500,
          width: 300,
          marginTop: 'auto',
          marginBottom: 'auto'
        }
      ]}
        isOpen={this.props.modalState}
        animationDuration={0}
        position={"top"}
        ref={"modal4"}
        backdropPressToClose={false}
        swipeToClose={false}
        backdropOpacity={0.92}
      >
        <View
          style={{
            flex: 8,
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {(this.props.countNumber !== '') ?
            <Text style={{
              flex: 1,
              fontSize: 30,
              color: '#3897f4',
              textAlign: 'center',
              fontFamily: 'dbhelvethaicax_bd'
            }}>
              {modalTitle}
            </Text> : null}
        </View>
        <ImageBackground source={require('../../asset/image/stripe2.png')} style={{
          flex: 70,
          width: '100%',
          height: '100%',
          backgroundColor: 'transparent',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
          <Progress.Circle size={160}
            animated={false}
            progress={this.state.circleprogress}            
            // color={this.props.state == 'drop'?'#3796f4':'#06C358'}
            color={this.props.state == 'drop'?'#3796f4':'#3796f4'}
            unfilledColor='#c9c9ca'
            borderWidth={0}
            showsText={true}
            formatText={(progress) => {
              return this.state.timeText
            }}
            style={{
              flex: 3,
              marginTop: 15,
              marginBottom: 0,
              padding: 0,
              justifyContent: 'center',
              alignItems: 'center',
            }}
            textStyle={{
              fontSize: 45,
              fontFamily: 'dbhelvethaicax_bd',
            }}
          />
          <View
            style={{
              flex: 3,
              justifyContent: 'flex-start',
              alignItems: 'flex-start',
              paddingHorizontal: 10
            }}>
            <ScrollView
              style={{
                flex: 1,
              }}>
              <View
                style={{
                  flexDirection: 'row'
                }}
              >
                <Text
                  style={{
                    fontSize: 20,
                    fontFamily: 'dbhelvethaicax_bd',
                  }}
                >
                  ชื่อ: {this.props.customer && this.props.customer.name}
                </Text>
                <Text
                  style={{
                    flex: 1,
                    fontSize: 20,
                    fontFamily: 'dbhelvethaicax_bd',
                    textAlign: 'right'
                  }}>เวลานัด - {moment
                    .utc(this.props.pickupDate)
                    .local()
                    .format('h:mmA')}
                </Text>
              </View>
              <Text
                style={{
                  flex: 1,
                  fontSize: 18,
                  textAlign: 'left',
                  fontFamily: 'dbhelvethaicax_bd'
                }}>
                สถานที่รับ: {this.props.fromLocation && this.props.fromLocation.name}
              </Text>
              {stopLocationName}
              <Text
                onPress={this.handleOpenMap(this.props.toLocation && `${this.props.toLocation.lat},${this.props.toLocation.lng}`)}
                style={{
                  flex: 1,
                  fontSize: 18,
                  textAlign: 'left',
                  marginBottom: 10,
                  fontFamily: 'dbhelvethaicax_bd',
                  color: 'blue',
                  textDecorationLine: 'underline'
                }}>
                สถานที่ส่ง: {this.props.toLocation && this.props.toLocation.name}
              </Text>
              { this.props.tripInfo && this.props.tripInfo.remark &&
                <Text
                  style={{
                    fontSize: 18,
                    fontFamily: 'dbhelvethaicax_med',
                    marginBottom: 5
                  }}>
                  หมายเหตุ: {this.props.tripInfo.remark}
                </Text> 
              }
            </ScrollView>
          </View>
        </ImageBackground>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'flex-end',
            alignItems: 'flex-end',
            borderRadius: 10,
          }}
        >
          <Button
            large
            accessibilityLabel="processModal"
            disabled={this.props.buttonBlock}
            icon={this.props.buttonBlock ? { name: 'cached' } : null}
            title={this.props.state == 'drop'?'เดินทางต่อ':'ออกเดินทาง'}
            buttonStyle={{
              backgroundColor: '#4ebbf9',
              justifyContent: 'center',
              alignItems: 'center',
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: (this.props.state == 'arrived' ||
                this.props.state == 'waitBefore' ||
                this.props.state == 'arrivedAfter' ||
                this.props.state == 'arrivedBefore') ? 0 : 10,
              backgroundColor: '#4ebbf9',
              height: 80,
            }}
            containerViewStyle={{
              flex: 2,
              marginLeft: 0,
              marginRight: 0,
              borderBottomLeftRadius: 10,
              borderBottomRightRadius: (this.props.state == 'arrived' ||
                this.props.state == 'waitBefore' ||
                this.props.state == 'arrivedAfter' ||
                this.props.state == 'arrivedBefore') ? 0 : 10,
              backgroundColor: '#4ebbf9',
              height: 80,
            }}
            textStyle={{
              color: '#000000',
              textAlign: 'center',
              // marginTop: 20,
              justifyContent: 'flex-end',
              alignItems: 'flex-end',
              fontSize: 30,
              fontFamily: 'dbhelvethaicax_bd'
            }}
            onPress={this.handleChangeState}
          />
  
          {
            this.props.state == 'arrived' ||
              this.props.state == 'waitBefore' ||
              this.props.state == 'arrivedAfter' ||
              this.props.state == 'arrivedBefore' ?
              <Icon
                name='call'
                size={40}
                
                onPress={() =>
                  Communications.phonecall(
                    this.props.customer.phone ? '+' + this.props.customer.phone : '',
                    true
                  )
                }
                containerStyle={{
                  flex: 1,
                  marginLeft: 0,
                  marginRight: 0,
                  borderBottomRightRadius: 10,
                  backgroundColor: '#009688',
                  height: 80,
                }}
                iconStyle={{
                  color: '#000000',
                  textAlign: 'center',                  
                  justifyContent: 'flex-end',
                  alignItems: 'flex-end',
                  borderBottomRightRadius: 10,
                  backgroundColor: '#009688',
                }}
              /> : null}
        </View>
      </Modal>
    )
  }
}