import React, { PureComponent } from 'react'
import { View, StyleSheet } from 'react-native'
import Modal from 'react-native-modalbox'
import { Button } from 'react-native-elements'
import { FormInput } from 'react-native-elements'

class ConfirmModal extends PureComponent {
  state = {
    confirmText: '',
    disabledButton: true
  }

  componentDidUpdate(prevProps, prevState) {
    const { confirmText } = this.state

    if (prevState.confirmText !== confirmText) {
      if (confirmText === '1234') {
        this.setState({ disabledButton: false })
      } else { 
        this.setState({ disabledButton: true })
      }
    } 
  }

  onChangConfirmText = (val) => {
    this.setState({ confirmText: val })
  }

  handleNextProcess = () => {
    const {  toggleConfirmModal, nextState } = this.props

    toggleConfirmModal()
    return nextState()
  }

  render() {
    const { confirmText, disabledButton } = this.state
    const { isOpenConfirmModal, toggleConfirmModal, state } = this.props
    const isDriveState = state === 'never-happen'

    return (
      <Modal 
        style={[ styles.modal, { height: isDriveState ? 155 : 85 }]}
        isOpen={isOpenConfirmModal}
        animationDuration={0}
        position={'center'}
        backdropPressToClose={false}
        swipeToClose={false}
        backdropOpacity={0.8}
      >
        {
          isDriveState && 
          (
            <View style={styles.viewRow}>
              <FormInput
                autoFocus={true}
                placeholder="กรุณากรอก: 1234"
                keyboardType="numeric"
                containerStyle={styles.formContainer}
                inputStyle={styles.formInput}
                underlineColorAndroid={0}
                onChangeText={this.onChangConfirmText}
                value={confirmText}
              />
            </View>
          )
        }
        
        <View style={styles.viewRow}>
          <Button 
            title="ยืนยัน" 
            buttonStyle={styles.buttonLeft} 
            textStyle={styles.buttonText} 
            containerViewStyle={styles.buttonContainer}
            disabled={isDriveState ? disabledButton : false}
            onPress={this.handleNextProcess}
          />
          <Button 
            title="ยกเลิก" 
            buttonStyle={styles.buttonRight} 
            textStyle={styles.buttonText} 
            containerViewStyle={styles.buttonContainer}
            onPress={toggleConfirmModal}
          />
        </View>
      </Modal>
    )
  }
}

export default ConfirmModal

const styles = StyleSheet.create({
  modal: {
    position: 'relative',
    zIndex: 10,
  },
  viewRow: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },

  buttonContainer: {
    flex: 1,
    marginBottom: 0,
    marginLeft: 0,
    marginTop: 0,
    marginRight: 0,
    height: 85
  },
  buttonRight: {
    backgroundColor: '#b7b7b7',
    height: 85,
  },
  buttonLeft: {
    backgroundColor: '#4ebbf9',
    height: 85,
  },
  buttonText: {
    color: '#000',
    fontSize: 25,
    fontFamily: 'dbhelvethaicax_bd',
  },
  formContainer: {
    flex: 1,
  },
  formInput: {
    fontSize: 25,
  }
});
