import React, { PureComponent } from 'react'
import { StyleSheet, Text, ScrollView } from 'react-native'
import Modal from 'react-native-modalbox'
import { Card, Button } from 'react-native-elements'
import _ from 'lodash'

import { tripApi } from '../../config/hostname'

class ReviewModal extends PureComponent {
  state = {
    comments: [],
    isLoading: false
  }

  async componentDidMount() {
    try {
      const { result, comments } = await this.getCustomerComment()

      if (result) {
        this.setState({ comments })
      }
    } catch (err) {
      console.log(JSON.stringify(err))
    }
  }

  async componentDidUpdate(prevProps) {
    const { customer } = this.props

    if (!_.isEqual(prevProps.customer, customer) && customer.phone) {
      try {
        const { result, comments } = await this.getCustomerComment()

        if (result) {
          this.setState({ comments })
        }
      } catch (err) {
        console.log(JSON.stringify(err))
      }
    }
  }

  getCustomerComment = async () => {
    const { customer } = this.props

    try {
      this.setState({ isLoading: true })
      const response = await fetch(tripApi + 'trip/get-customer-comment', {
        method: 'POST',
        headers: {
          Accept: 'application/json, text/plain, */*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          customerPhone: customer.phone
        })
      })

      this.setState({ isLoading: false })
      return response.json()
    } catch (err) {
      this.setState({ isLoading: false })
      throw new Error(err)
    }
  }

  render() {
    const { isOpenReviewModal, toggleReviewModal } = this.props
    const { comments, isLoading } = this.state

    return (
      <Modal
        isOpen={isOpenReviewModal}
        animationDuration={0}
        position={'top'}
        backdropOpacity={0.8}
        backdropPressToClose={false}
        swipeToClose={false}
        style={styles.modal}>
        <ScrollView>
          {comments.length ? (
            comments.map((comment, index) => (
              <Card key={index}>
                <Text style={styles.textInput}>{comment}</Text>
              </Card>
            ))
          ) : (
            <Text style={styles.textNotFound}>ไม่พบข้อมูล</Text>
          )}
        </ScrollView>
        <Button
          large
          accessibilityLabel="processModal"
          title="ปิด"
          disabled={isLoading}
          buttonStyle={{
            borderBottomLeftRadius: 10,
            borderBottomRightRadius: 10
          }}
          containerViewStyle={{
            width: '100%',
            marginLeft: 0,
            marginRight: 0,
            borderBottomLeftRadius: 10,
            borderBottomRightRadius: 10
          }}
          textStyle={{
            fontSize: 24,
            fontFamily: 'dbhelvethaicax_bd'
          }}
          onPress={toggleReviewModal}
        />
      </Modal>
    )
  }
}

export default ReviewModal

const styles = StyleSheet.create({
  modal: {
    borderRadius: 10,
    height: 500,
    width: 300,
    marginTop: 'auto',
    marginBottom: 'auto'
  },
  textInput: {
    fontSize: 24,
    textAlign: 'left',
    fontFamily: 'dbhelvethaicax_bd'
  },
  textNotFound: { textAlign: 'center', marginTop: 10 }
})
