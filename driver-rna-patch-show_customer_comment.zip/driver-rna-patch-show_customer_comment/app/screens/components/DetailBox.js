import React from 'react'
import { TouchableOpacity, Text, TextInput, View, ScrollView } from 'react-native'
import ModalSelector from 'react-native-modal-selector'
import Communications from 'react-native-communications'
import moment from 'moment'
import SendIntentAndroid from 'react-native-send-intent'

export default class DetailBox extends React.Component {
  state = {
    show: false,
    boxHeight: '60%',
    iconToMap: 'expand-more',
    tripId: '',
    tripInfo: this.props.tripInfo,
    fromLocationLat: 0.0,
    fromLocationLng: 0.0,
    fromLocationName: '',
    toLocationLat: 0.0,
    toLocationLng: 0.0,
    toLocationName: '',
    pickupDate: '',
    customerName: '',
    customerPhone: '',
    priceNet: 0,
    remark: '',
    navigatorData: [],
    btnNavigatePosition: 0,
    openModalReview: false
  }

  componentWillReceiveProps(nextProps, nextSate) {
    if (nextProps.fromLocation !== this.props.fromLocation) {
      this.getNavigateData(nextProps)
    }
    if (nextProps.state !== this.props.state) {
      if (this.props.state === 'travel') {
        this.setState({ btnNavigatePosition: 30 })
      }
    }
  }

  getNavigateData = async tripInfo => {
    let keyLocation = 1
    const fromLocation =
      tripInfo.fromLocation && tripInfo.fromLocation.lat
        ? [
            {
              key: keyLocation,
              label: 'ตำแหน่งปัจจุบันไปหาลูกค้า',
              location:
                (tripInfo.fromLocation && tripInfo.fromLocation.lat).toString() +
                ',' +
                (tripInfo.fromLocation && tripInfo.fromLocation.lng).toString()
            }
          ]
        : []

    const stopsLocationOption =
      (tripInfo.stopsLocation &&
        tripInfo.stopsLocation.map((address, index) => {
          keyLocation++
          return {
            key: keyLocation,
            label: 'ตำแหน่งปัจจุบันไปยัง ' + address.name,
            location: address.lat + ',' + address.lng
          }
        })) ||
      []

    const toLocationOption =
      (tripInfo.toLocation &&
        tripInfo.toLocation.lat && [
          {
            key: keyLocation + 1,
            label: 'ตำแหน่งปัจจุบันถึงจุดสุดท้าย',
            location:
              (tripInfo.toLocation && tripInfo.toLocation.lat).toString() +
              ',' +
              (tripInfo.toLocation && tripInfo.toLocation.lng).toString()
          }
        ]) ||
      []

    let navigator = fromLocation.concat(toLocationOption)
    this.setState({ navigatorData: navigator })
  }

  showButtons = () => {
    this.setState({
      show: true,
      boxHeight: '50%',
      iconToMap: 'expand-less'
    })
  }

  hideButtons = () => {
    this.setState({
      show: false,
      boxHeight: '60%',
      iconToMap: 'expand-more'
    })
  }

  openMap = async (mode, destination) => {
    SendIntentAndroid.openMapsWithRoute(destination, mode)
  }

  render() {
    const { runningNumber } = this.props.tripInfo
    return (
      <View
        style={{
          backgroundColor: '#f7f7f8',
          position: 'absolute',
          borderBottomLeftRadius: 10,
          borderBottomRightRadius: 10,
          top: 0,
          left: 0,
          right: 0,
          bottom: this.state.boxHeight,
          flex: 1,
          zIndex: 1,
          height: this.props.isMapExpand ? 0 : 'auto',
          display: this.props.customer && this.props.customer.name == '' ? 'none' : 'flex'
        }}>
        <View
          style={{
            flexDirection: 'row',
            height: 43,
            justifyContent: 'flex-start',
            alignItems: 'center'
          }}>
          <Text
            style={{
              fontSize: 24,
              textAlign: 'center',
              fontFamily: 'dbhelvethaicax_bd',
              marginLeft: 20
            }}>
            เวลานัด{' '}
            {moment
              .utc(this.props.pickupDate)
              .local()
              .format('HH:mm')}
            {'  '}
            ราคา {this.props.priceNet} บาท{' '}
            {this.props.tripInfo && this.props.tripInfo.isFixedPrice && '(งานเหมา)'}
          </Text>
        </View>
        <ScrollView
          style={{
            flex: 1,
            marginLeft: 10,
            marginRight: 10,
            height: 50,
            paddingHorizontal: 10,
            paddingVertical: 3,
            backgroundColor: '#f1f1f1'
          }}>
          <TripNumber runningNumber={runningNumber} />
          <Text
            style={{
              fontSize: 18,
              fontFamily: 'dbhelvethaicax_med',
              marginBottom: 5
            }}>
            ชื่อ: {this.props.customer && this.props.customer.name}
          </Text>
          <Text
            style={{
              fontSize: 18,
              fontFamily: 'dbhelvethaicax_med',
              marginBottom: 5
            }}>
            การจ่ายเงิน:{' '}
            {this.props.customer && this.props.customer.paymentType === 'Cash'
              ? 'เงินสด'
              : 'บัตรเครดิต'}
          </Text>
          <Text
            style={{
              fontSize: 18,
              fontFamily: 'dbhelvethaicax_med',
              marginBottom: 5
            }}>
            ที่รับ: {this.props.fromLocation && this.props.fromLocation.name}
          </Text>
          {this.props.stopsLocation &&
            this.props.stopsLocation.map((addressInfo, index) => {
              return (
                <Text
                  key={index}
                  style={{
                    fontSize: 18,
                    fontFamily: 'dbhelvethaicax_med',
                    marginBottom: 5
                  }}>
                  แวะ- {index + 1}: {addressInfo.name}
                </Text>
              )
            })}
          <Text
            style={{
              fontSize: 18,
              fontFamily: 'dbhelvethaicax_med',
              marginBottom: 5
            }}>
            ที่ส่ง: {this.props.toLocation && this.props.toLocation.name}
          </Text>

          {this.props.remark && (
            <Text
              style={{
                fontSize: 18,
                fontFamily: 'dbhelvethaicax_med',
                marginBottom: 5
              }}>
              หมายเหตุ: {this.props.remark}
            </Text>
          )}
        </ScrollView>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            marginTop: 10,
            marginLeft: 0,
            marginBottom: 10,
            marginRight: 20
          }}>
          {this.props.state === 'travel' && (
            <TouchableOpacity
              style={{
                flex: 3,
                backgroundColor: '#f1f1f1',
                borderWidth: 0,
                borderRadius: 3,
                height: 40,
                justifyContent: 'center',
                alignItems: 'center',
                marginLeft: 30,
                marginRight: 10
              }}
              onPress={this.props.navigateScreen.bind(this, 'TransportCost', {
                TransportCostsOnly: true
              })}>
              <Text
                style={{
                  fontSize: 18,
                  color: '#000000',
                  fontFamily: 'dbhelvethaicax'
                }}>
                ค่าเดินทาง
              </Text>
            </TouchableOpacity>
          )}
          <ModalSelector
            style={{
              flex: 3,
              backgroundColor: '#f1f1f1',
              borderWidth: 0,
              borderRadius: 3,
              height: 40,
              justifyContent: 'center',
              alignItems: 'center',
              marginLeft: this.state.btnNavigatePosition
            }}
            selectStyle={{
              borderWidth: 0
            }}
            sectionTextStyle={{
              color: '#000000'
            }}
            optionTextStyle={{
              fontSize: 20
            }}
            cancelTextStyle={{
              fontSize: 20
            }}
            cancelText="ปิด"
            data={this.state.navigatorData}
            initValue="ระบบนำทาง"
            onChange={option => {
              this.openMap('d', option.location)
            }}>
            <TextInput
              style={{
                flex: 1,
                margin: 0,
                padding: 0,
                width: 100,
                justifyContent: 'center',
                alignItems: 'center',
                color: '#000000',
                fontSize: 18
              }}
              textAlign={'center'}
              underlineColorAndroid={0}
              editable={false}
              placeholder="ประเภท"
              value="ระบบนำทาง"
            />
          </ModalSelector>
          <TouchableOpacity
            style={{
              flex: 3,
              backgroundColor: '#f1f1f1',
              borderWidth: 0,
              borderRadius: 3,
              height: 40,
              justifyContent: 'center',
              alignItems: 'center',
              marginLeft: 10,
              marginRight: 10
            }}
            onPress={() =>
              Communications.phonecall(
                this.props.customer.phone ? '+' + this.props.customer.phone : '',
                true
              )
            }>
            <Text
              style={{
                fontSize: 18,
                color: '#000000',
                fontFamily: 'dbhelvethaicax'
              }}>
              โทรหาลูกค้า
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              flex: 3,
              backgroundColor: '#f1f1f1',
              borderWidth: 0,
              borderRadius: 3,
              height: 40,
              justifyContent: 'center',
              alignItems: 'center',
              marginLeft: 10,
              marginRight: 10
            }}
            onPress={this.props.toggleReviewModal}>
            <Text
              style={{
                fontSize: 18,
                color: '#000000',
                fontFamily: 'dbhelvethaicax'
              }}>
              รีวิว
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    )
  }
}

const TripNumber = ({ runningNumber }) =>
  (runningNumber && (
    <Text
      style={{
        fontSize: 18,
        fontFamily: 'dbhelvethaicax_med',
        marginBottom: 5
      }}>
      หมายเลขทริป: {runningNumber}
    </Text>
  )) ||
  null
