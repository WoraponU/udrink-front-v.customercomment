import React from 'react'
import { View } from 'react-native'
import { Button } from 'react-native-elements'

export default class ButtonJob extends React.Component {
  constructor(props, context) {
    super(props, context)

    this.state = {
      state: '',
      blueText: '',
      blueState: 0,
      grayText: '',
      grayState: 0,
      waitBeforeId: '',
      waitAfterId: '',
      processing: false,
      buttonLeftColor: '#4ebbf9',
      textLeftColor: '#000000',
      buttonRightColor: '#b7b7b7',
      textRightColor: '#6a6666'
    }

    this.setUI = this.setUI.bind(this)
  }

  componentWillReceiveProps(nextProps) {
    this.setbutton(nextProps)
  }

  setUI(blueText = '', blueState = 1, grayText = '', grayState = 0) {
    this.setState({
      blueText: blueText,
      blueState: blueState,
      grayText: grayText,
      grayState: grayState,
    })
  }

  setbutton(nextProps) {
    if (nextProps.state == 'drive') {
      this.setState({
        // buttonLeftColor: '#b7b7b7',
        // textLeftColor: '#6a6666',
        // buttonRightColor: '#4ebbf9',
        // textRightColor: '#000000'
      })
    }

    if (!nextProps.processingButton) {
      if (nextProps.state == 'booked' || nextProps.state == 'accepted') {
        this.setUI('ไปหาลูกค้า', 1, 'ยกเลิก', 0)
      }
      else if (nextProps.state == 'travel') {
        this.setUI('ถึงที่รับ')
      }
      else if (nextProps.state == 'arrived') {
        this.setUI('ออกเดินทาง', 1)
      }
      else if (nextProps.state == 'on-job' || nextProps.state == 'wait-before') {
        this.setUI('ออกเดินทาง', 1)
      }
      else if (nextProps.state == 'on-board') {
        this.setUI('ออกเดินทาง', 1)
      }
      else if (nextProps.state == 'drive') {
        this.setUI('ถึงที่หมาย', 2, 'แวะ/รอ', 1)
      }
      else if (nextProps.state == 'drop') {
        this.setUI('ถึงที่หมาย', 2, 'แวะ/รอ', 1)
      }
      else if (nextProps.state == 'wait-after') {
        this.setUI('ถึงที่หมาย', 2, 'แวะ/รอ', 1)
      }
      else {
        // this.setUI('x1'+nextProps.state, 1, 'x1', 1)
      }
    }
    else if (nextProps.modalState) {
      // this.setUI('', 0, '', 0)
    }
    else {
      // this.setUI('x2'+nextProps.state, 1, 'x2s', 1)
    }
  }

  render() {
    const { isMapExpand } = this.props

    return (
      <View
        style={{
          position: 'absolute',
          bottom: 0,
          flexDirection: 'row',
          justifyContent: 'flex-end',
          alignItems: 'flex-end',
          zIndex: 1
        }}
      >
        {this.state.blueState > 0 ?
          <Button
            large
            raised
            accessibilityLabel="processLeft"
            disabled={(
              this.props.processingButton ||
              this.props.state == 'arrived' ||
              this.props.state == 'on-job' ||
              this.props.state == 'waitBefore' ||
              this.props.state == 'arrivedBefore' ||
              this.props.state == 'arrivedAfter' ||
              this.props.state == 'on-board'
            )}
            icon={this.props.processingButton ? { name: 'cached' } : null}
            title={this.state.blueText}
            buttonStyle={{
              backgroundColor: this.state.buttonLeftColor,
              padding: 20,
              height: isMapExpand ? 0 : 85,
            }}
            containerViewStyle={{
              height: isMapExpand ? 0 : 85,
              flex: this.state.blueState,
              marginLeft: 0,
              marginRight: 0,
            }}
            textStyle={{
              color: this.state.textLeftColor,
              fontSize: 25,
              fontFamily: 'dbhelvethaicax_bd',
            }}
            onPress={this.props.toggleConfirmModal}
          /> : null
        }
        
        {this.state.grayState > 0 ?
          <Button
            large
            raised
            accessibilityLabel="processRight"
            disabled={this.props.processingButton}
            icon={this.props.processingButton ? { name: 'cached' } : null}
            title={this.state.grayText}
            buttonStyle={{
              backgroundColor: this.state.buttonRightColor,
              padding: 30,
              paddingHorizontal: 10,
              height: 85,
              height: isMapExpand ? 0 : 85,
            }}
            containerViewStyle={{
              flex: this.state.grayState,
              height: isMapExpand ? 0 : 85,
              marginLeft: 0,
              marginRight: 0,
            }}
            textStyle={{
              color: this.state.textRightColor,
              fontSize: 25,
              fontFamily: 'dbhelvethaicax_bd'
            }}
            onPress={this.props.processRight}
          /> : null
        }
      </View>
    )
  }
}