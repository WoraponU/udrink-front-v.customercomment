import React from 'react'
import { View } from 'react-native'
import DetailBox from './DetailBox'
import MapReview from './MapReview'
import ButtonJob from './ButtonJob'
import CountDownModal from './CountDownModal'
import ConfirmModal from './ConfirmModal'
import ReviewModal from './ReviewModal'

export default class JobProcessView extends React.Component {
  state = {
    isMapExpand: false
  }

  componentDidUpdate(prevProps) {
    const { isTravelOver2Km } = this.props

    if (prevProps.isTravelOver2Km !== isTravelOver2Km && isTravelOver2Km) {
      this.props.processLeft()
    }
  }

  onToggleMapExpand = () => {
    const { isMapExpand } = this.state
    this.setState({ isMapExpand: !isMapExpand })
  }

  render() {
    const { isMapExpand } = this.state
    const {
      countNumber,
      modalState,
      tripInfo,
      customer,
      fromLocation,
      toLocation,
      pickupDate,
      priceNet,
      remark,
      state,
      processLeft,
      processRight,
      processingButton,
      processHideModal,
      buttonBlock,
      coords,
      timelimit,
      getLocationNow,
      coordsRoute,
      regionFromToMap,
      currentLocationMap,
      navigateScreen,
      stopsLocation,
      isOpenConfirmModal,
      toggleConfirmModal,
      isOpenReviewModal,
      toggleReviewModal
    } = this.props

    return (
      <View
        style={{
          flex: 1
        }}>
        <DetailBox
          state={state}
          isMapExpand={isMapExpand}
          stopsLocation={stopsLocation}
          tripInfo={tripInfo}
          customer={customer}
          fromLocation={fromLocation}
          toLocation={toLocation}
          pickupDate={pickupDate}
          priceNet={priceNet}
          remark={remark}
          currentLocationMap={currentLocationMap}
          navigateScreen={navigateScreen}
          toggleReviewModal={toggleReviewModal}
        />

        <ConfirmModal
          isOpenConfirmModal={isOpenConfirmModal}
          toggleConfirmModal={toggleConfirmModal}
          nextState={processLeft}
          state={state}
        />

        <ReviewModal
          isOpenReviewModal={isOpenReviewModal}
          toggleReviewModal={toggleReviewModal}
          customer={customer}
        />

        <ButtonJob
          isMapExpand={isMapExpand}
          toggleConfirmModal={toggleConfirmModal}
          state={state}
          processLeft={processLeft}
          processRight={processRight}
          processingButton={processingButton}
          modalState={modalState}
        />
        <CountDownModal
          tripInfo={tripInfo}
          toggleConfirmModal={toggleConfirmModal}
          state={state}
          customer={customer}
          stopsLocation={stopsLocation}
          fromLocation={fromLocation}
          toLocation={toLocation}
          pickupDate={pickupDate}
          countNumber={countNumber}
          modalState={modalState}
          processHideModal={processHideModal}
          buttonBlock={buttonBlock}
          timelimit={timelimit}
        />
        <MapReview
          state={state}
          isMapExpand={isMapExpand}
          onToggleMapExpand={this.onToggleMapExpand}
          tripInfo={tripInfo}
          stopsLocation={stopsLocation}
          customer={customer}
          fromLocation={fromLocation}
          toLocation={toLocation}
          pickupDate={pickupDate}
          priceNet={priceNet}
          modalState={modalState}
          regionFromToMap={regionFromToMap}
          currentLocationMap={currentLocationMap}
        />
      </View>
    )
  }
}
