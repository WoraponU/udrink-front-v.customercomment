import React from 'react'
import MapView from 'react-native-maps'
import { Icon } from 'react-native-elements'
import _ from 'lodash'
import { TouchableOpacity, Text, TextInput, View, ScrollView } from 'react-native'

export default class MapReview extends React.Component {
  state = {
    coords: {}
  }

  componentWillReceiveProps(nextProps) {
    const { currentLocationMap, fromLocation, toLocation, stopsLocation } = this.props
    const unInitialLocation = currentLocationMap.latitude === 0 && currentLocationMap.longitude === 0
    const fromLocationChanged = !_.isEqual(nextProps.fromLocation, fromLocation)
    const toLocationChanged = !_.isEqual(nextProps.toLocation, toLocation)
    const stopsLocationChanged = !_.isEqual(nextProps.stopsLocation, stopsLocation)
    const currentLocationMapChanged = !_.isEqual(
      nextProps.currentLocationMap,
      currentLocationMap
    )

    if (fromLocationChanged || toLocationChanged || stopsLocationChanged) {
      // this.setPathToMap(nextProps)
      this.fitAllMarkers(nextProps, 'onTripLocationChanged')
    }

    if (currentLocationMapChanged) {
      if (this.marker) {
        const duration = 500

        this.marker._component.animateMarkerToCoordinate(
          {
            latitude: nextProps.currentLocationMap.latitude,
            longitude: nextProps.currentLocationMap.longitude
          },
          duration
        )
      }

      if (unInitialLocation) {
        // this.setPathToMap(nextProps)
        this.fitAllMarkers(nextProps, 'onCurrentLocationChanged.fromZero')
      }
    }
  }

  onMapLayout = () => {
    // this.setPathToMap(this.props)
    this.fitAllMarkers(this.props, 'onMapLayout')
  }

  createCoordinate = location => ({
    latitude: location ? Number(location.lat) : 0,
    longitude: location ? Number(location.lng) : 0
  })

  fitAllMarkers = (props, notes='') => {
    const {currentLocationMap, fromLocation, toLocation, stopsLocation} = props
    
    let currentCoordinate
    if (
      currentLocationMap &&
      currentLocationMap.latitude !== 0 &&
      currentLocationMap.longitude !== 0
    ) {
      currentCoordinate = {
        latitude: currentLocationMap.latitude,
        longitude: currentLocationMap.longitude,
      }
      console.log(`currentCoordinate`, currentCoordinate)
    }

    const stopsCoordinates = 
      stopsLocation && 
      stopsLocation.map(address => this.createCoordinate(address))

    const allCoordinates = [
      this.createCoordinate(fromLocation),
      this.createCoordinate(toLocation),
      ...(stopsCoordinates || []),
      ...(currentCoordinate && [currentCoordinate] || [])
    ]

    console.log(`@MapReview, fitting markers ${notes}`, allCoordinates)
    this.map.fitToCoordinates(
      allCoordinates,
      { 
        edgePadding: { top: 100, right: 50, bottom: 50, left: 50 }, 
        animated: false 
      }
    )
  }

  // setPathToMap = async nextProps => {
    // if (
    //   nextProps.currentLocationMap &&
    //   nextProps.currentLocationMap.latitude !== 0 &&
    //   nextProps.currentLocationMap.longitude !== 0
    // ) {
    //   this.map.animateToRegion({
    //     latitude: nextProps.currentLocationMap.latitude,
    //     longitude: nextProps.currentLocationMap.longitude,
    //     latitudeDelta: 0.01,
    //     longitudeDelta: 0.01
    //   })
    // }
  // }

  render() {
    const { isMapExpand, onToggleMapExpand } = this.props
    const stopsLocationMarker =
      this.props.stopsLocation &&
      this.props.stopsLocation.map((address, index) => (
        <MapView.Marker
          key={index}
          coordinate={{
            latitude: address ? Number(address.lat) : 0,
            longitude: address ? Number(address.lng) : 0
          }}
          title={`แวะ ${index + 1}`}>
          <Icon name="person-pin" size={40} />
        </MapView.Marker>
      ))
    
    return (
      <View style={{
        flex: 1,
      }}>
        <MapView
          style={{
            flex: 1,
            marginTop: isMapExpand ? 0 : 230,
            marginBottom: isMapExpand ? 0 : 85,
            width: null,
            height: null
          }}
          ref={map => {
            this.map = map
          }}
          onLayout={this.onMapLayout}
          initialRegion={{
            latitude: this.props.currentLocationMap
              ? Number(this.props.currentLocationMap.latitude)
              : 0,
            longitude: this.props.currentLocationMap
              ? Number(this.props.currentLocationMap.longitude)
              : 0,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01
          }}>
          
          <MapView.Marker.Animated
            ref={marker => {
              this.marker = marker
            }}
            coordinate={{
              latitude: this.props.currentLocationMap
                ? Number(this.props.currentLocationMap.latitude)
                : 0,
              longitude: this.props.currentLocationMap
                ? Number(this.props.currentLocationMap.longitude)
                : 0
            }}
            title={'คนขับ'}>
            <Icon name="directions-walk" size={40} />
          </MapView.Marker.Animated>

          <MapView.Marker
            coordinate={{
              latitude: this.props.fromLocation ? Number(this.props.fromLocation.lat) : 0,
              longitude: this.props.fromLocation ? Number(this.props.fromLocation.lng) : 0
            }}
            title={'ที่รับ'}>
            <Icon name="directions-car" size={40} />
          </MapView.Marker>
          {stopsLocationMarker}

          <MapView.Marker
            coordinate={{
              latitude: this.props.toLocation ? Number(this.props.toLocation.lat) : 0,
              longitude: this.props.toLocation ? Number(this.props.toLocation.lng) : 0
            }}
            title={'ที่ส่ง'}>
            <Icon name="home" size={40} />
          </MapView.Marker>        
        </MapView>
        <TouchableOpacity 
          style={{
            position: 'absolute',
            backgroundColor: '#b7b7b782',
            right: 10,
            borderRadius: 3,
            paddingLeft: 5,
            paddingRight: 5,
            bottom: isMapExpand ? 10 : 90,
            height: 'auto'
          }}
          onPress={onToggleMapExpand}
        >
          { isMapExpand ? <Icon type='ionicon' name="md-contract" size={40} /> : <Icon type='ionicon' name="md-expand" size={40} /> }
        </TouchableOpacity>
      </View>
    )
  }
}
