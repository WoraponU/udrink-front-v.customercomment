const INCOMING_TRIPS = [
  {
    id: 1,
    fromTo: 'Thonglor - Mega Bangna',
    pickupTime: '22:10',
    icon: 'directions-car'
  },
  {
    id: 2,
    fromTo: 'Mega Bangna - Sukumwit 22',
    pickupTime: '23:20',
    icon: 'directions-car'
  },
  {
    id: 3,
    fromTo: 'Sukumwit 22 - Petchburi 33',
    pickupTime: '00:30',
    icon: 'directions-car'
  },
  {
    id: 4,
    fromTo: 'Petchburi 33 - Ratchada 48',
    pickupTime: '01:40',
    icon: 'directions-car'
  },
  {
    id: 5,
    fromTo: 'Ratchada 48 - Phaholyothin 55',
    pickupTime: '02:50',
    icon: 'directions-car'
  }
]

const genIncomingTrip = function* genIncomingTrip() {
  yield INCOMING_TRIPS[0]
  yield INCOMING_TRIPS[1]
  yield INCOMING_TRIPS[2]
  yield INCOMING_TRIPS[3]
  yield INCOMING_TRIPS[4]
}

const it = genIncomingTrip()

export const fetchIncomingTripAsync = token =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      const { value, done } = it.next()
      return resolve(value || {})
    }, 1000)
  })
