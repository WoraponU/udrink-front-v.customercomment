import _ from 'lodash'

const people = [
  { name: 'Nader', age: 36 },
  { name: 'Amanda', age: 24 },
  { name: 'Jason', age: 44 }
]

export const getPeopleAsync = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      return resolve(people)
    }, 1000)
  })
}

const authInfo = { token: '1234567890' }

export const loginAsync = ({ email, password }) =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      return resolve(authInfo)
    }, 1000)
  })

const trips = [
  {
    id: 1,
    fromTo: 'Thonglor - Mega Bangna',
    pickupTime: '23:45',
    icon: 'directions-car'
  },
  {
    id: 2,
    fromTo: 'Ekamai - Siam',
    pickupTime: '01:00',
    icon: 'ios-car',
    iconType: 'ionicon'
  },
  {
    id: 3,
    fromTo: ' รังสิต - ทองหล่อ',
    pickupTime: '01:00',
    icon: 'ios-car',
    iconType: 'ionicon'
  }
]

export const fetchTripsAsync = ({ token }) =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      return resolve(trips)
    }, 1000)
  })

const status = {
  state: 'assigned',
  trip: {
    id: 100,
    fromTo: 'Thonglor - Mega Bangna',
    pickupTime: '23:45',
    icon: 'directions-car'
  }
}

export const fetchDriverStatusAsync = ({ token }) =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      return resolve(status)
    }, 1000)
  })

const mapActionToState = action => {
  switch (action.toLowerCase()) {
    case 'accept':
      return 'accepted'
    case 'reject':
      return 'rejected'
    case 'depart':
      return 'travel'
    case 'arrive':
      return 'arrived'
  }
}
export const setDriverActionAsync = ({ token, newAction }) => {
  if (_.includes(['accept', 'reject'], newAction.toLowerCase())) {
    const yes = newAction === 'accept'
    // call driver-accept api    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        return resolve(mapActionToState(newAction))
      }, 1000)
    })
  } else {
    // call driver-action api    
    new Promise((resolve, reject) => {
      setTimeout(() => {
        return resolve(mapActionToState(newAction))
      }, 1000)
    })
  }
}
