import React from 'react'
import { View, Text, StyleSheet, ScrollView} from 'react-native'
import { Card, Button } from 'react-native-elements'

const TripInfo = ({ isFetching, data }) => (
  <ScrollView style={{
    flex: 1,
    marginHorizontal: 20,
    padding: 20,
    marginTop: 20,
    backgroundColor: '#29B6F6',    
  }}>
    {/* {data && data.id ? <Text style={styles.info}>รหัสงาน {data.id}</Text> : null}
    {data && data.fromTo ? <Text style={styles.info}>สถานที่รับส่ง {data.fromTo}</Text> : null}
    {data && data.pickupTime ? <Text style={styles.info}>เวลา {data.pickupTime}</Text> : null} */}
    <Text style={styles.info}>ทะเบียนรถ-xxxxx</Text>
    <Text style={styles.info}>เวลาที่ลูกค้าให้รอ-xxxxx</Text>
    <Text style={styles.info}>ค่าบริการโดยประมาณ-xxxxx</Text>
    <Text style={styles.info}>วิธีการชำระเงิน-xxxxx</Text>
    <Text style={styles.info}>หมายเหตุจากลูกค้า-xxxxx</Text>
    <Text style={styles.info}>หมายเหตุ-xxxxx</Text>
  </ScrollView>
)

const styles = StyleSheet.create({
  info: {
    fontSize: 20,
    color: '#FFFFFF',
    marginVertical: 5,
  }
})

export default TripInfo
