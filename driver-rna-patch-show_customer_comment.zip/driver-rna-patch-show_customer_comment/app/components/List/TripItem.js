import React from 'react'
import { StyleSheet, View, Text, TouchableHighlight } from 'react-native'
import { Card, Button, Icon, Badge } from 'react-native-elements'

const TripItem = ({ trip, onPress }) => (
  <Card
    style={{      
      backgroundColor: '#ffffff',
      marginVertical: 8,
      marginHorizontal: 16,
      paddingHorizontal: 18,
      borderRadius: 10,
      height: 155,
      elevation: 5
    }}    
    onPress={_ => onPress(trip)}
  >
    <View
      style={{
        flexDirection: 'row',
        marginBottom: 20,
        paddingTop: 12             
      }}
    >
      <Text
        style={{
          flex: 20,
          color: '#0b0b0b',
          fontSize: 12,
          fontWeight: 'bold'
        }}
      >
        งานหมายเลข: SAT2012
      </Text>
      <Text
        style={{
          flex: 15,
          color: '#0b0b0b',
          fontSize: 12,
          fontWeight: 'bold'
        }}
      >
        วันที่ 2/12/2017
      </Text>
      <Text
        style={{
          flex: 10,
          color: '#0b0b0b',
          fontSize: 12,
          fontWeight: 'bold'
        }}
      >
        เวลา 21:00
      </Text>
    </View>

    <View
      style={{
        marginBottom: 23,
      }}
    >
      <Text
        style={{
          color: '#0b0b0b',
          fontSize: 12,
          fontWeight: 'bold',
          marginBottom: 10
        }}
      >
        สถานที่รับ: ทองหล่อซอย 10 ตึกเมเจอร์ ทาวเวอร์
      </Text>
      <Text
        style={{
          color: '#0b0b0b',
          fontSize: 12,
          fontWeight: 'bold'
        }}
      >
        สถานที่ส่ง: สุขุมวิท 23 แขวงคลองเตยเหนือ เขตวัฒนา
      </Text>
    </View>
    <View
      style={{
        justifyContent: 'flex-end',
        marginBottom: 10,  
      }}
    >
      <Text
        style={{
          color: '#0b0b0b',
          fontSize: 12,
          fontWeight: 'bold'
        }}
      >
        รายละเอียดเพิ่มเติม: รถเกียร์กระปุก บ้านอยู่ลึกเรียกแท๊กซี่ยาก
      </Text>
    </View>
  </Card>
)

const styles = StyleSheet.create({
  main: {
  },
  header: {
    marginVertical: 5,
    color: '#0b0b0b'
  },
  content: {
    marginVertical: 5,
    color: '#0b0b0b'
  }
})

export default TripItem
