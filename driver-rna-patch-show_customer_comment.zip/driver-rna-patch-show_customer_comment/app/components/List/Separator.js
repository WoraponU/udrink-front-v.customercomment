import React from 'react'
import { StyleSheet, View } from 'react-native'

const Separator = () => <View style={styles.separator} />

const styles = StyleSheet.create({
  separator: {
    backgroundColor: '#EAEAEA',
    height: 5,
    flex: 1,
    marginLeft: 20
  }
})

export default Separator
