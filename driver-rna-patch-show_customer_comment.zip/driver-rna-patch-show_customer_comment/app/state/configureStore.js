import { createStore, combineReducers, applyMiddleware } from 'redux'
import { composeWithDevTools } from 'redux-devtools-extension'
import * as reducers from './paco'
import * as v2Reducers from './v2'
// import * as reducers from './ducks'

const rootReducer = combineReducers({
  ...reducers,
  ...v2Reducers
})

// import createSagaMiddleware from 'redux-saga'
// import rootSaga from './ducks/sagas'
import thunk from 'redux-thunk'

// const sagaMiddleware = createSagaMiddleware()

export default function configureStore() {
  const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(thunk)))
  // sagaMiddleware.run(rootSaga)

  return store
}
