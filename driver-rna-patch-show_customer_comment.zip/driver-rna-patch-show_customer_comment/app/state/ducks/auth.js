import { fetchInfo2 } from '../../config/api'
import { driverApi } from '../../config/hostname'

// Actions
export const LOGIN_REQUEST = 'auth/LOGIN_REQUEST'
export const LOGIN_SUCCESS = 'auth/LOGIN_SUCCESS'
export const LOGIN_FAILURE = 'auth/LOGIN_FAILURE'

// Reducer
const initialState = {
  token: null,
  isAuthenticated: false,
  isFetching: false,
  error: false
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case LOGIN_REQUEST:
      return {
        ...state,
        token: null,
        isAuthenticated: false,
        isFetching: true,
        error: false,
        creds: action.creds,
        responseJson: action.responseJson
      }
    case LOGIN_SUCCESS:
      return {
        ...state,
        token: action.data.token,
        isAuthenticated: true,
        isFetching: false
      }
    case LOGIN_FAILURE:
      return {
        ...state,
        isFetching: false,
        error: true
      }
    default:
      return state
  }
}

// Action Creators
// export function requestLogin(creds) {
//   let responseJson = await fetchInfo2(driverApi + 'driver-login', creds)
//   return {
//     type: LOGIN_REQUEST,
//     creds,
//     responseJson
//   }
// }