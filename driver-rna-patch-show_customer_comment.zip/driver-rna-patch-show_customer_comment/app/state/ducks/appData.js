import getPeople from '../../api'

// Actions
export const FETCHING_DATA = 'appData/FETCHING_DATA'
export const FETCHING_DATA_SUCCESS = 'appData/FETCHING_DATA_SUCCESS'
export const FETCHING_DATA_FAILURE = 'appData/FETCHING_DATA_FAILURE'

// Reducer
const initialState = {
  data: [],
  dataFetched: false,
  isFetching: false,
  error: false
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case FETCHING_DATA:
      return {
        ...state,
        data: [],
        isFetching: true
      }
    case FETCHING_DATA_SUCCESS:
      return {
        ...state,
        isFetching: false,
        data: action.data
      }
    case FETCHING_DATA_FAILURE:
      return {
        ...state,
        isFetching: false,
        error: true
      }
    default:
      return state
  }
}

// Action Creators
export function fetchData() {
  return {
    type: FETCHING_DATA
  }
}
