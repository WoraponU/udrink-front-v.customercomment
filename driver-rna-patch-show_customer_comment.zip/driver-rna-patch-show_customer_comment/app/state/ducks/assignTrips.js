import _ from 'lodash'

// Actions
export const READY_FOR_TRIPS = 'trips/READY_FOR_TRIPS'
export const PROCESS_INCOMING_TRIPS = 'trips/PROCESS_INCOMING_TRIPS'
export const SAVING_ASSIGN_TRIP = 'trips/SAVING_ASSIGN_TRIP'
export const SAVING_ASSIGN_TRIP_SUCCESS = 'trips/SAVING_ASSIGN_TRIP_SUCCESS'
export const SAVING_ASSIGN_TRIP_FAILURE = 'trips/SAVING_ASSIGN_TRIP_FAILURE'

export const ACCEPT_TRIP_ASSIGNMENT = 'trips/ACCEPT_TRIP_ASSIGNMENT'
export const REJECT_TRIP_ASSIGNMENT = 'trips/REJECT_TRIP_ASSIGNMENT'
export const CLOSE_TRIP_ASSIGNMENT = 'trips/CLOSE_TRIP_ASSIGNMENT'
export const DONE_HANDLE_ASSIGNMENT = 'trips/DONE_HANDLE_ASSIGNMENT'

// State shaoe
const initialState = {
  trips: {
    /*
    [id]: {
      id,
      fromTo,
      pickupTime,
      icon,
      iconType
    }, ...
  */
  },
  dataFetched: false,
  isFetching: false,
  error: false
}

// Reducer
export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case SAVING_ASSIGN_TRIP:
      return {
        ...state,
        dataFetched: false,
        isFetching: true
      }
    case SAVING_ASSIGN_TRIP_SUCCESS:
      const trip = action.trip
      const tripId = trip && trip.id
      const currentTrip = _.get(state.trips, tripId + '', {})
      const incomingTrip = (tripId && trip) || {}
      updatedTrip = !_.isEmpty(incomingTrip)
        ? { [tripId]: { ...currentTrip, ...incomingTrip } }
        : {}
      return {
        ...state,
        trips: { ...state.trips, ...updatedTrip },
        lastFetched: new Date(),
        dataFetched: true,
        isFetching: false
      }
    case SAVING_ASSIGN_TRIP_FAILURE:
      return {
        ...state,
        isFetching: false,
        error: true
      }
    case DONE_HANDLE_ASSIGNMENT:
      tripId = action.tripId
      currentTrip = _.get(state.trips, tripId + '', {})
      const handledTrip = { assignmentHandled: true }
      updatedTrip = !_.isEmpty(currentTrip)
        ? { [tripId]: { ...currentTrip, ...handledTrip } }
        : {}
      return {
        ...state,
        trips: { ...state.trips, ...updatedTrip }
      }
    default:
      return state
  }
}

// Action Creators
export function readyForTrips() {
  return {
    type: READY_FOR_TRIPS
  }
}
export function handleTripAssignment(token, command) {
  switch (command.toLowerCase()) {
    case 'accept':
      return { type: ACCEPT_TRIP_ASSIGNMENT, token, command }
    case 'reject':
      return { type: REJECT_TRIP_ASSIGNMENT, token, command }
    default:
      return { type: CLOSE_TRIP_ASSIGNMENT }
  }
}
export function doneHandleAssignment(tripId) {
  return {
    type: DONE_HANDLE_ASSIGNMENT,
    tripId
  }
}

// State Selectors
export function getTripsListFromState(state) {
  const trips = state.trips
  return _.reduce(
    trips,
    function(result, value, key) {
      result.push(value)
      return result
    },
    []
  )
}
export function getTripById(state, tripId) {
  const trips = state.activeTrips.trips
  return _.get(trips, tripId + '', {})
}
export function isAssignmentHandled(trip) {
  return !_.isEmpty(trip) && _.get(trip, 'assignmentHandled', false)
}
