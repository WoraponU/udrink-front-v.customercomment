import {
  FETCHING_STATUS,
  FETCHING_STATUS_SUCCESS,
  FETCHING_STATUS_FAILURE,
  SETTING_ACTION,
  SETTING_ACTION_SUCCESS,
  SETTING_ACTION_FAILURE
} from './driver'
import { put, takeEvery } from 'redux-saga/effects'
import { fetchDriverStatusAsync, setDriverActionAsync } from '../../api'

const fetchDriverStatus = function* fetchDriverStatus(action) {
  try {
    const data = yield fetchDriverStatusAsync({ token: action.token })
    yield put({ type: FETCHING_STATUS_SUCCESS, data })
  } catch (e) {
    yield put({ type: FETCHING_STATUS_FAILURE })
  }
}

const setDriverAction = function* setDriverAction({ token, newAction }) {
  console.log({ newAction })
  try {
    const newState = yield setDriverActionAsync({ token, newAction })
    yield put({ type: SETTING_ACTION_SUCCESS, newState })
  } catch (e) {
    yield put({ type: SETTING_ACTION_FAILURE })
  }
}

const driverSaga = function* driverSaga() {
  yield takeEvery(FETCHING_STATUS, fetchDriverStatus)
  yield takeEvery(SETTING_ACTION, setDriverAction)
}

export default driverSaga
