import { FETCHING_TRIPS, FETCHING_TRIPS_SUCCESS, FETCHING_TRIPS_FAILURE } from './trips'
import { put, takeEvery } from 'redux-saga/effects'
import { fetchTripsAsync } from '../../api'

const fetchTrips = function* fetchTrips(action) {
  try {
    const data = yield fetchTripsAsync({ token: action.token })
    yield put({ type: FETCHING_TRIPS_SUCCESS, data })
  } catch (e) {
    yield put({ type: FETCHING_TRIPS_FAILURE })
  }
}

const tripsSaga = function* tripsSaga() {
  yield takeEvery(FETCHING_TRIPS, fetchTrips)
}

export default tripsSaga
