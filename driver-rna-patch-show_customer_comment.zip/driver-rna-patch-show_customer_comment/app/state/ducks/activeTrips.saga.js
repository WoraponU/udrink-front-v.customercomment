import {
  FETCHING_ACTIVE_TRIPS,
  FETCHING_ACTIVE_TRIPS_SUCCESS,
  FETCHING_ACTIVE_TRIPS_FAILURE,
  ACCEPT_TRIP_ASSIGNMENT,
  REJECT_TRIP_ASSIGNMENT,
  CLOSE_TRIP_ASSIGNMENT,
  doneHandleAssignment,
  getTripById,
  isAssignmentHandled
} from './activeTrips.js'
import { FETCHING_STATUS_SUCCESS, setAction } from './driver.js'

import { put, takeEvery, take, call, select } from 'redux-saga/effects'
import { fetchDriverStatusAsync } from '../../api'
import { NavigationActions } from 'react-navigation'

const fetchActiveTrips = function* fetchActiveTrips(action) {
  try {
    const driverStatus = yield fetchDriverStatusAsync({ token: action.token })
    const { state, trip } = driverStatus
    let tripData = {}
    switch (state) {
      case 'assigned':
      case 'accepted':
      case 'booked':
      case 'travel':
      case 'arrived':
      case 'on-job':
      case 'wait-before':
      case 'on-board':
      case 'drive':
      case 'wait-after':
      case 'drop':
      case 'off-job':
      case 'evaluated':
        tripData = { trip }
        break
      default: // Do Nothing
    }
    yield put({ type: FETCHING_ACTIVE_TRIPS_SUCCESS, data: tripData })
    yield put({ type: FETCHING_STATUS_SUCCESS, data: driverStatus })

    let newTrip
    if (driverStatus.state === 'assigned' && trip && trip.id) {
      const tripId = trip.id
      const currentTrip = yield select(getTripById, tripId)
      newTrip = !isAssignmentHandled(currentTrip) && trip
    }
    return { driverStatus, newTrip }
  } catch (e) {
    yield put({ type: FETCHING_ACTIVE_TRIPS_SUCCESS })
  }
}

const activeTripsSaga = function* activeTripsSaga() {
  // yield takeEvery(FETCHING_ACTIVE_TRIPS, fetchActiveTrips)

  while (true) {
    const action = yield take(FETCHING_ACTIVE_TRIPS)
    const { driverStatus, newTrip } = yield call(fetchActiveTrips, action)

    if (newTrip) {
      const tripId = newTrip.id
      // yield put(
      //   NavigationActions.navigate({
      //     routeName: 'TripAssignment',
      //     params: {}
      //   })
      // )
      const respondAction = yield take([
        ACCEPT_TRIP_ASSIGNMENT,
        REJECT_TRIP_ASSIGNMENT,
        CLOSE_TRIP_ASSIGNMENT
      ])
      console.log({ respondAction })
      const { type, command, token } = respondAction
      switch (type) {
        case ACCEPT_TRIP_ASSIGNMENT:
          yield put(setAction(token, command))
          break
        case REJECT_TRIP_ASSIGNMENT:
          yield put(setAction(token, command))
          break
      }

      // TODO: move into driver/SETTING_ACTION_SUCCESS reducer
      yield put(doneHandleAssignment(tripId))

      // Return to previous screen after handle action
      yield put(NavigationActions.back())
    }
  }
}

export default activeTripsSaga
