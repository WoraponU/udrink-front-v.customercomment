import _ from 'lodash'

// Actions
export const FETCHING_ACTIVE_TRIPS = 'trips/FETCHING_ACTIVE_TRIPS'
export const FETCHING_ACTIVE_TRIPS_SUCCESS = 'trips/FETCHING_ACTIVE_TRIPS_SUCCESS'
export const FETCHING_ACTIVE_TRIPS_FAILURE = 'trips/FETCHING_ACTIVE_TRIPS_FAILURE'

export const ACCEPT_TRIP_ASSIGNMENT = 'trips/ACCEPT_TRIP_ASSIGNMENT'
export const REJECT_TRIP_ASSIGNMENT = 'trips/REJECT_TRIP_ASSIGNMENT'
export const CLOSE_TRIP_ASSIGNMENT = 'trips/CLOSE_TRIP_ASSIGNMENT'
export const DONE_HANDLE_ASSIGNMENT = 'trips/DONE_HANDLE_ASSIGNMENT'

// Reducer
const initialState = {
  trips: {},
  dataFetched: false,
  isFetching: false,
  error: false
  // assignmentHandled: false
}

export default function reducer(state = initialState, action = {}) {
  let tripId, currentTrip, updatedTrip
  switch (action.type) {
    case FETCHING_ACTIVE_TRIPS:
      return {
        ...state,
        dataFetched: false,
        isFetching: true
      }
    case FETCHING_ACTIVE_TRIPS_SUCCESS:
      const { trip } = action.data
      tripId = trip && trip.id
      currentTrip = _.get(state.trips, tripId + '', {})
      const incomingTrip = (tripId && trip) || {}
      updatedTrip = !_.isEmpty(incomingTrip)
        ? { [tripId]: { ...currentTrip, ...incomingTrip } }
        : {}
      return {
        ...state,
        trips: { ...state.trips, ...updatedTrip },
        lastFetched: new Date(),
        dataFetched: true,
        isFetching: false
      }
    case FETCHING_ACTIVE_TRIPS_FAILURE:
      return {
        ...state,
        isFetching: false,
        error: true
      }
    case DONE_HANDLE_ASSIGNMENT:
      tripId = action.tripId
      currentTrip = _.get(state.trips, tripId + '', {})
      const handledTrip = { assignmentHandled: true }
      updatedTrip = !_.isEmpty(currentTrip)
        ? { [tripId]: { ...currentTrip, ...handledTrip } }
        : {}
      return {
        ...state,
        trips: { ...state.trips, ...updatedTrip }
      }
    default:
      return state
  }
}

// Action Creators
export function fetchActiveTrips(token) {
  return {
    type: FETCHING_ACTIVE_TRIPS,
    token
  }
}
export function handleTripAssignment(token, command) {
  switch (command.toLowerCase()) {
    case 'accept':
      return { type: ACCEPT_TRIP_ASSIGNMENT, token, command }
    case 'reject':
      return { type: REJECT_TRIP_ASSIGNMENT, token, command }
    default:
      return { type: CLOSE_TRIP_ASSIGNMENT }
  }
}
export function doneHandleAssignment(tripId) {
  return {
    type: DONE_HANDLE_ASSIGNMENT,
    tripId
  }
}

// State Selectors
export function getTripsListFromState(state) {
  const trips = state.trips
  return _.reduce(
    trips,
    function(result, value, key) {
      result.push(value)
      return result
    },
    []
  )
}
export function getTripById(state, tripId) {
  const trips = state.activeTrips.trips
  return _.get(trips, tripId + '', {})
}
export function isAssignmentHandled(trip) {
  return !_.isEmpty(trip) && _.get(trip, 'assignmentHandled', false)
}
