import { LOGIN_REQUEST, LOGIN_SUCCESS, LOGIN_FAILURE } from './auth'
import { delay } from 'redux-saga'
import { put, takeEvery } from 'redux-saga/effects'
import { loginAsync } from '../../api'
import { NavigationActions } from 'react-navigation'

const navigateToTrips = NavigationActions.navigate({
  routeName: 'Trips',
  params: {}
})

const requestLogin = function* requestLogin(action) {
  try {
    const data = yield loginAsync(action.creds)
    yield put({ type: LOGIN_SUCCESS, data })
    yield delay(1000)
    yield put(navigateToTrips)
  } catch (e) {
    yield put({ type: LOGIN_FAILURE })
  }
}

const authSaga = function* authSaga() {
  yield takeEvery(LOGIN_REQUEST, requestLogin)
}

export default authSaga
