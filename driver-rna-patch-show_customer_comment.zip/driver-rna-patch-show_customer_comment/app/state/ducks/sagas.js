import { all } from 'redux-saga/effects'
import authSaga from './auth.saga'
import tripsSaga from './trips.saga'
import driverSaga from './driver.saga'
import activeTripsSaga from './activeTrips.saga'
import assignTripsSaga from './assignTrips.saga'

const rootSaga = function* rootSaga() {
  yield all([authSaga(), tripsSaga(), driverSaga(), activeTripsSaga(), assignTripsSaga()])
}

export default rootSaga
