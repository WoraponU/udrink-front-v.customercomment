// Actions
export const FETCHING_TRIPS = 'trips/FETCHING_TRIPS'
export const FETCHING_TRIPS_SUCCESS = 'trips/FETCHING_TRIPS_SUCCESS'
export const FETCHING_TRIPS_FAILURE = 'trips/FETCHING_TRIPS_FAILURE'

// Reducer
const initialState = {
  data: [],
  dataFetched: false,
  isFetching: false,
  error: false
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case FETCHING_TRIPS:
      return {
        ...state,
        data: [],
        dataFetched: false,
        isFetching: true
      }
    case FETCHING_TRIPS_SUCCESS:
      return {
        ...state,
        data: action.data,
        dataFetched: true,
        isFetching: false
      }
    case FETCHING_TRIPS_FAILURE:
      return {
        ...state,
        isFetching: false,
        error: true
      }
    default:
      return state
  }
}

// Action Creators
export function fetchTrips(token) {
  return {
    type: FETCHING_TRIPS,
    token
  }
}
