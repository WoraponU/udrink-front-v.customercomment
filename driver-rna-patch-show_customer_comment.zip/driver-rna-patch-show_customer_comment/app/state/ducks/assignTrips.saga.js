import { all, put, actionChannel, take, call, select } from 'redux-saga/effects'
import { delay, buffers } from 'redux-saga'
import { NavigationActions } from 'react-navigation'
import _ from 'lodash'

import {
  READY_FOR_TRIPS,
  PROCESS_INCOMING_TRIPS,
  SAVING_ASSIGN_TRIP,
  SAVING_ASSIGN_TRIP_SUCCESS,
  SAVING_ASSIGN_TRIP_FAILURE,
  ACCEPT_TRIP_ASSIGNMENT,
  REJECT_TRIP_ASSIGNMENT,
  CLOSE_TRIP_ASSIGNMENT,
  doneHandleAssignment,
  getTripById,
  isAssignmentHandled
} from './assignTrips'
import { FETCHING_STATUS_SUCCESS, setAction } from './driver.js'

import { fetchIncomingTripAsync } from '../../api/v2'

const fetchIncomingTrip = function* fetchIncomingTrip() {
  let newTrip = {}
  try {
    newTrip = yield call(fetchIncomingTripAsync)
  } catch (e) {}
  return newTrip
}

const watchIncomingTrips = function* watchIncomingTrips() {
  yield take(READY_FOR_TRIPS)
  // TODO: Make it cancellable via NOT_READY_NOW
  while (true) {
    const newTrip = yield call(fetchIncomingTrip)
    if (!_.isEmpty(newTrip)) {
      yield put({ type: PROCESS_INCOMING_TRIPS, trip: newTrip })
    } else {
      break
    }
    // TODO: Make it random delay
    yield call(delay, 1000)
  }
}

const saveAssignTrip = function* saveAssignTrip({ trip }) {
  yield put({ type: SAVING_ASSIGN_TRIP })
  yield put({ type: SAVING_ASSIGN_TRIP_SUCCESS, trip })
}

const handleAssignTrip = function* handleAssignTrip({ trip }) {
  const tripId = trip.id
  // yield put(
  //   NavigationActions.navigate({
  //     routeName: 'TripAssignment',
  //     params: { trip }
  //   })
  // )
  const respondAction = yield take([
    ACCEPT_TRIP_ASSIGNMENT,
    REJECT_TRIP_ASSIGNMENT,
    CLOSE_TRIP_ASSIGNMENT
  ])
  console.log({ respondAction })

  const { type, command, token } = respondAction
  switch (type) {
    case ACCEPT_TRIP_ASSIGNMENT:
      yield put(setAction(token, command))
      break
    case REJECT_TRIP_ASSIGNMENT:
      yield put(setAction(token, command))
      break
  }

  // TODO: save handled result
  yield put(doneHandleAssignment(tripId))

  // Return to previous screen after handle action
  yield put(NavigationActions.back())
}

const processIncomingTrips = function* processIncomingTrips() {
  const incomingChannel = yield actionChannel(
    PROCESS_INCOMING_TRIPS,
    buffers.dropping(10)
  )
  while (true) {
    const action = yield take(incomingChannel)
    yield call(saveAssignTrip, action)
    yield call(delay, 1000)
    yield call(handleAssignTrip, action)
    yield call(delay, 1000)
  }
}

const assignTripsSaga = function* assignTripsSaga() {
  yield all([call(watchIncomingTrips), call(processIncomingTrips)])
}

export default assignTripsSaga
