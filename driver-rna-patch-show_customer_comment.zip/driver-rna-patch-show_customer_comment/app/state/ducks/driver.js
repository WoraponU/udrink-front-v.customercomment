// Actions
export const FETCHING_STATUS = 'driver/FETCHING_STATUS'
export const FETCHING_STATUS_SUCCESS = 'driver/FETCHING_STATUS_SUCCESS'
export const FETCHING_STATUS_FAILURE = 'driver/FETCHING_STATUS_FAILURE'

export const SETTING_ACTION = 'driver/SETTING_ACTION'
export const SETTING_ACTION_SUCCESS = 'driver/SETTING_ACTION_SUCCESS'
export const SETTING_ACTION_FAILURE = 'driver/SETTING_ACTION_FAILURE'

// Reducer
const initialState = {
  data: undefined,
  dataFetched: false,
  isFetching: false,
  error: false
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case FETCHING_STATUS:
      return {
        ...state,
        data: undefined,
        dataFetched: false,
        isFetching: true
      }
    case FETCHING_STATUS_SUCCESS:
      return {
        ...state,
        data: action.data,
        dataFetched: true,
        isFetching: false
      }
    case FETCHING_STATUS_FAILURE:
      return {
        ...state,
        isFetching: false,
        error: true
      }

    case SETTING_ACTION:
      return {
        ...state,
        isSetting: true,
        dataUpdated: false
      }
    case SETTING_ACTION_SUCCESS:
      console.log({ newState: action.newState })
      const newProps = action && action.newState ? { state: action.newState } : {}
      return {
        ...state,
        data: { ...state.data, ...newProps },
        isSetting: false,
        dataUpdated: true,
        lastUpdated: new Date()
      }
    case SETTING_ACTION_FAILURE:
      return {
        ...state,
        isSetting: false,
        error: true
      }
    default:
      return state
  }
}

// Action Creators
export function fetchState(token) {
  return {
    type: FETCHING_STATUS,
    token
  }
}

export function setAction(token, newAction) {
  return {
    type: SETTING_ACTION,
    token,
    newAction
  }
}
