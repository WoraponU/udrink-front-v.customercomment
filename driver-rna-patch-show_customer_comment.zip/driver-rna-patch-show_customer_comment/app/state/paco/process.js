import { navigateToScreen } from './nav'
import { pollingTime, intervalName, COMPENSATE_TIME } from '../../config/uiconfig'
import timer from 'react-native-timer'
import { fetchInfo2, getState2 as apiGetState } from '../../config/api'
import { driverApi } from '../../config/hostname'
import moment from 'moment'
import { tripSetCurrentState } from './trip'


// Actions
export const PROCESS_FETCH_START = 'process/PROCESS_FETCH_START'
export const PROCESS_FETCH_END = 'process/PROCESS_FETCH_END'
export const PROCESS_SET_CURRENT_STATE = 'process/PROCESS_SET_CURRENT_STATE'
export const PROCESS_SET_ARRIVED_BEFORE_TIMER = 'process/PROCESS_SET_ARRIVED_BEFORE_TIMER'
export const PROCESS_SET_ARRIVED_AFTER_TIMER = 'process/PROCESS_SET_ARRIVED_AFTER_TIMER'
export const PROCESS_SET_DROP_TIMER = 'process/PROCESS_SET_DROP_TIMER'
export const PROCESS_ENDING = 'process/PROCESS_ENDING'
export const PROCESS_SET_DROP_MARK = 'process/PROCESS_SET_DROP_MARK'
export const PROCESS_SET_CURRENT_LOCATION = 'process/PROCESS_SET_CURRENT_LOCATION'
export const PROCESS_SET_REGION_FROM_TO = 'process/PROCESS_SET_REGION_FROM_TO'
export const THROW_ERROR = 'process/THROW_ERROR'
export const CLEAR_ERROR = 'process/CLEAR_ERROR'
//Reducer
const initialState = {
  fetching: false,
  state: '',
  lastStateChanged: '',
  tripId: '',
  tripInfo: {
    pickupDate: '',
    fromLocation: {
      latitude: 0,
      longitude: 0
    },
    toLocation: {
      latitude: 0,
      longitude: 0
    }
  },
  arriveBeforeTimer: moment.duration(0),
  arrival: '',
  arriveAfterTimer: moment.duration(0),
  dropTimer: moment.duration(0),
  dropTime: '',
  ending: false,
  regionFromToMap: {
    latitude: 0,
    longitude: 0,
    latitudeDelta: 0,
    longitudeDelta: 0
  },
  currentLocationMap: {
    latitude: 0,
    longitude: 0
  },
  errorMessage: ''
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case PROCESS_FETCH_START:
      return {
        ...state,
        fetching: true
      }
    case PROCESS_FETCH_END:
      return {
        ...state,
        fetching: false
      }
    case PROCESS_SET_CURRENT_STATE:
      return {
        ...state,
        ...(action.data.state && { state: action.data.state }),
        ...(action.data.lastStateChanged && { lastStateChanged: moment(action.data.lastStateChanged) }),
        ...(action.data.trip && { tripInfo: action.data.trip }),
        ...(action.data.tripId && { tripId: action.data.tripId })
      }
    case PROCESS_SET_ARRIVED_BEFORE_TIMER:
      return {
        ...state,
        arriveBeforeTimer: action.arriveBeforeTimer
      }
    case PROCESS_SET_ARRIVED_AFTER_TIMER:
      return {
        ...state,
        arriveAfterTimer: action.arriveAfterTimer,
        arriveBeforeTimer: action.arriveBeforeTimer
      }
    case PROCESS_SET_DROP_TIMER:
      return {
        ...state,
        dropTimer: action.dropTimer
      }
    case PROCESS_ENDING:
      return {
        ...state,
        ending: action.end
      }
    case PROCESS_SET_DROP_MARK:
      return {
        ...state,
        dropMark: action.dropMark
      }
    case PROCESS_SET_CURRENT_LOCATION:
      return {
        ...state,
        currentLocationMap: action.location
      }
    case PROCESS_SET_REGION_FROM_TO:
      return {
        ...state,
        regionFromToMap: action.region
      }
    case THROW_ERROR:
      return {
        ...state,
        fetching: false,
        errorMessage: action.errorMessage
      }
    case CLEAR_ERROR:
      return {
        ...state,
        errorMessage: ''
      }
    default:
      return state
  }
}

// Action Creators
export function throwErrorAction(error) {
  return {
    type: THROW_ERROR,
    errorMessage: error
  }
}

export function clearError() {
  return {
    type: CLEAR_ERROR
  }
}

export function setInitialState() {
  return async (dispatch, getState) => {
    try {
      dispatch(processFetchStart())
      const { token } = getState().auth
      const { state, trip, tripId, lastStateChanged } = await apiGetState(token)

      dispatch(
        tripSetCurrentState({
          state,
          trip,
          tripId,
          lastStateChanged
        })
      )
      dispatch(processFetchEnd())
      return dispatch(processAdjustUiFromState())
    }
    catch (error) {
      dispatch(throwErrorAction(error))
    }
  }
}

export function processAdjustUiFromState() {
  return async (dispatch, getState) => {
    const { state, tripInfo, lastStateChanged } = getState().trip
    const { pickupDate } = tripInfo
    if (
      state == 'arrived' ||
      state == 'waitBefore' ||
      state == 'arrivedBefore' ||
      state == 'arrivedAfter'
    ) {
      const arrivalDiff = new Date(lastStateChanged).getTime() + COMPENSATE_TIME - new Date(pickupDate).getTime()
      if (arrivalDiff < 0) {
        return dispatch(handleStateArrivedBefore(pickupDate))
      }
      else if (arrivalDiff >= 0) {
        return dispatch(handleStateArrivedAfter(pickupDate))
      }
    }
    else if (state == 'on-job') {
      dispatch(tripSetCurrentState({
        state: 'waitBefore'
      }))
      return dispatch(processArrivedAfterCountUp(pickupDate))
    }
    else if (state == 'drop') {
      dispatch(processDropTimer(lastStateChanged))
    }
    else {

    }
  }
}


export function processSetRegionFromTo(region) {
  return {
    type: PROCESS_SET_REGION_FROM_TO,
    region: region
  }
}

export function processSetCurrentLocation(location) {
  return {
    type: PROCESS_SET_CURRENT_LOCATION,
    location: location
  }
}

export function processDepart() {
  return async (dispatch, getState) => {
    return dispatch(callApi('v2/driver-action/depart', 1))
  }
}

export function processArrive(mode = true) {
  return async (dispatch, getState) => {
    const { tripInfo, lastStateChanged } = getState().trip
    const { pickupDate } = tripInfo
    if (mode) {
      return dispatch(callApi('v2/driver-action/arrive', 1))
        .then((done) => {
          if (done) {
            const arrivalDiff = new Date(lastStateChanged).getTime() + COMPENSATE_TIME - new Date(pickupDate).getTime()            
            if (arrivalDiff < 0) {
              return dispatch(handleStateArrivedBefore(pickupDate))
            }
            else if (arrivalDiff >= 0) {
              return dispatch(handleStateArrivedAfter(pickupDate))
            }
          }

        })
    }
    else {
      return dispatch(callApi('v2/driver-action/arrive', 1))
    }
  }
}

export function handleStateArrivedAfter(pickupDate) {
  return async (dispatch) => {
    dispatch(tripSetCurrentState({
      state: 'arrivedAfter'
    }))
    return dispatch(processBeginAfter(pickupDate))
  }
}

export function processBeginAfter(pickupDate, currentTime = moment()) {
  return async (dispatch) => {
    return dispatch(processBegin(currentTime))
      .then((done) => {
        if (done) {
          dispatch(tripSetCurrentState({
            state: 'waitBefore'
          }))
          return done
        }
        else {
          return true
        }
      })
      .finally(() => {        
        return dispatch(processArrivedAfterCountUp(pickupDate))
      })
  }
}

export function processBegin(beginTime = moment()) {
  return async (dispatch) => {
    return dispatch(callApi('v2/driver-action/begin', 1, beginTime))
      .then((done) => {
        if (done) {
          dispatch(processStopTimer())
          return Promise.resolve(true)
        }
        else {
          // dispatch(clearError())
          // return Promise.reject(false)
        }
      })
  }
}

export function processArrivedAfterCountUp(pickupDate) {
  return async (dispatch) => {
    dispatch(processSetArrivedAfterTimer(moment.duration(0)))
    timer.setInterval(
      intervalName
      , () => {
        console.log('processArrivedAfterCountUp interval')
        let timeDiff = moment.duration(new Date().getTime() + COMPENSATE_TIME - new Date(pickupDate).getTime())
        dispatch(processSetArrivedAfterTimer(timeDiff))
      }, pollingTime
    )
  }
}

export function handleStateArrivedBefore(pickupDate) {
  return async (dispatch) => {
    dispatch(tripSetCurrentState({
      state: 'arrivedBefore'
    }))
    return dispatch(processArrivedBeforeCountDown(pickupDate))
  }
}

export function processArrivedBeforeCountDown(pickupDate) {
  return async (dispatch) => {
    dispatch(processSetArrivedBeforeTimer(moment.duration(0)))
    timer.setInterval(
      intervalName
      , async () => {
        console.log('processArrivedBeforeCountDown')
        let timeDiff = moment.duration(new Date().getTime() + COMPENSATE_TIME - new Date(pickupDate).getTime())
        dispatch(processSetArrivedBeforeTimer(timeDiff))
        if (timeDiff > 0) {
          dispatch(processFetchEnd())
          dispatch(processStopTimer())
          let currentTime = await moment().subtract(timeDiff, 'milliseconds').utc().format()
          dispatch(processBeginAfter(pickupDate, currentTime))
        }
        else if (timeDiff > -5000 && timeDiff < -300) {
          dispatch(processFetchStart())
        }
      }, pollingTime
    )
  }
}

export function processSetArrivedBeforeTimer(time) {
  return {
    type: PROCESS_SET_ARRIVED_BEFORE_TIMER,
    arriveBeforeTimer: time
  }
}

export function processSetArrivedAfterTimer(time) {
  return {
    type: PROCESS_SET_ARRIVED_AFTER_TIMER,
    arriveAfterTimer: time,
    arriveBeforeTimer: time,    
  }
}

export function processStopTimer() {
  return async (dispatch) => {
    timer.clearInterval(intervalName)
    dispatch(processSetArrivedBeforeTimer(moment.duration(0)))
    dispatch(processSetArrivedAfterTimer(moment.duration(0)))
    return Promise.resolve(true)
  }
}

export function processBeginGotCustomer() {
  return async (dispatch) => {
    return dispatch(processBegin())
      .then((done) => {
        if (done) {
          dispatch(processGotCustomer())
        }
        else {
          // dispatch(clearError())
        }
      })
  }
}

export function processDrive() {
  return async (dispatch) => {
    return dispatch(callApi('v2/driver-action/drive', 1))
  }
}

export function processGotCustomer() {
  return async (dispatch) => {
    return dispatch(callApi('v2/driver-action/got-customer', 1))
      .then((done) => {
        if (done) {
          dispatch(processStopTimer())
          dispatch(processDrive())
        }
        else {
          // dispatch(clearError())
        }
      })
  }
}

export function processDrop() {
  return async (dispatch, getState) => {
    const { ending } = getState().process
    return dispatch(callApi('v2/driver-action/drop', 1))
      .then((done) => {
        if (!ending && done) {
          const { lastStateChanged } = getState().trip
          dispatch(processDropTimer(lastStateChanged))
        }
        else if (!done) {
          // dispatch(clearError())
        }
        return Promise.resolve(done)
      })
  }
}

export function processDropTimer(dropTime = moment()) {
  return async (dispatch) => {
    dispatch(processSetDropTimer(moment.duration(0)))
    timer.setInterval(
      intervalName
      , () => {
        console.log('processSetDropTimer')
        let timeDiff = moment.duration(new Date().getTime() - new Date(dropTime).getTime())
        dispatch(processSetDropTimer(timeDiff))
      }, pollingTime
    )
  }
}

export function processSetDropMark(time) {
  return {
    type: PROCESS_SET_DROP_MARK,
    dropMark: time
  }
}

export function processSetDropTimer(timer) {
  return {
    type: PROCESS_SET_DROP_TIMER,
    dropTimer: timer
  }
}

export function processContinue() {
  return async (dispatch) => {
    return dispatch(callApi('v2/driver-action/continue', 1))
      .then((done) => {
        if (done) {
          dispatch(processStopTimer())
        }
      })
      .catch((fail) => {
        // dispatch(clearError())
      })
  }
}

export function processEnd() {
  return async (dispatch, getState) => {
    const { token } = getState().auth
    const { tripId } = getState().trip
    dispatch(processEnding(true))
    dispatch(processDrop())
      .then((done) => {
        if (done) {
          return dispatch(callApi('v2/driver-action/end', 1))
        }
      })
      .then((done) => {
        if (done) {
          dispatch(processEnding(false))
          dispatch(navigateToScreen('JobAfterFinish'))
        }
        else {
          // dispatch(clearError())
        }
      })

  }
}

export function processEnding(end) {
  return {
    type: PROCESS_ENDING,
    end: end
  }
}

export function callApi(path, action = 0, timestamp = new Date().toJSON()) {
  return async (dispatch, getState) => {
    try {
      const body = {
        token: getState().auth.token,
        tripId: getState().trip.tripId,
      }
      dispatch(processFetchStart())

      await fetchInfo2(driverApi + path, body, action, timestamp)
      const { state, trip, tripId, lastStateChanged } = await apiGetState(getState().auth.token)

      dispatch(tripSetCurrentState(
        {
          state,
          trip,
          tripId,
          lastStateChanged
        }
      ))

      dispatch(processFetchEnd())

      return Promise.resolve(true)
    }
    catch (error) {
      dispatch(processFetchEnd())
      dispatch(throwErrorAction(error))
      dispatch(clearError())
      // return Promise.reject(false)
    }
  }
}

export function processFetchStart() {
  return {
    type: PROCESS_FETCH_START,
  }
}

export function processFetchEnd() {
  return {
    type: PROCESS_FETCH_END
  }
}

export function navigateScreen(name, params = {}) {
  return async (dispatch) => {
    dispatch(navigateToScreen(name, params))
  }
}