import { loadNotiId } from '../../config/storage'
import { driverApi } from '../../config/hostname'
import { calculateTime, fetchInfo2, getState2 as apiGetState } from '../../config/api'
import timer from 'react-native-timer'
import moment from 'moment'
import { navigateToScreen } from './nav'
import { pollingTime, intervalName, MAX_WAIT_TIME } from '../../config/uiconfig'
// Actions
export const TRIP_FETCH_START = 'trip/TRIP_FETCH_START'
export const TRIP_FETCH_END = 'trip/TRIP_FETCH_END'
export const TRIP_SET_CURRENT_STATE = 'trip/TRIP_SET_CURRENT_STATE'
export const TRIP_SET_COUNT_TIME = 'trip/TRIP_SET_COUNT_TIME'
export const TRIP_WAITING_FOR_ACCEPT = 'trip/TRIP_WAITING_FOR_ACCEPT'
export const THROW_ERROR = 'trip/THROW_ERROR'
export const CLEAR_ERROR = 'trip/CLEAR_ERROR'
export const CLEAR_STATE = 'trip/CLEAR_STATE'

// Reducer
const initialState = {
  state: null,
  tripInfo: {
    pickupDate: null,
    fromLocation: null,
    toLocation: null
  },
  lastTripId: null,
  lastTripInfo: null,
  tripId: null,
  lastStateChanged: null,
  fetching: false,
  countTime: MAX_WAIT_TIME,
  waitingForAccept: false,
  errorMessage: ''
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case TRIP_FETCH_START:
      return {
        ...state,
        fetching: true
      }
    case TRIP_FETCH_END:
      return {
        ...state,
        fetching: false
      }
    case TRIP_SET_CURRENT_STATE:
      return {
        ...state,
        ...(action.data.state && { state: action.data.state }),
        ...(action.data.lastStateChanged && {
          lastStateChanged: moment(action.data.lastStateChanged)
        }),
        ...(action.data.trip && { tripInfo: action.data.trip }),
        ...(action.data.tripId && { tripId: action.data.tripId }),
        ...(action.data.lastTripId && { lastTripId: action.data.lastTripId }),
        ...(action.data.lastTripInfo && { lastTripInfo: action.data.lastTripInfo })
      }
    case TRIP_SET_COUNT_TIME:
      return {
        ...state,
        countTime: action.countTime
      }
    case TRIP_WAITING_FOR_ACCEPT:
      return {
        ...state,
        waitingForAccept: action.waitingForAccept
      }
    case THROW_ERROR:
      return {
        ...state,
        fetching: false,
        errorMessage: action.errorMessage
      }
    case CLEAR_ERROR:
      return {
        ...state,
        errorMessage: ''
      }
    case CLEAR_STATE:
      return {
        ...state,
        state: ''
      }
    default:
      return state
  }
}

// Action Creators
export function throwErrorAction(error) {
  return {
    type: THROW_ERROR,
    errorMessage: error
  }
}

export function clearError() {
  return {
    type: CLEAR_ERROR
  }
}

export function setInitialState() {
  return async (dispatch, getState) => {
    try {
      dispatch(tripFetchStart())
      const { token } = getState().auth
      const {
        state,
        trip,
        tripId,
        lastStateChanged,
        lastTripId,
        lastTripInfo
      } = await apiGetState(token)
      dispatch(
        tripSetCurrentState({
          state,
          trip,
          tripId,
          lastStateChanged,
          lastTripId,
          lastTripInfo
        })
      )
      dispatch(tripFetchEnd())
      return dispatch(tripAdjustUiFromState())
    } catch (error) {
      dispatch(throwErrorAction(error))
    }
  }
}

export function tripAdjustUiFromState() {
  return async (dispatch, getState) => {
    const { state, lastStateChanged } = getState().trip
    if (state == 'rejected' || state == 'evaluated') {
      dispatch(tripApiReadyRequest())
    } else if (state == 'assigned') {
      dispatch(handleStateAssigned(lastStateChanged))
    }
  }
}

export function handleStateAssigned(lastStateChanged) {
  return async (dispatch, getState) => {
    const over = await dispatch(isOverOneminute(lastStateChanged))
    if (over) {
      return dispatch(tripApiAcceptRequest(false)).then(done => {
        if (done) {
          dispatch(tripApiReadyRequest())
        }
      })
    } else {
      return dispatch(tripCountDown())
    }
  }
}

export const isOverOneminute = lastStateChanged => {
  return async () => {
    const timeOver =
      moment.duration(moment().diff(moment(lastStateChanged))).minutes() > 0

    if (timeOver) {
      return Promise.resolve(true)
    } else {
      return Promise.resolve(false)
    }
  }
}

export function navigateScreen(name) {
  return async dispatch => {
    dispatch(navigateToScreen(name))
  }
}

export function tripOpenNoti(openResult) {
  return async dispatch => {
    dispatch(tripHandleNoti(openResult.notification))
  }
}

export function tripReceiveNoti(notification) {
  return async dispatch => {
    dispatch(tripHandleNoti(notification))
  }
}

export function tripHandleNoti(notification) {
  return async (dispatch, getState) => {
    // const { state, trip, tripId, lastStateChanged } = notification.payload.additionalData
    const { token } = getState().auth
    const { index, routes } = getState().nav
    const { routeName } = routes[index]
    try {
      const { state, trip, tripId, lastStateChanged } = await apiGetState(token)
      dispatch(
        tripSetCurrentState({
          state,
          trip,
          tripId,
          lastStateChanged
        })
      )

      if (state == 'standby' || state == 'on-queue') {
        if (routeName !== 'Trips' && routeName !== 'TransportCost') {
          dispatch(navigateToScreen('Trips'))
        }
        dispatch(tripStopWaitingForAccept())
        dispatch(clearError())
        dispatch(tripStopTimer())
      } else if (state == 'assigned') {
        dispatch(tripWaitingForAccept())
        dispatch(handleStateAssigned(lastStateChanged))
      } else if (state == 'on-line') {
        setTimeout(() => {
          // OneSignal.cancelNotification(notification.androidNotificationId)
        }, 2000)
      }
    } catch (error) {
      dispatch(throwErrorAction(error))
      // dispatch(clearError())
      // dispatch(
      //   tripSetCurrentState({
      //     state: 'error'
      //   })
      // )
    }
  }
}

export function tripApiToggle() {
  return async (dispatch, getState) => {
    const { token } = getState().auth
    const { state: prevstate } = getState().trip
    dispatch(tripFetchStart())
    try {
      const {
        state,
        trip,
        tripId,
        lastStateChanged,
        lastTripId,
        lastTripInfo
      } = await apiGetState(token)
      dispatch(tripFetchEnd())
      dispatch(
        tripSetCurrentState({
          state,
          trip,
          tripId,
          lastStateChanged,
          lastTripId,
          lastTripInfo
        })
      )
      if (prevstate !== 'error') {
        if (state == 'on-queue' || state == 'standby') {
          // OneSignal.clearOneSignalNotifications()
          dispatch(tripApiUnreadyRequest())
        } else if (state == 'assigned') {
          dispatch(handleStateAssigned(lastStateChanged))
        } else {
          dispatch(tripApiReadyRequest())
        }
      } else {
        if (state == 'assigned') {
          dispatch(handleStateAssigned(lastStateChanged))
        } else if (state == 'rejected') {
          dispatch(tripApiReadyRequest())
        }
      }
    } catch (error) {
      dispatch(throwErrorAction(error))
      // dispatch(clearError())
      // dispatch(
      //   tripSetCurrentState({
      //     state: 'error'
      //   })
      // )
    }
  }
}

export function tripApiReadyRequest() {
  return async (dispatch, getState) => {
    try {
      const { token } = getState().auth
      const { userId } = await loadNotiId()
      dispatch(tripFetchStart())
      const readyApiResponse = await fetchInfo2(driverApi + 'v3/driver-ready', {
        token: token,
        mode: 'on-queue',
        ...(userId && {playerId: userId})
      })
      // console.log({readyApiResponse})
      const { state, lastStateChanged, lastTripId, lastTripInfo } = await apiGetState(
        token
      )
      dispatch(
        tripSetCurrentState({
          state,
          lastStateChanged,
          lastTripId,
          lastTripInfo
        })
      )
      dispatch(tripFetchEnd())
    } catch (error) {
      dispatch(tripFetchEnd())
      dispatch(throwErrorAction(error))
      // dispatch(clearError())
      // dispatch(
      //   tripSetCurrentState({
      //     state: 'error'
      //   })
      // )
    }
  }
}

export function tripApiUnreadyRequest() {
  return async (dispatch, getState) => {
    const { token } = getState().auth
    dispatch(tripFetchStart())
    try {
      const readyApiResponse = await fetchInfo2(
        driverApi + 'v3/driver-ready',
        {
          token: token,
          mode: 'unready'
        }
      )
      // console.log({readyApiResponse})
      const { state, lastStateChanged, lastTripId, lastTripInfo } = readyApiResponse
      dispatch(
        tripSetCurrentState({
          state,
          lastStateChanged,
          lastTripId,
          lastTripInfo
        })
      )
      if (state !== 'on-queue' && state !== 'standby') {
        dispatch(tripFetchEnd())
      }
    } catch (error) {
      dispatch(tripFetchEnd())
      dispatch(throwErrorAction(error))
      // dispatch(clearError())
      // dispatch(
      //   tripSetCurrentState({
      //     state: 'error'
      //   })
      // )
    }
  }
}

export function tripStopTimer() {
  return async dispatch => {
    Promise.resolve(timer.clearInterval(intervalName))
  }
}

export function tripApiAcceptRequest(yes) {
  return async (dispatch, getState) => {
    try {
      const { token } = getState().auth
      const { tripId } = getState().trip
      dispatch(tripFetchStart())
      const { state, trip, lastStateChanged } = await fetchInfo2(
        driverApi + 'v2/driver-accept',
        {
          token: token,
          tripId: tripId,
          yes: yes
        }
      )
      dispatch(
        tripSetCurrentState({
          state,
          trip,
          tripId,
          lastStateChanged,
          lastTripId: null
        })
      )
      dispatch(tripFetchEnd())
      dispatch(tripStopTimer())
      dispatch(tripStopWaitingForAccept())
      // OneSignal.clearOneSignalNotifications()
      if (yes) {
        return Promise.resolve(state === 'accepted' ? true : false)
      } else {
        return Promise.resolve(state === 'rejected' ? true : false)
      }
    } catch (error) {
      dispatch(tripFetchEnd())
      dispatch(throwErrorAction(error))
      // dispatch(clearError())
      // dispatch(
      //   tripSetCurrentState({
      //     state: 'error'
      //   })
      // )
      return Promise.reject(false)
    }
  }
}

export function tripCountDown() {
  return async (dispatch, getState) => {
    dispatch(tripStopTimer()).then(() => {
      dispatch(tripWaitingForAccept())
      const { lastStateChanged } = getState().trip
      // const waitTime = MAX_WAIT_TIME - Math.floor(((new Date().getTime()) - (lastStateChanged))/1000)
      const waitTime = calculateTime(MAX_WAIT_TIME, lastStateChanged)
      const timeleft = waitTime < 0 ? MAX_WAIT_TIME : waitTime
      dispatch(tripSetCountTime(timeleft))
      timer.setInterval(
        intervalName,
        () => {
          // const { countTime } = getState().trip
          let timeBuffer = calculateTime(MAX_WAIT_TIME, lastStateChanged)
          if (timeBuffer > 0) {
            dispatch(tripSetCountTime(timeBuffer))
          } else {
            // OneSignal.clearOneSignalNotifications()
            dispatch(tripStopTimer())
            dispatch(tripStopWaitingForAccept())
            dispatch(setInitialState())
          }
        },
        pollingTime
      )
    })
  }
}

export function tripWaitingForAccept() {
  return {
    type: TRIP_WAITING_FOR_ACCEPT,
    waitingForAccept: true
  }
}

export function tripStopWaitingForAccept() {
  return {
    type: TRIP_WAITING_FOR_ACCEPT,
    waitingForAccept: false
  }
}

export function tripSetCurrentState(data) {
  return {
    type: TRIP_SET_CURRENT_STATE,
    data: data
  }
}

export function tripSetCountTime(countTime) {
  return {
    type: TRIP_SET_COUNT_TIME,
    countTime: countTime
  }
}

export function tripFetchStart() {
  return {
    type: TRIP_FETCH_START
  }
}

export function tripFetchEnd() {
  return {
    type: TRIP_FETCH_END
  }
}

export function tripClearState() {
  return {
    type: CLEAR_STATE
  }
}
