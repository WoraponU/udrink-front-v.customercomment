import { fetchInfo2 } from '../../config/api'
import { driverApi } from '../../config/hostname'
import { navigateToScreen } from './nav'
import { setToken as saveToken, setLogin as saveLogin } from '../../config/storage'

// Actions
export const LOGIN_REQUEST = 'auth/LOGIN_REQUEST'
export const LOGIN_SUCCESS = 'auth/LOGIN_SUCCESS'
export const LOGIN_SAVE_PLAYERID = 'auth/LOGIN_SAVE_PLAYERID'
export const THROW_ERROR = 'auth/THROW_ERROR'
export const CLEAR_ERROR = 'auth/CLEAR_ERROR'
export const CHECKING_TOKEN = 'auth/CHECKING_TOKEN'
export const CHECKING_TOKEN_DONE = 'auth/CHECKING_TOKEN_DONE'

// Reducer
const initialState = {
  token: null,
  isFetching: false,
  isError: false,
  errorMessage: '',
  playerId: '',

  isCheckingToken: false
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case LOGIN_REQUEST:
      return {
        ...state,
        isFetching: true,
        isError: false
      }
    case LOGIN_SUCCESS:
      return {
        ...state,
        isFetching: false,
        isError: false,
        token: action.token
      }
    case LOGIN_SAVE_PLAYERID:
      return {
        ...state,
        playerId: action.playerId
      }
    case THROW_ERROR:
      return {
        ...state,
        isFetching: false,
        errorMessage: action.errorMessage
      }
    case CLEAR_ERROR:
      return {
        ...state,
        errorMessage: ''
      }

    case CHECKING_TOKEN:
      return {
        ...state,
        isCheckingToken: true
      }

    case CHECKING_TOKEN_DONE:
      return {
        ...state,
        isCheckingToken: false
      }

    default:
      return state
  }
}

// Action Creators
export function throwErrorAction(error) {
  return {
    type: THROW_ERROR,
    errorMessage: error
  }
}

export function clearError() {
  return {
    type: CLEAR_ERROR
  }
}

export function requestLogin(creds) {
  return async dispatch => {
    // console.log({ creds })
    dispatch(loginRequest())
    try {
      let { token, state, driverId } = await fetchInfo2(driverApi + 'driver-login', creds)
      if (state && token) {
        _saveCred(token, creds.email, creds.password)
        if (driverId) {
          // OneSignal.sendTag('_id', driverId)
        }
        dispatch(loginSuccess(token))
        return dispatch(nextScreen(state, creds))
      }
    } catch (error) {
      console.log(error)
      dispatch(throwErrorAction(error))
    }
  }
}

const _saveCred = (token, email, password) => {
  saveToken(token)
  saveLogin(email, password)
}

export function nextScreen(state, creds) {
  return async dispatch => {
    if (state) {
      if (
        state == 'on-queue' ||
        state == 'standby' ||
        state == 'on-line' ||
        state == 'evaluated' ||
        state == 'assigned'
      ) {
        dispatch(navigateToScreen('Trips'))
      } else if (
        state == 'accepted' ||
        state == 'booked' ||
        state == 'travel' ||
        state == 'arrived' ||
        state == 'on-job' ||
        state == 'on-board' ||
        state == 'wait-before'
      ) {
        dispatch(navigateToScreen('JobProcess'))
      } else if (state == 'drive') {
        dispatch(navigateToScreen('JobProcess'))
      } else if (state == 'wait-after' || state == 'drop') {
        dispatch(navigateToScreen('JobProcess'))
      } else if (state == 'off-job') {
        dispatch(navigateToScreen('JobAfterFinish'))
      } else {
        dispatch(navigateToScreen('Trips'))
      }
    }
  }
}

export function loginRequest() {
  return {
    type: LOGIN_REQUEST
  }
}

export function loginSuccess(token) {
  return {
    type: LOGIN_SUCCESS,
    token: token
  }
}

export function loginSavePlayerId(playerId) {
  return {
    type: LOGIN_SAVE_PLAYERID,
    playerId: playerId
  }
}

export const checkingToken = _ => ({
  type: CHECKING_TOKEN
})

export const checkingTokenDone = _ => ({
  type: CHECKING_TOKEN_DONE
})
