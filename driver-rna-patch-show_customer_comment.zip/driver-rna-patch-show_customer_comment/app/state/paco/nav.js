import { NavigationActions } from 'react-navigation'
import Navigator from '../../config/router'

const initialState = Navigator.router.getStateForAction(NavigationActions.init())

export default (state = initialState, action) => {
  const nextState = Navigator.router.getStateForAction(action, state)
  return nextState || state
}

// export const navigateToScreen = screenName => NavigationActions.replace({
//   routeName: screenName,
//   params: {}
// })

// export const navigateToScreen = (routeName) => NavigationActions.reset({
//   index: 0,
//   actions: [
//     NavigationActionsc.navigate({ routeName })
//   ]
// })

export const navigateToScreen = (routeName, params = {}) =>
  NavigationActions.reset({
    index: 0,
    actions: [
      NavigationActions.navigate({
        routeName,
        params
      })
    ]
  })
