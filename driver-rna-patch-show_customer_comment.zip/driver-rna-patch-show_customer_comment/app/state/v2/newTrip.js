import { tripHandleNoti } from '../paco/trip'

// Actions
export const ASSIGN = 'newTrip/ASSIGN'
export const ACCEPT = 'newTrip/ACCEPT'
export const REJECT = 'newTrip/REJECT'
export const PURGE = 'newTrip/PURGE'

// Reducer
const initialState = {}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case ASSIGN: {
      const { tripId, trip } = action.payload
      return {
        status: 'assigned',
        data: {
          _id: tripId,
          ...trip
        }
      }
    }

    case ACCEPT:
      return {
        ...state,
        status: 'accepted'
      }

    case REJECT:
      return {
        ...state,
        status: 'rejected'
      }

    case PURGE:
      return {}

    default:
      return state
  }
}

// Action Creators
export const assign = newTrip => ({
  type: ASSIGN,
  payload: newTrip
})

export const accept = _ => ({
  type: ACCEPT
})

export const reject = _ => ({
  type: REJECT
})

export const purge = _ => ({
  type: PURGE
})

export const checkIn = newTrip => {
  if (newTrip && newTrip.trip) {
    newTrip.trip = JSON.parse(newTrip.trip)
  }
  return async (dispatch, getState) => {
    dispatch(purge())
    dispatch(assign(newTrip))
    return dispatch(tripHandleNoti(newTrip))
  }
}
