// Actions
export const SYNC = 'driverState/SYNC'
export const SET = 'driverState/SET'

// Reducer
const initialState = {
  data: {},
  lastFetched: null,

  isFetching: false,
  isFetchingError: false,
  error: null
}

export default function reducer(state = initialState, action = {}) {
  switch (action.type) {
    case `${SYNC}_PENDING`:
      return {
        ...state,
        isFetching: true,
        isFetchingError: false,
        error: null
      }

    case `${SYNC}_FULFILLED`:
      return {
        ...state,
        data: action.payload,
        lastFetched: new Date(),
        isFetching: false
      }

    case `${SYNC}_REJECTED`:
      return {
        ...state,
        isFetching: false,
        isFetchingError: true,
        error: action.payload
      }

    case `SET`:
      return {
        ...state,
        data: {
          ...state.data,
          ...action.payload
        }
      }

    default:
      return state
  }
}

// Action Creators
export const sync = _ => ({
  type: SYNC,
  payload: {} // TODO: change to fetchDriverStateFromAPI promise
})

export const set = data => ({
  type: SET,
  payload: data
})
