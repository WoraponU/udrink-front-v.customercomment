import React from 'react'
import { Provider, connect } from 'react-redux'

import configureStore from './state/configureStore'
import App from './screens/App'

import { setCustomTextInput, setCustomText } from 'react-native-global-props'

import { processSetCurrentLocation } from './state/paco/process'

import { loginSavePlayerId } from './state/paco/auth'

import { tripReceiveNoti, tripOpenNoti } from './state/paco/trip'

import { checkIn } from './state/v2/newTrip'

const customTextProps = {
  style: {
    fontSize: 22,
    fontFamily: 'dbhelvethaicax'
  }
}

setCustomTextInput(customTextProps)
setCustomText(customTextProps)

const store = configureStore()

const mapStateToProp = state => ({
  nav: state.nav,
  token: state.auth.token,
  newTripState: state.newTrip.status,
  trip: state.trip
})

const mapDispatchToProp = dispatch => ({
  processSetCurrentLocation: location => dispatch(processSetCurrentLocation(location)),
  tripReceiveNoti: notification => dispatch(tripReceiveNoti(notification)),
  tripOpenNoti: openResult => dispatch(tripOpenNoti(openResult)),
  loginSavePlayerId: playerId => dispatch(loginSavePlayerId(playerId)),
  checkIn: newTrip => dispatch(checkIn(newTrip))
})

const AppWithNavigationState = connect(
  mapStateToProp,
  mapDispatchToProp
)(App)

export default () => (
  <Provider store={store}>
    <AppWithNavigationState />
  </Provider>
)
