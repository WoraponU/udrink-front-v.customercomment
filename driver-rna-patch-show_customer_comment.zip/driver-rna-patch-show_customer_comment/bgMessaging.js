import firebase from 'react-native-firebase'
import { Linking } from 'react-native'

const showLocalNotification = (messageId, data) => {
  const { event, title, body } = data
  const notification = new firebase.notifications.Notification()
    .setNotificationId(messageId)
    .setTitle(title)
    .setBody(body)
    .setData(data)
  notification.android.setChannelId(event)
  notification.android.setPriority(firebase.notifications.Android.Priority.Max)
  notification.android.setAutoCancel(true)
  firebase.notifications().displayNotification(notification)
}

const openURL = (prefix) => {
  const intentName = 'udid://driver'

  Linking.canOpenURL(`${intentName}/${prefix}`).then(supported => {
    if (supported) {
      Linking.openURL(`${intentName}/${prefix}`);
    }
  })
}

export default async message => {
  const data = message.data
  console.log({ data })

  const { event } = data || {}
  switch (event) {
    case 'new-trip':
      openURL('new-trip');
      break;
  }

  return new Promise((done, failed) => {
    showLocalNotification(message.messageId, data)
    done()
  })
}
