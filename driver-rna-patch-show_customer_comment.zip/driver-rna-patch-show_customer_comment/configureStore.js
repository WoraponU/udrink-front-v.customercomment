import { createStore, combineReducers, applyMiddleware } from 'redux'
import { composeWithDevTools } from 'remote-redux-devtools'
import * as reducers from './ducks'

const rootReducer = combineReducers({
  ...reducers
})

import createSagaMiddleware from 'redux-saga'
import dataSaga from './ducks/sagas'

const sagaMiddleware = createSagaMiddleware()

export default function configureStore() {
  const store = createStore(
    rootReducer,
    composeWithDevTools(applyMiddleware(sagaMiddleware))
  )
  sagaMiddleware.run(dataSaga)

  return store
}
